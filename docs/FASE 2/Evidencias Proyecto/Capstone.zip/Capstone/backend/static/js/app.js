// JS general del frontend (ej: auto-cierre de alerts, toasts, etc.)
console.debug("App UI loaded");
