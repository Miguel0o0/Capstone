# Diagrama rápido del modelo

Vista general de las entidades, relaciones y reglas del sistema.

![ERD](./ERD%20(1).png)

> Fuente: diagrama ERD general utilizado para representar las relaciones entre las tablas del proyecto.
