--
-- PostgreSQL database dump
--

-- Dumped from database version 17.6
-- Dumped by pg_dump version 17.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: auth; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA auth;


ALTER SCHEMA auth OWNER TO supabase_admin;

--
-- Name: extensions; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA extensions;


ALTER SCHEMA extensions OWNER TO postgres;

--
-- Name: graphql; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA graphql;


ALTER SCHEMA graphql OWNER TO supabase_admin;

--
-- Name: graphql_public; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA graphql_public;


ALTER SCHEMA graphql_public OWNER TO supabase_admin;

--
-- Name: pgbouncer; Type: SCHEMA; Schema: -; Owner: pgbouncer
--

CREATE SCHEMA pgbouncer;


ALTER SCHEMA pgbouncer OWNER TO pgbouncer;

--
-- Name: realtime; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA realtime;


ALTER SCHEMA realtime OWNER TO supabase_admin;

--
-- Name: storage; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA storage;


ALTER SCHEMA storage OWNER TO supabase_admin;

--
-- Name: vault; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA vault;


ALTER SCHEMA vault OWNER TO supabase_admin;

--
-- Name: pg_graphql; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_graphql WITH SCHEMA graphql;


--
-- Name: EXTENSION pg_graphql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_graphql IS 'pg_graphql: GraphQL support';


--
-- Name: pg_stat_statements; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_stat_statements WITH SCHEMA extensions;


--
-- Name: EXTENSION pg_stat_statements; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_stat_statements IS 'track planning and execution statistics of all SQL statements executed';


--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA extensions;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: supabase_vault; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS supabase_vault WITH SCHEMA vault;


--
-- Name: EXTENSION supabase_vault; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION supabase_vault IS 'Supabase Vault Extension';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA extensions;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: aal_level; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE auth.aal_level AS ENUM (
    'aal1',
    'aal2',
    'aal3'
);


ALTER TYPE auth.aal_level OWNER TO supabase_auth_admin;

--
-- Name: code_challenge_method; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE auth.code_challenge_method AS ENUM (
    's256',
    'plain'
);


ALTER TYPE auth.code_challenge_method OWNER TO supabase_auth_admin;

--
-- Name: factor_status; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE auth.factor_status AS ENUM (
    'unverified',
    'verified'
);


ALTER TYPE auth.factor_status OWNER TO supabase_auth_admin;

--
-- Name: factor_type; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE auth.factor_type AS ENUM (
    'totp',
    'webauthn',
    'phone'
);


ALTER TYPE auth.factor_type OWNER TO supabase_auth_admin;

--
-- Name: oauth_authorization_status; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE auth.oauth_authorization_status AS ENUM (
    'pending',
    'approved',
    'denied',
    'expired'
);


ALTER TYPE auth.oauth_authorization_status OWNER TO supabase_auth_admin;

--
-- Name: oauth_client_type; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE auth.oauth_client_type AS ENUM (
    'public',
    'confidential'
);


ALTER TYPE auth.oauth_client_type OWNER TO supabase_auth_admin;

--
-- Name: oauth_registration_type; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE auth.oauth_registration_type AS ENUM (
    'dynamic',
    'manual'
);


ALTER TYPE auth.oauth_registration_type OWNER TO supabase_auth_admin;

--
-- Name: oauth_response_type; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE auth.oauth_response_type AS ENUM (
    'code'
);


ALTER TYPE auth.oauth_response_type OWNER TO supabase_auth_admin;

--
-- Name: one_time_token_type; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE auth.one_time_token_type AS ENUM (
    'confirmation_token',
    'reauthentication_token',
    'recovery_token',
    'email_change_token_new',
    'email_change_token_current',
    'phone_change_token'
);


ALTER TYPE auth.one_time_token_type OWNER TO supabase_auth_admin;

--
-- Name: action; Type: TYPE; Schema: realtime; Owner: supabase_admin
--

CREATE TYPE realtime.action AS ENUM (
    'INSERT',
    'UPDATE',
    'DELETE',
    'TRUNCATE',
    'ERROR'
);


ALTER TYPE realtime.action OWNER TO supabase_admin;

--
-- Name: equality_op; Type: TYPE; Schema: realtime; Owner: supabase_admin
--

CREATE TYPE realtime.equality_op AS ENUM (
    'eq',
    'neq',
    'lt',
    'lte',
    'gt',
    'gte',
    'in'
);


ALTER TYPE realtime.equality_op OWNER TO supabase_admin;

--
-- Name: user_defined_filter; Type: TYPE; Schema: realtime; Owner: supabase_admin
--

CREATE TYPE realtime.user_defined_filter AS (
	column_name text,
	op realtime.equality_op,
	value text
);


ALTER TYPE realtime.user_defined_filter OWNER TO supabase_admin;

--
-- Name: wal_column; Type: TYPE; Schema: realtime; Owner: supabase_admin
--

CREATE TYPE realtime.wal_column AS (
	name text,
	type_name text,
	type_oid oid,
	value jsonb,
	is_pkey boolean,
	is_selectable boolean
);


ALTER TYPE realtime.wal_column OWNER TO supabase_admin;

--
-- Name: wal_rls; Type: TYPE; Schema: realtime; Owner: supabase_admin
--

CREATE TYPE realtime.wal_rls AS (
	wal jsonb,
	is_rls_enabled boolean,
	subscription_ids uuid[],
	errors text[]
);


ALTER TYPE realtime.wal_rls OWNER TO supabase_admin;

--
-- Name: buckettype; Type: TYPE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TYPE storage.buckettype AS ENUM (
    'STANDARD',
    'ANALYTICS',
    'VECTOR'
);


ALTER TYPE storage.buckettype OWNER TO supabase_storage_admin;

--
-- Name: email(); Type: FUNCTION; Schema: auth; Owner: supabase_auth_admin
--

CREATE FUNCTION auth.email() RETURNS text
    LANGUAGE sql STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.email', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'email')
  )::text
$$;


ALTER FUNCTION auth.email() OWNER TO supabase_auth_admin;

--
-- Name: FUNCTION email(); Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON FUNCTION auth.email() IS 'Deprecated. Use auth.jwt() -> ''email'' instead.';


--
-- Name: jwt(); Type: FUNCTION; Schema: auth; Owner: supabase_auth_admin
--

CREATE FUNCTION auth.jwt() RETURNS jsonb
    LANGUAGE sql STABLE
    AS $$
  select 
    coalesce(
        nullif(current_setting('request.jwt.claim', true), ''),
        nullif(current_setting('request.jwt.claims', true), '')
    )::jsonb
$$;


ALTER FUNCTION auth.jwt() OWNER TO supabase_auth_admin;

--
-- Name: role(); Type: FUNCTION; Schema: auth; Owner: supabase_auth_admin
--

CREATE FUNCTION auth.role() RETURNS text
    LANGUAGE sql STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.role', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'role')
  )::text
$$;


ALTER FUNCTION auth.role() OWNER TO supabase_auth_admin;

--
-- Name: FUNCTION role(); Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON FUNCTION auth.role() IS 'Deprecated. Use auth.jwt() -> ''role'' instead.';


--
-- Name: uid(); Type: FUNCTION; Schema: auth; Owner: supabase_auth_admin
--

CREATE FUNCTION auth.uid() RETURNS uuid
    LANGUAGE sql STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.sub', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'sub')
  )::uuid
$$;


ALTER FUNCTION auth.uid() OWNER TO supabase_auth_admin;

--
-- Name: FUNCTION uid(); Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON FUNCTION auth.uid() IS 'Deprecated. Use auth.jwt() -> ''sub'' instead.';


--
-- Name: grant_pg_cron_access(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION extensions.grant_pg_cron_access() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF EXISTS (
    SELECT
    FROM pg_event_trigger_ddl_commands() AS ev
    JOIN pg_extension AS ext
    ON ev.objid = ext.oid
    WHERE ext.extname = 'pg_cron'
  )
  THEN
    grant usage on schema cron to postgres with grant option;

    alter default privileges in schema cron grant all on tables to postgres with grant option;
    alter default privileges in schema cron grant all on functions to postgres with grant option;
    alter default privileges in schema cron grant all on sequences to postgres with grant option;

    alter default privileges for user supabase_admin in schema cron grant all
        on sequences to postgres with grant option;
    alter default privileges for user supabase_admin in schema cron grant all
        on tables to postgres with grant option;
    alter default privileges for user supabase_admin in schema cron grant all
        on functions to postgres with grant option;

    grant all privileges on all tables in schema cron to postgres with grant option;
    revoke all on table cron.job from postgres;
    grant select on table cron.job to postgres with grant option;
  END IF;
END;
$$;


ALTER FUNCTION extensions.grant_pg_cron_access() OWNER TO supabase_admin;

--
-- Name: FUNCTION grant_pg_cron_access(); Type: COMMENT; Schema: extensions; Owner: supabase_admin
--

COMMENT ON FUNCTION extensions.grant_pg_cron_access() IS 'Grants access to pg_cron';


--
-- Name: grant_pg_graphql_access(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION extensions.grant_pg_graphql_access() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $_$
DECLARE
    func_is_graphql_resolve bool;
BEGIN
    func_is_graphql_resolve = (
        SELECT n.proname = 'resolve'
        FROM pg_event_trigger_ddl_commands() AS ev
        LEFT JOIN pg_catalog.pg_proc AS n
        ON ev.objid = n.oid
    );

    IF func_is_graphql_resolve
    THEN
        -- Update public wrapper to pass all arguments through to the pg_graphql resolve func
        DROP FUNCTION IF EXISTS graphql_public.graphql;
        create or replace function graphql_public.graphql(
            "operationName" text default null,
            query text default null,
            variables jsonb default null,
            extensions jsonb default null
        )
            returns jsonb
            language sql
        as $$
            select graphql.resolve(
                query := query,
                variables := coalesce(variables, '{}'),
                "operationName" := "operationName",
                extensions := extensions
            );
        $$;

        -- This hook executes when `graphql.resolve` is created. That is not necessarily the last
        -- function in the extension so we need to grant permissions on existing entities AND
        -- update default permissions to any others that are created after `graphql.resolve`
        grant usage on schema graphql to postgres, anon, authenticated, service_role;
        grant select on all tables in schema graphql to postgres, anon, authenticated, service_role;
        grant execute on all functions in schema graphql to postgres, anon, authenticated, service_role;
        grant all on all sequences in schema graphql to postgres, anon, authenticated, service_role;
        alter default privileges in schema graphql grant all on tables to postgres, anon, authenticated, service_role;
        alter default privileges in schema graphql grant all on functions to postgres, anon, authenticated, service_role;
        alter default privileges in schema graphql grant all on sequences to postgres, anon, authenticated, service_role;

        -- Allow postgres role to allow granting usage on graphql and graphql_public schemas to custom roles
        grant usage on schema graphql_public to postgres with grant option;
        grant usage on schema graphql to postgres with grant option;
    END IF;

END;
$_$;


ALTER FUNCTION extensions.grant_pg_graphql_access() OWNER TO supabase_admin;

--
-- Name: FUNCTION grant_pg_graphql_access(); Type: COMMENT; Schema: extensions; Owner: supabase_admin
--

COMMENT ON FUNCTION extensions.grant_pg_graphql_access() IS 'Grants access to pg_graphql';


--
-- Name: grant_pg_net_access(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION extensions.grant_pg_net_access() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF EXISTS (
    SELECT 1
    FROM pg_event_trigger_ddl_commands() AS ev
    JOIN pg_extension AS ext
    ON ev.objid = ext.oid
    WHERE ext.extname = 'pg_net'
  )
  THEN
    IF NOT EXISTS (
      SELECT 1
      FROM pg_roles
      WHERE rolname = 'supabase_functions_admin'
    )
    THEN
      CREATE USER supabase_functions_admin NOINHERIT CREATEROLE LOGIN NOREPLICATION;
    END IF;

    GRANT USAGE ON SCHEMA net TO supabase_functions_admin, postgres, anon, authenticated, service_role;

    IF EXISTS (
      SELECT FROM pg_extension
      WHERE extname = 'pg_net'
      -- all versions in use on existing projects as of 2025-02-20
      -- version 0.12.0 onwards don't need these applied
      AND extversion IN ('0.2', '0.6', '0.7', '0.7.1', '0.8', '0.10.0', '0.11.0')
    ) THEN
      ALTER function net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) SECURITY DEFINER;
      ALTER function net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) SECURITY DEFINER;

      ALTER function net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) SET search_path = net;
      ALTER function net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) SET search_path = net;

      REVOKE ALL ON FUNCTION net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) FROM PUBLIC;
      REVOKE ALL ON FUNCTION net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) FROM PUBLIC;

      GRANT EXECUTE ON FUNCTION net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) TO supabase_functions_admin, postgres, anon, authenticated, service_role;
      GRANT EXECUTE ON FUNCTION net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) TO supabase_functions_admin, postgres, anon, authenticated, service_role;
    END IF;
  END IF;
END;
$$;


ALTER FUNCTION extensions.grant_pg_net_access() OWNER TO supabase_admin;

--
-- Name: FUNCTION grant_pg_net_access(); Type: COMMENT; Schema: extensions; Owner: supabase_admin
--

COMMENT ON FUNCTION extensions.grant_pg_net_access() IS 'Grants access to pg_net';


--
-- Name: pgrst_ddl_watch(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION extensions.pgrst_ddl_watch() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  cmd record;
BEGIN
  FOR cmd IN SELECT * FROM pg_event_trigger_ddl_commands()
  LOOP
    IF cmd.command_tag IN (
      'CREATE SCHEMA', 'ALTER SCHEMA'
    , 'CREATE TABLE', 'CREATE TABLE AS', 'SELECT INTO', 'ALTER TABLE'
    , 'CREATE FOREIGN TABLE', 'ALTER FOREIGN TABLE'
    , 'CREATE VIEW', 'ALTER VIEW'
    , 'CREATE MATERIALIZED VIEW', 'ALTER MATERIALIZED VIEW'
    , 'CREATE FUNCTION', 'ALTER FUNCTION'
    , 'CREATE TRIGGER'
    , 'CREATE TYPE', 'ALTER TYPE'
    , 'CREATE RULE'
    , 'COMMENT'
    )
    -- don't notify in case of CREATE TEMP table or other objects created on pg_temp
    AND cmd.schema_name is distinct from 'pg_temp'
    THEN
      NOTIFY pgrst, 'reload schema';
    END IF;
  END LOOP;
END; $$;


ALTER FUNCTION extensions.pgrst_ddl_watch() OWNER TO supabase_admin;

--
-- Name: pgrst_drop_watch(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION extensions.pgrst_drop_watch() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  obj record;
BEGIN
  FOR obj IN SELECT * FROM pg_event_trigger_dropped_objects()
  LOOP
    IF obj.object_type IN (
      'schema'
    , 'table'
    , 'foreign table'
    , 'view'
    , 'materialized view'
    , 'function'
    , 'trigger'
    , 'type'
    , 'rule'
    )
    AND obj.is_temporary IS false -- no pg_temp objects
    THEN
      NOTIFY pgrst, 'reload schema';
    END IF;
  END LOOP;
END; $$;


ALTER FUNCTION extensions.pgrst_drop_watch() OWNER TO supabase_admin;

--
-- Name: set_graphql_placeholder(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION extensions.set_graphql_placeholder() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $_$
    DECLARE
    graphql_is_dropped bool;
    BEGIN
    graphql_is_dropped = (
        SELECT ev.schema_name = 'graphql_public'
        FROM pg_event_trigger_dropped_objects() AS ev
        WHERE ev.schema_name = 'graphql_public'
    );

    IF graphql_is_dropped
    THEN
        create or replace function graphql_public.graphql(
            "operationName" text default null,
            query text default null,
            variables jsonb default null,
            extensions jsonb default null
        )
            returns jsonb
            language plpgsql
        as $$
            DECLARE
                server_version float;
            BEGIN
                server_version = (SELECT (SPLIT_PART((select version()), ' ', 2))::float);

                IF server_version >= 14 THEN
                    RETURN jsonb_build_object(
                        'errors', jsonb_build_array(
                            jsonb_build_object(
                                'message', 'pg_graphql extension is not enabled.'
                            )
                        )
                    );
                ELSE
                    RETURN jsonb_build_object(
                        'errors', jsonb_build_array(
                            jsonb_build_object(
                                'message', 'pg_graphql is only available on projects running Postgres 14 onwards.'
                            )
                        )
                    );
                END IF;
            END;
        $$;
    END IF;

    END;
$_$;


ALTER FUNCTION extensions.set_graphql_placeholder() OWNER TO supabase_admin;

--
-- Name: FUNCTION set_graphql_placeholder(); Type: COMMENT; Schema: extensions; Owner: supabase_admin
--

COMMENT ON FUNCTION extensions.set_graphql_placeholder() IS 'Reintroduces placeholder function for graphql_public.graphql';


--
-- Name: get_auth(text); Type: FUNCTION; Schema: pgbouncer; Owner: supabase_admin
--

CREATE FUNCTION pgbouncer.get_auth(p_usename text) RETURNS TABLE(username text, password text)
    LANGUAGE plpgsql SECURITY DEFINER
    AS $_$
begin
    raise debug 'PgBouncer auth request: %', p_usename;

    return query
    select 
        rolname::text, 
        case when rolvaliduntil < now() 
            then null 
            else rolpassword::text 
        end 
    from pg_authid 
    where rolname=$1 and rolcanlogin;
end;
$_$;


ALTER FUNCTION pgbouncer.get_auth(p_usename text) OWNER TO supabase_admin;

--
-- Name: apply_rls(jsonb, integer); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION realtime.apply_rls(wal jsonb, max_record_bytes integer DEFAULT (1024 * 1024)) RETURNS SETOF realtime.wal_rls
    LANGUAGE plpgsql
    AS $$
declare
-- Regclass of the table e.g. public.notes
entity_ regclass = (quote_ident(wal ->> 'schema') || '.' || quote_ident(wal ->> 'table'))::regclass;

-- I, U, D, T: insert, update ...
action realtime.action = (
    case wal ->> 'action'
        when 'I' then 'INSERT'
        when 'U' then 'UPDATE'
        when 'D' then 'DELETE'
        else 'ERROR'
    end
);

-- Is row level security enabled for the table
is_rls_enabled bool = relrowsecurity from pg_class where oid = entity_;

subscriptions realtime.subscription[] = array_agg(subs)
    from
        realtime.subscription subs
    where
        subs.entity = entity_;

-- Subscription vars
roles regrole[] = array_agg(distinct us.claims_role::text)
    from
        unnest(subscriptions) us;

working_role regrole;
claimed_role regrole;
claims jsonb;

subscription_id uuid;
subscription_has_access bool;
visible_to_subscription_ids uuid[] = '{}';

-- structured info for wal's columns
columns realtime.wal_column[];
-- previous identity values for update/delete
old_columns realtime.wal_column[];

error_record_exceeds_max_size boolean = octet_length(wal::text) > max_record_bytes;

-- Primary jsonb output for record
output jsonb;

begin
perform set_config('role', null, true);

columns =
    array_agg(
        (
            x->>'name',
            x->>'type',
            x->>'typeoid',
            realtime.cast(
                (x->'value') #>> '{}',
                coalesce(
                    (x->>'typeoid')::regtype, -- null when wal2json version <= 2.4
                    (x->>'type')::regtype
                )
            ),
            (pks ->> 'name') is not null,
            true
        )::realtime.wal_column
    )
    from
        jsonb_array_elements(wal -> 'columns') x
        left join jsonb_array_elements(wal -> 'pk') pks
            on (x ->> 'name') = (pks ->> 'name');

old_columns =
    array_agg(
        (
            x->>'name',
            x->>'type',
            x->>'typeoid',
            realtime.cast(
                (x->'value') #>> '{}',
                coalesce(
                    (x->>'typeoid')::regtype, -- null when wal2json version <= 2.4
                    (x->>'type')::regtype
                )
            ),
            (pks ->> 'name') is not null,
            true
        )::realtime.wal_column
    )
    from
        jsonb_array_elements(wal -> 'identity') x
        left join jsonb_array_elements(wal -> 'pk') pks
            on (x ->> 'name') = (pks ->> 'name');

for working_role in select * from unnest(roles) loop

    -- Update `is_selectable` for columns and old_columns
    columns =
        array_agg(
            (
                c.name,
                c.type_name,
                c.type_oid,
                c.value,
                c.is_pkey,
                pg_catalog.has_column_privilege(working_role, entity_, c.name, 'SELECT')
            )::realtime.wal_column
        )
        from
            unnest(columns) c;

    old_columns =
            array_agg(
                (
                    c.name,
                    c.type_name,
                    c.type_oid,
                    c.value,
                    c.is_pkey,
                    pg_catalog.has_column_privilege(working_role, entity_, c.name, 'SELECT')
                )::realtime.wal_column
            )
            from
                unnest(old_columns) c;

    if action <> 'DELETE' and count(1) = 0 from unnest(columns) c where c.is_pkey then
        return next (
            jsonb_build_object(
                'schema', wal ->> 'schema',
                'table', wal ->> 'table',
                'type', action
            ),
            is_rls_enabled,
            -- subscriptions is already filtered by entity
            (select array_agg(s.subscription_id) from unnest(subscriptions) as s where claims_role = working_role),
            array['Error 400: Bad Request, no primary key']
        )::realtime.wal_rls;

    -- The claims role does not have SELECT permission to the primary key of entity
    elsif action <> 'DELETE' and sum(c.is_selectable::int) <> count(1) from unnest(columns) c where c.is_pkey then
        return next (
            jsonb_build_object(
                'schema', wal ->> 'schema',
                'table', wal ->> 'table',
                'type', action
            ),
            is_rls_enabled,
            (select array_agg(s.subscription_id) from unnest(subscriptions) as s where claims_role = working_role),
            array['Error 401: Unauthorized']
        )::realtime.wal_rls;

    else
        output = jsonb_build_object(
            'schema', wal ->> 'schema',
            'table', wal ->> 'table',
            'type', action,
            'commit_timestamp', to_char(
                ((wal ->> 'timestamp')::timestamptz at time zone 'utc'),
                'YYYY-MM-DD"T"HH24:MI:SS.MS"Z"'
            ),
            'columns', (
                select
                    jsonb_agg(
                        jsonb_build_object(
                            'name', pa.attname,
                            'type', pt.typname
                        )
                        order by pa.attnum asc
                    )
                from
                    pg_attribute pa
                    join pg_type pt
                        on pa.atttypid = pt.oid
                where
                    attrelid = entity_
                    and attnum > 0
                    and pg_catalog.has_column_privilege(working_role, entity_, pa.attname, 'SELECT')
            )
        )
        -- Add "record" key for insert and update
        || case
            when action in ('INSERT', 'UPDATE') then
                jsonb_build_object(
                    'record',
                    (
                        select
                            jsonb_object_agg(
                                -- if unchanged toast, get column name and value from old record
                                coalesce((c).name, (oc).name),
                                case
                                    when (c).name is null then (oc).value
                                    else (c).value
                                end
                            )
                        from
                            unnest(columns) c
                            full outer join unnest(old_columns) oc
                                on (c).name = (oc).name
                        where
                            coalesce((c).is_selectable, (oc).is_selectable)
                            and ( not error_record_exceeds_max_size or (octet_length((c).value::text) <= 64))
                    )
                )
            else '{}'::jsonb
        end
        -- Add "old_record" key for update and delete
        || case
            when action = 'UPDATE' then
                jsonb_build_object(
                        'old_record',
                        (
                            select jsonb_object_agg((c).name, (c).value)
                            from unnest(old_columns) c
                            where
                                (c).is_selectable
                                and ( not error_record_exceeds_max_size or (octet_length((c).value::text) <= 64))
                        )
                    )
            when action = 'DELETE' then
                jsonb_build_object(
                    'old_record',
                    (
                        select jsonb_object_agg((c).name, (c).value)
                        from unnest(old_columns) c
                        where
                            (c).is_selectable
                            and ( not error_record_exceeds_max_size or (octet_length((c).value::text) <= 64))
                            and ( not is_rls_enabled or (c).is_pkey ) -- if RLS enabled, we can't secure deletes so filter to pkey
                    )
                )
            else '{}'::jsonb
        end;

        -- Create the prepared statement
        if is_rls_enabled and action <> 'DELETE' then
            if (select 1 from pg_prepared_statements where name = 'walrus_rls_stmt' limit 1) > 0 then
                deallocate walrus_rls_stmt;
            end if;
            execute realtime.build_prepared_statement_sql('walrus_rls_stmt', entity_, columns);
        end if;

        visible_to_subscription_ids = '{}';

        for subscription_id, claims in (
                select
                    subs.subscription_id,
                    subs.claims
                from
                    unnest(subscriptions) subs
                where
                    subs.entity = entity_
                    and subs.claims_role = working_role
                    and (
                        realtime.is_visible_through_filters(columns, subs.filters)
                        or (
                          action = 'DELETE'
                          and realtime.is_visible_through_filters(old_columns, subs.filters)
                        )
                    )
        ) loop

            if not is_rls_enabled or action = 'DELETE' then
                visible_to_subscription_ids = visible_to_subscription_ids || subscription_id;
            else
                -- Check if RLS allows the role to see the record
                perform
                    -- Trim leading and trailing quotes from working_role because set_config
                    -- doesn't recognize the role as valid if they are included
                    set_config('role', trim(both '"' from working_role::text), true),
                    set_config('request.jwt.claims', claims::text, true);

                execute 'execute walrus_rls_stmt' into subscription_has_access;

                if subscription_has_access then
                    visible_to_subscription_ids = visible_to_subscription_ids || subscription_id;
                end if;
            end if;
        end loop;

        perform set_config('role', null, true);

        return next (
            output,
            is_rls_enabled,
            visible_to_subscription_ids,
            case
                when error_record_exceeds_max_size then array['Error 413: Payload Too Large']
                else '{}'
            end
        )::realtime.wal_rls;

    end if;
end loop;

perform set_config('role', null, true);
end;
$$;


ALTER FUNCTION realtime.apply_rls(wal jsonb, max_record_bytes integer) OWNER TO supabase_admin;

--
-- Name: broadcast_changes(text, text, text, text, text, record, record, text); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION realtime.broadcast_changes(topic_name text, event_name text, operation text, table_name text, table_schema text, new record, old record, level text DEFAULT 'ROW'::text) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
    -- Declare a variable to hold the JSONB representation of the row
    row_data jsonb := '{}'::jsonb;
BEGIN
    IF level = 'STATEMENT' THEN
        RAISE EXCEPTION 'function can only be triggered for each row, not for each statement';
    END IF;
    -- Check the operation type and handle accordingly
    IF operation = 'INSERT' OR operation = 'UPDATE' OR operation = 'DELETE' THEN
        row_data := jsonb_build_object('old_record', OLD, 'record', NEW, 'operation', operation, 'table', table_name, 'schema', table_schema);
        PERFORM realtime.send (row_data, event_name, topic_name);
    ELSE
        RAISE EXCEPTION 'Unexpected operation type: %', operation;
    END IF;
EXCEPTION
    WHEN OTHERS THEN
        RAISE EXCEPTION 'Failed to process the row: %', SQLERRM;
END;

$$;


ALTER FUNCTION realtime.broadcast_changes(topic_name text, event_name text, operation text, table_name text, table_schema text, new record, old record, level text) OWNER TO supabase_admin;

--
-- Name: build_prepared_statement_sql(text, regclass, realtime.wal_column[]); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION realtime.build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]) RETURNS text
    LANGUAGE sql
    AS $$
      /*
      Builds a sql string that, if executed, creates a prepared statement to
      tests retrive a row from *entity* by its primary key columns.
      Example
          select realtime.build_prepared_statement_sql('public.notes', '{"id"}'::text[], '{"bigint"}'::text[])
      */
          select
      'prepare ' || prepared_statement_name || ' as
          select
              exists(
                  select
                      1
                  from
                      ' || entity || '
                  where
                      ' || string_agg(quote_ident(pkc.name) || '=' || quote_nullable(pkc.value #>> '{}') , ' and ') || '
              )'
          from
              unnest(columns) pkc
          where
              pkc.is_pkey
          group by
              entity
      $$;


ALTER FUNCTION realtime.build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]) OWNER TO supabase_admin;

--
-- Name: cast(text, regtype); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION realtime."cast"(val text, type_ regtype) RETURNS jsonb
    LANGUAGE plpgsql IMMUTABLE
    AS $$
    declare
      res jsonb;
    begin
      execute format('select to_jsonb(%L::'|| type_::text || ')', val)  into res;
      return res;
    end
    $$;


ALTER FUNCTION realtime."cast"(val text, type_ regtype) OWNER TO supabase_admin;

--
-- Name: check_equality_op(realtime.equality_op, regtype, text, text); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text) RETURNS boolean
    LANGUAGE plpgsql IMMUTABLE
    AS $$
      /*
      Casts *val_1* and *val_2* as type *type_* and check the *op* condition for truthiness
      */
      declare
          op_symbol text = (
              case
                  when op = 'eq' then '='
                  when op = 'neq' then '!='
                  when op = 'lt' then '<'
                  when op = 'lte' then '<='
                  when op = 'gt' then '>'
                  when op = 'gte' then '>='
                  when op = 'in' then '= any'
                  else 'UNKNOWN OP'
              end
          );
          res boolean;
      begin
          execute format(
              'select %L::'|| type_::text || ' ' || op_symbol
              || ' ( %L::'
              || (
                  case
                      when op = 'in' then type_::text || '[]'
                      else type_::text end
              )
              || ')', val_1, val_2) into res;
          return res;
      end;
      $$;


ALTER FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text) OWNER TO supabase_admin;

--
-- Name: is_visible_through_filters(realtime.wal_column[], realtime.user_defined_filter[]); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION realtime.is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]) RETURNS boolean
    LANGUAGE sql IMMUTABLE
    AS $_$
    /*
    Should the record be visible (true) or filtered out (false) after *filters* are applied
    */
        select
            -- Default to allowed when no filters present
            $2 is null -- no filters. this should not happen because subscriptions has a default
            or array_length($2, 1) is null -- array length of an empty array is null
            or bool_and(
                coalesce(
                    realtime.check_equality_op(
                        op:=f.op,
                        type_:=coalesce(
                            col.type_oid::regtype, -- null when wal2json version <= 2.4
                            col.type_name::regtype
                        ),
                        -- cast jsonb to text
                        val_1:=col.value #>> '{}',
                        val_2:=f.value
                    ),
                    false -- if null, filter does not match
                )
            )
        from
            unnest(filters) f
            join unnest(columns) col
                on f.column_name = col.name;
    $_$;


ALTER FUNCTION realtime.is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]) OWNER TO supabase_admin;

--
-- Name: list_changes(name, name, integer, integer); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION realtime.list_changes(publication name, slot_name name, max_changes integer, max_record_bytes integer) RETURNS SETOF realtime.wal_rls
    LANGUAGE sql
    SET log_min_messages TO 'fatal'
    AS $$
      with pub as (
        select
          concat_ws(
            ',',
            case when bool_or(pubinsert) then 'insert' else null end,
            case when bool_or(pubupdate) then 'update' else null end,
            case when bool_or(pubdelete) then 'delete' else null end
          ) as w2j_actions,
          coalesce(
            string_agg(
              realtime.quote_wal2json(format('%I.%I', schemaname, tablename)::regclass),
              ','
            ) filter (where ppt.tablename is not null and ppt.tablename not like '% %'),
            ''
          ) w2j_add_tables
        from
          pg_publication pp
          left join pg_publication_tables ppt
            on pp.pubname = ppt.pubname
        where
          pp.pubname = publication
        group by
          pp.pubname
        limit 1
      ),
      w2j as (
        select
          x.*, pub.w2j_add_tables
        from
          pub,
          pg_logical_slot_get_changes(
            slot_name, null, max_changes,
            'include-pk', 'true',
            'include-transaction', 'false',
            'include-timestamp', 'true',
            'include-type-oids', 'true',
            'format-version', '2',
            'actions', pub.w2j_actions,
            'add-tables', pub.w2j_add_tables
          ) x
      )
      select
        xyz.wal,
        xyz.is_rls_enabled,
        xyz.subscription_ids,
        xyz.errors
      from
        w2j,
        realtime.apply_rls(
          wal := w2j.data::jsonb,
          max_record_bytes := max_record_bytes
        ) xyz(wal, is_rls_enabled, subscription_ids, errors)
      where
        w2j.w2j_add_tables <> ''
        and xyz.subscription_ids[1] is not null
    $$;


ALTER FUNCTION realtime.list_changes(publication name, slot_name name, max_changes integer, max_record_bytes integer) OWNER TO supabase_admin;

--
-- Name: quote_wal2json(regclass); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION realtime.quote_wal2json(entity regclass) RETURNS text
    LANGUAGE sql IMMUTABLE STRICT
    AS $$
      select
        (
          select string_agg('' || ch,'')
          from unnest(string_to_array(nsp.nspname::text, null)) with ordinality x(ch, idx)
          where
            not (x.idx = 1 and x.ch = '"')
            and not (
              x.idx = array_length(string_to_array(nsp.nspname::text, null), 1)
              and x.ch = '"'
            )
        )
        || '.'
        || (
          select string_agg('' || ch,'')
          from unnest(string_to_array(pc.relname::text, null)) with ordinality x(ch, idx)
          where
            not (x.idx = 1 and x.ch = '"')
            and not (
              x.idx = array_length(string_to_array(nsp.nspname::text, null), 1)
              and x.ch = '"'
            )
          )
      from
        pg_class pc
        join pg_namespace nsp
          on pc.relnamespace = nsp.oid
      where
        pc.oid = entity
    $$;


ALTER FUNCTION realtime.quote_wal2json(entity regclass) OWNER TO supabase_admin;

--
-- Name: send(jsonb, text, text, boolean); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION realtime.send(payload jsonb, event text, topic text, private boolean DEFAULT true) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
  generated_id uuid;
  final_payload jsonb;
BEGIN
  BEGIN
    -- Generate a new UUID for the id
    generated_id := gen_random_uuid();

    -- Check if payload has an 'id' key, if not, add the generated UUID
    IF payload ? 'id' THEN
      final_payload := payload;
    ELSE
      final_payload := jsonb_set(payload, '{id}', to_jsonb(generated_id));
    END IF;

    -- Set the topic configuration
    EXECUTE format('SET LOCAL realtime.topic TO %L', topic);

    -- Attempt to insert the message
    INSERT INTO realtime.messages (id, payload, event, topic, private, extension)
    VALUES (generated_id, final_payload, event, topic, private, 'broadcast');
  EXCEPTION
    WHEN OTHERS THEN
      -- Capture and notify the error
      RAISE WARNING 'ErrorSendingBroadcastMessage: %', SQLERRM;
  END;
END;
$$;


ALTER FUNCTION realtime.send(payload jsonb, event text, topic text, private boolean) OWNER TO supabase_admin;

--
-- Name: subscription_check_filters(); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION realtime.subscription_check_filters() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
    /*
    Validates that the user defined filters for a subscription:
    - refer to valid columns that the claimed role may access
    - values are coercable to the correct column type
    */
    declare
        col_names text[] = coalesce(
                array_agg(c.column_name order by c.ordinal_position),
                '{}'::text[]
            )
            from
                information_schema.columns c
            where
                format('%I.%I', c.table_schema, c.table_name)::regclass = new.entity
                and pg_catalog.has_column_privilege(
                    (new.claims ->> 'role'),
                    format('%I.%I', c.table_schema, c.table_name)::regclass,
                    c.column_name,
                    'SELECT'
                );
        filter realtime.user_defined_filter;
        col_type regtype;

        in_val jsonb;
    begin
        for filter in select * from unnest(new.filters) loop
            -- Filtered column is valid
            if not filter.column_name = any(col_names) then
                raise exception 'invalid column for filter %', filter.column_name;
            end if;

            -- Type is sanitized and safe for string interpolation
            col_type = (
                select atttypid::regtype
                from pg_catalog.pg_attribute
                where attrelid = new.entity
                      and attname = filter.column_name
            );
            if col_type is null then
                raise exception 'failed to lookup type for column %', filter.column_name;
            end if;

            -- Set maximum number of entries for in filter
            if filter.op = 'in'::realtime.equality_op then
                in_val = realtime.cast(filter.value, (col_type::text || '[]')::regtype);
                if coalesce(jsonb_array_length(in_val), 0) > 100 then
                    raise exception 'too many values for `in` filter. Maximum 100';
                end if;
            else
                -- raises an exception if value is not coercable to type
                perform realtime.cast(filter.value, col_type);
            end if;

        end loop;

        -- Apply consistent order to filters so the unique constraint on
        -- (subscription_id, entity, filters) can't be tricked by a different filter order
        new.filters = coalesce(
            array_agg(f order by f.column_name, f.op, f.value),
            '{}'
        ) from unnest(new.filters) f;

        return new;
    end;
    $$;


ALTER FUNCTION realtime.subscription_check_filters() OWNER TO supabase_admin;

--
-- Name: to_regrole(text); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION realtime.to_regrole(role_name text) RETURNS regrole
    LANGUAGE sql IMMUTABLE
    AS $$ select role_name::regrole $$;


ALTER FUNCTION realtime.to_regrole(role_name text) OWNER TO supabase_admin;

--
-- Name: topic(); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION realtime.topic() RETURNS text
    LANGUAGE sql STABLE
    AS $$
select nullif(current_setting('realtime.topic', true), '')::text;
$$;


ALTER FUNCTION realtime.topic() OWNER TO supabase_realtime_admin;

--
-- Name: add_prefixes(text, text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.add_prefixes(_bucket_id text, _name text) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
DECLARE
    prefixes text[];
BEGIN
    prefixes := "storage"."get_prefixes"("_name");

    IF array_length(prefixes, 1) > 0 THEN
        INSERT INTO storage.prefixes (name, bucket_id)
        SELECT UNNEST(prefixes) as name, "_bucket_id" ON CONFLICT DO NOTHING;
    END IF;
END;
$$;


ALTER FUNCTION storage.add_prefixes(_bucket_id text, _name text) OWNER TO supabase_storage_admin;

--
-- Name: can_insert_object(text, text, uuid, jsonb); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.can_insert_object(bucketid text, name text, owner uuid, metadata jsonb) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
  INSERT INTO "storage"."objects" ("bucket_id", "name", "owner", "metadata") VALUES (bucketid, name, owner, metadata);
  -- hack to rollback the successful insert
  RAISE sqlstate 'PT200' using
  message = 'ROLLBACK',
  detail = 'rollback successful insert';
END
$$;


ALTER FUNCTION storage.can_insert_object(bucketid text, name text, owner uuid, metadata jsonb) OWNER TO supabase_storage_admin;

--
-- Name: delete_leaf_prefixes(text[], text[]); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.delete_leaf_prefixes(bucket_ids text[], names text[]) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
DECLARE
    v_rows_deleted integer;
BEGIN
    LOOP
        WITH candidates AS (
            SELECT DISTINCT
                t.bucket_id,
                unnest(storage.get_prefixes(t.name)) AS name
            FROM unnest(bucket_ids, names) AS t(bucket_id, name)
        ),
        uniq AS (
             SELECT
                 bucket_id,
                 name,
                 storage.get_level(name) AS level
             FROM candidates
             WHERE name <> ''
             GROUP BY bucket_id, name
        ),
        leaf AS (
             SELECT
                 p.bucket_id,
                 p.name,
                 p.level
             FROM storage.prefixes AS p
                  JOIN uniq AS u
                       ON u.bucket_id = p.bucket_id
                           AND u.name = p.name
                           AND u.level = p.level
             WHERE NOT EXISTS (
                 SELECT 1
                 FROM storage.objects AS o
                 WHERE o.bucket_id = p.bucket_id
                   AND o.level = p.level + 1
                   AND o.name COLLATE "C" LIKE p.name || '/%'
             )
             AND NOT EXISTS (
                 SELECT 1
                 FROM storage.prefixes AS c
                 WHERE c.bucket_id = p.bucket_id
                   AND c.level = p.level + 1
                   AND c.name COLLATE "C" LIKE p.name || '/%'
             )
        )
        DELETE
        FROM storage.prefixes AS p
            USING leaf AS l
        WHERE p.bucket_id = l.bucket_id
          AND p.name = l.name
          AND p.level = l.level;

        GET DIAGNOSTICS v_rows_deleted = ROW_COUNT;
        EXIT WHEN v_rows_deleted = 0;
    END LOOP;
END;
$$;


ALTER FUNCTION storage.delete_leaf_prefixes(bucket_ids text[], names text[]) OWNER TO supabase_storage_admin;

--
-- Name: delete_prefix(text, text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.delete_prefix(_bucket_id text, _name text) RETURNS boolean
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
BEGIN
    -- Check if we can delete the prefix
    IF EXISTS(
        SELECT FROM "storage"."prefixes"
        WHERE "prefixes"."bucket_id" = "_bucket_id"
          AND level = "storage"."get_level"("_name") + 1
          AND "prefixes"."name" COLLATE "C" LIKE "_name" || '/%'
        LIMIT 1
    )
    OR EXISTS(
        SELECT FROM "storage"."objects"
        WHERE "objects"."bucket_id" = "_bucket_id"
          AND "storage"."get_level"("objects"."name") = "storage"."get_level"("_name") + 1
          AND "objects"."name" COLLATE "C" LIKE "_name" || '/%'
        LIMIT 1
    ) THEN
    -- There are sub-objects, skip deletion
    RETURN false;
    ELSE
        DELETE FROM "storage"."prefixes"
        WHERE "prefixes"."bucket_id" = "_bucket_id"
          AND level = "storage"."get_level"("_name")
          AND "prefixes"."name" = "_name";
        RETURN true;
    END IF;
END;
$$;


ALTER FUNCTION storage.delete_prefix(_bucket_id text, _name text) OWNER TO supabase_storage_admin;

--
-- Name: delete_prefix_hierarchy_trigger(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.delete_prefix_hierarchy_trigger() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    prefix text;
BEGIN
    prefix := "storage"."get_prefix"(OLD."name");

    IF coalesce(prefix, '') != '' THEN
        PERFORM "storage"."delete_prefix"(OLD."bucket_id", prefix);
    END IF;

    RETURN OLD;
END;
$$;


ALTER FUNCTION storage.delete_prefix_hierarchy_trigger() OWNER TO supabase_storage_admin;

--
-- Name: enforce_bucket_name_length(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.enforce_bucket_name_length() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
begin
    if length(new.name) > 100 then
        raise exception 'bucket name "%" is too long (% characters). Max is 100.', new.name, length(new.name);
    end if;
    return new;
end;
$$;


ALTER FUNCTION storage.enforce_bucket_name_length() OWNER TO supabase_storage_admin;

--
-- Name: extension(text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.extension(name text) RETURNS text
    LANGUAGE plpgsql IMMUTABLE
    AS $$
DECLARE
    _parts text[];
    _filename text;
BEGIN
    SELECT string_to_array(name, '/') INTO _parts;
    SELECT _parts[array_length(_parts,1)] INTO _filename;
    RETURN reverse(split_part(reverse(_filename), '.', 1));
END
$$;


ALTER FUNCTION storage.extension(name text) OWNER TO supabase_storage_admin;

--
-- Name: filename(text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.filename(name text) RETURNS text
    LANGUAGE plpgsql
    AS $$
DECLARE
_parts text[];
BEGIN
	select string_to_array(name, '/') into _parts;
	return _parts[array_length(_parts,1)];
END
$$;


ALTER FUNCTION storage.filename(name text) OWNER TO supabase_storage_admin;

--
-- Name: foldername(text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.foldername(name text) RETURNS text[]
    LANGUAGE plpgsql IMMUTABLE
    AS $$
DECLARE
    _parts text[];
BEGIN
    -- Split on "/" to get path segments
    SELECT string_to_array(name, '/') INTO _parts;
    -- Return everything except the last segment
    RETURN _parts[1 : array_length(_parts,1) - 1];
END
$$;


ALTER FUNCTION storage.foldername(name text) OWNER TO supabase_storage_admin;

--
-- Name: get_level(text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.get_level(name text) RETURNS integer
    LANGUAGE sql IMMUTABLE STRICT
    AS $$
SELECT array_length(string_to_array("name", '/'), 1);
$$;


ALTER FUNCTION storage.get_level(name text) OWNER TO supabase_storage_admin;

--
-- Name: get_prefix(text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.get_prefix(name text) RETURNS text
    LANGUAGE sql IMMUTABLE STRICT
    AS $_$
SELECT
    CASE WHEN strpos("name", '/') > 0 THEN
             regexp_replace("name", '[\/]{1}[^\/]+\/?$', '')
         ELSE
             ''
        END;
$_$;


ALTER FUNCTION storage.get_prefix(name text) OWNER TO supabase_storage_admin;

--
-- Name: get_prefixes(text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.get_prefixes(name text) RETURNS text[]
    LANGUAGE plpgsql IMMUTABLE STRICT
    AS $$
DECLARE
    parts text[];
    prefixes text[];
    prefix text;
BEGIN
    -- Split the name into parts by '/'
    parts := string_to_array("name", '/');
    prefixes := '{}';

    -- Construct the prefixes, stopping one level below the last part
    FOR i IN 1..array_length(parts, 1) - 1 LOOP
            prefix := array_to_string(parts[1:i], '/');
            prefixes := array_append(prefixes, prefix);
    END LOOP;

    RETURN prefixes;
END;
$$;


ALTER FUNCTION storage.get_prefixes(name text) OWNER TO supabase_storage_admin;

--
-- Name: get_size_by_bucket(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.get_size_by_bucket() RETURNS TABLE(size bigint, bucket_id text)
    LANGUAGE plpgsql STABLE
    AS $$
BEGIN
    return query
        select sum((metadata->>'size')::bigint) as size, obj.bucket_id
        from "storage".objects as obj
        group by obj.bucket_id;
END
$$;


ALTER FUNCTION storage.get_size_by_bucket() OWNER TO supabase_storage_admin;

--
-- Name: list_multipart_uploads_with_delimiter(text, text, text, integer, text, text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.list_multipart_uploads_with_delimiter(bucket_id text, prefix_param text, delimiter_param text, max_keys integer DEFAULT 100, next_key_token text DEFAULT ''::text, next_upload_token text DEFAULT ''::text) RETURNS TABLE(key text, id text, created_at timestamp with time zone)
    LANGUAGE plpgsql
    AS $_$
BEGIN
    RETURN QUERY EXECUTE
        'SELECT DISTINCT ON(key COLLATE "C") * from (
            SELECT
                CASE
                    WHEN position($2 IN substring(key from length($1) + 1)) > 0 THEN
                        substring(key from 1 for length($1) + position($2 IN substring(key from length($1) + 1)))
                    ELSE
                        key
                END AS key, id, created_at
            FROM
                storage.s3_multipart_uploads
            WHERE
                bucket_id = $5 AND
                key ILIKE $1 || ''%'' AND
                CASE
                    WHEN $4 != '''' AND $6 = '''' THEN
                        CASE
                            WHEN position($2 IN substring(key from length($1) + 1)) > 0 THEN
                                substring(key from 1 for length($1) + position($2 IN substring(key from length($1) + 1))) COLLATE "C" > $4
                            ELSE
                                key COLLATE "C" > $4
                            END
                    ELSE
                        true
                END AND
                CASE
                    WHEN $6 != '''' THEN
                        id COLLATE "C" > $6
                    ELSE
                        true
                    END
            ORDER BY
                key COLLATE "C" ASC, created_at ASC) as e order by key COLLATE "C" LIMIT $3'
        USING prefix_param, delimiter_param, max_keys, next_key_token, bucket_id, next_upload_token;
END;
$_$;


ALTER FUNCTION storage.list_multipart_uploads_with_delimiter(bucket_id text, prefix_param text, delimiter_param text, max_keys integer, next_key_token text, next_upload_token text) OWNER TO supabase_storage_admin;

--
-- Name: list_objects_with_delimiter(text, text, text, integer, text, text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.list_objects_with_delimiter(bucket_id text, prefix_param text, delimiter_param text, max_keys integer DEFAULT 100, start_after text DEFAULT ''::text, next_token text DEFAULT ''::text) RETURNS TABLE(name text, id uuid, metadata jsonb, updated_at timestamp with time zone)
    LANGUAGE plpgsql
    AS $_$
BEGIN
    RETURN QUERY EXECUTE
        'SELECT DISTINCT ON(name COLLATE "C") * from (
            SELECT
                CASE
                    WHEN position($2 IN substring(name from length($1) + 1)) > 0 THEN
                        substring(name from 1 for length($1) + position($2 IN substring(name from length($1) + 1)))
                    ELSE
                        name
                END AS name, id, metadata, updated_at
            FROM
                storage.objects
            WHERE
                bucket_id = $5 AND
                name ILIKE $1 || ''%'' AND
                CASE
                    WHEN $6 != '''' THEN
                    name COLLATE "C" > $6
                ELSE true END
                AND CASE
                    WHEN $4 != '''' THEN
                        CASE
                            WHEN position($2 IN substring(name from length($1) + 1)) > 0 THEN
                                substring(name from 1 for length($1) + position($2 IN substring(name from length($1) + 1))) COLLATE "C" > $4
                            ELSE
                                name COLLATE "C" > $4
                            END
                    ELSE
                        true
                END
            ORDER BY
                name COLLATE "C" ASC) as e order by name COLLATE "C" LIMIT $3'
        USING prefix_param, delimiter_param, max_keys, next_token, bucket_id, start_after;
END;
$_$;


ALTER FUNCTION storage.list_objects_with_delimiter(bucket_id text, prefix_param text, delimiter_param text, max_keys integer, start_after text, next_token text) OWNER TO supabase_storage_admin;

--
-- Name: lock_top_prefixes(text[], text[]); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.lock_top_prefixes(bucket_ids text[], names text[]) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
DECLARE
    v_bucket text;
    v_top text;
BEGIN
    FOR v_bucket, v_top IN
        SELECT DISTINCT t.bucket_id,
            split_part(t.name, '/', 1) AS top
        FROM unnest(bucket_ids, names) AS t(bucket_id, name)
        WHERE t.name <> ''
        ORDER BY 1, 2
        LOOP
            PERFORM pg_advisory_xact_lock(hashtextextended(v_bucket || '/' || v_top, 0));
        END LOOP;
END;
$$;


ALTER FUNCTION storage.lock_top_prefixes(bucket_ids text[], names text[]) OWNER TO supabase_storage_admin;

--
-- Name: objects_delete_cleanup(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.objects_delete_cleanup() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
DECLARE
    v_bucket_ids text[];
    v_names      text[];
BEGIN
    IF current_setting('storage.gc.prefixes', true) = '1' THEN
        RETURN NULL;
    END IF;

    PERFORM set_config('storage.gc.prefixes', '1', true);

    SELECT COALESCE(array_agg(d.bucket_id), '{}'),
           COALESCE(array_agg(d.name), '{}')
    INTO v_bucket_ids, v_names
    FROM deleted AS d
    WHERE d.name <> '';

    PERFORM storage.lock_top_prefixes(v_bucket_ids, v_names);
    PERFORM storage.delete_leaf_prefixes(v_bucket_ids, v_names);

    RETURN NULL;
END;
$$;


ALTER FUNCTION storage.objects_delete_cleanup() OWNER TO supabase_storage_admin;

--
-- Name: objects_insert_prefix_trigger(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.objects_insert_prefix_trigger() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    PERFORM "storage"."add_prefixes"(NEW."bucket_id", NEW."name");
    NEW.level := "storage"."get_level"(NEW."name");

    RETURN NEW;
END;
$$;


ALTER FUNCTION storage.objects_insert_prefix_trigger() OWNER TO supabase_storage_admin;

--
-- Name: objects_update_cleanup(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.objects_update_cleanup() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
DECLARE
    -- NEW - OLD (destinations to create prefixes for)
    v_add_bucket_ids text[];
    v_add_names      text[];

    -- OLD - NEW (sources to prune)
    v_src_bucket_ids text[];
    v_src_names      text[];
BEGIN
    IF TG_OP <> 'UPDATE' THEN
        RETURN NULL;
    END IF;

    -- 1) Compute NEW−OLD (added paths) and OLD−NEW (moved-away paths)
    WITH added AS (
        SELECT n.bucket_id, n.name
        FROM new_rows n
        WHERE n.name <> '' AND position('/' in n.name) > 0
        EXCEPT
        SELECT o.bucket_id, o.name FROM old_rows o WHERE o.name <> ''
    ),
    moved AS (
         SELECT o.bucket_id, o.name
         FROM old_rows o
         WHERE o.name <> ''
         EXCEPT
         SELECT n.bucket_id, n.name FROM new_rows n WHERE n.name <> ''
    )
    SELECT
        -- arrays for ADDED (dest) in stable order
        COALESCE( (SELECT array_agg(a.bucket_id ORDER BY a.bucket_id, a.name) FROM added a), '{}' ),
        COALESCE( (SELECT array_agg(a.name      ORDER BY a.bucket_id, a.name) FROM added a), '{}' ),
        -- arrays for MOVED (src) in stable order
        COALESCE( (SELECT array_agg(m.bucket_id ORDER BY m.bucket_id, m.name) FROM moved m), '{}' ),
        COALESCE( (SELECT array_agg(m.name      ORDER BY m.bucket_id, m.name) FROM moved m), '{}' )
    INTO v_add_bucket_ids, v_add_names, v_src_bucket_ids, v_src_names;

    -- Nothing to do?
    IF (array_length(v_add_bucket_ids, 1) IS NULL) AND (array_length(v_src_bucket_ids, 1) IS NULL) THEN
        RETURN NULL;
    END IF;

    -- 2) Take per-(bucket, top) locks: ALL prefixes in consistent global order to prevent deadlocks
    DECLARE
        v_all_bucket_ids text[];
        v_all_names text[];
    BEGIN
        -- Combine source and destination arrays for consistent lock ordering
        v_all_bucket_ids := COALESCE(v_src_bucket_ids, '{}') || COALESCE(v_add_bucket_ids, '{}');
        v_all_names := COALESCE(v_src_names, '{}') || COALESCE(v_add_names, '{}');

        -- Single lock call ensures consistent global ordering across all transactions
        IF array_length(v_all_bucket_ids, 1) IS NOT NULL THEN
            PERFORM storage.lock_top_prefixes(v_all_bucket_ids, v_all_names);
        END IF;
    END;

    -- 3) Create destination prefixes (NEW−OLD) BEFORE pruning sources
    IF array_length(v_add_bucket_ids, 1) IS NOT NULL THEN
        WITH candidates AS (
            SELECT DISTINCT t.bucket_id, unnest(storage.get_prefixes(t.name)) AS name
            FROM unnest(v_add_bucket_ids, v_add_names) AS t(bucket_id, name)
            WHERE name <> ''
        )
        INSERT INTO storage.prefixes (bucket_id, name)
        SELECT c.bucket_id, c.name
        FROM candidates c
        ON CONFLICT DO NOTHING;
    END IF;

    -- 4) Prune source prefixes bottom-up for OLD−NEW
    IF array_length(v_src_bucket_ids, 1) IS NOT NULL THEN
        -- re-entrancy guard so DELETE on prefixes won't recurse
        IF current_setting('storage.gc.prefixes', true) <> '1' THEN
            PERFORM set_config('storage.gc.prefixes', '1', true);
        END IF;

        PERFORM storage.delete_leaf_prefixes(v_src_bucket_ids, v_src_names);
    END IF;

    RETURN NULL;
END;
$$;


ALTER FUNCTION storage.objects_update_cleanup() OWNER TO supabase_storage_admin;

--
-- Name: objects_update_level_trigger(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.objects_update_level_trigger() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Ensure this is an update operation and the name has changed
    IF TG_OP = 'UPDATE' AND (NEW."name" <> OLD."name" OR NEW."bucket_id" <> OLD."bucket_id") THEN
        -- Set the new level
        NEW."level" := "storage"."get_level"(NEW."name");
    END IF;
    RETURN NEW;
END;
$$;


ALTER FUNCTION storage.objects_update_level_trigger() OWNER TO supabase_storage_admin;

--
-- Name: objects_update_prefix_trigger(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.objects_update_prefix_trigger() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    old_prefixes TEXT[];
BEGIN
    -- Ensure this is an update operation and the name has changed
    IF TG_OP = 'UPDATE' AND (NEW."name" <> OLD."name" OR NEW."bucket_id" <> OLD."bucket_id") THEN
        -- Retrieve old prefixes
        old_prefixes := "storage"."get_prefixes"(OLD."name");

        -- Remove old prefixes that are only used by this object
        WITH all_prefixes as (
            SELECT unnest(old_prefixes) as prefix
        ),
        can_delete_prefixes as (
             SELECT prefix
             FROM all_prefixes
             WHERE NOT EXISTS (
                 SELECT 1 FROM "storage"."objects"
                 WHERE "bucket_id" = OLD."bucket_id"
                   AND "name" <> OLD."name"
                   AND "name" LIKE (prefix || '%')
             )
         )
        DELETE FROM "storage"."prefixes" WHERE name IN (SELECT prefix FROM can_delete_prefixes);

        -- Add new prefixes
        PERFORM "storage"."add_prefixes"(NEW."bucket_id", NEW."name");
    END IF;
    -- Set the new level
    NEW."level" := "storage"."get_level"(NEW."name");

    RETURN NEW;
END;
$$;


ALTER FUNCTION storage.objects_update_prefix_trigger() OWNER TO supabase_storage_admin;

--
-- Name: operation(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.operation() RETURNS text
    LANGUAGE plpgsql STABLE
    AS $$
BEGIN
    RETURN current_setting('storage.operation', true);
END;
$$;


ALTER FUNCTION storage.operation() OWNER TO supabase_storage_admin;

--
-- Name: prefixes_delete_cleanup(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.prefixes_delete_cleanup() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
DECLARE
    v_bucket_ids text[];
    v_names      text[];
BEGIN
    IF current_setting('storage.gc.prefixes', true) = '1' THEN
        RETURN NULL;
    END IF;

    PERFORM set_config('storage.gc.prefixes', '1', true);

    SELECT COALESCE(array_agg(d.bucket_id), '{}'),
           COALESCE(array_agg(d.name), '{}')
    INTO v_bucket_ids, v_names
    FROM deleted AS d
    WHERE d.name <> '';

    PERFORM storage.lock_top_prefixes(v_bucket_ids, v_names);
    PERFORM storage.delete_leaf_prefixes(v_bucket_ids, v_names);

    RETURN NULL;
END;
$$;


ALTER FUNCTION storage.prefixes_delete_cleanup() OWNER TO supabase_storage_admin;

--
-- Name: prefixes_insert_trigger(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.prefixes_insert_trigger() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    PERFORM "storage"."add_prefixes"(NEW."bucket_id", NEW."name");
    RETURN NEW;
END;
$$;


ALTER FUNCTION storage.prefixes_insert_trigger() OWNER TO supabase_storage_admin;

--
-- Name: search(text, text, integer, integer, integer, text, text, text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.search(prefix text, bucketname text, limits integer DEFAULT 100, levels integer DEFAULT 1, offsets integer DEFAULT 0, search text DEFAULT ''::text, sortcolumn text DEFAULT 'name'::text, sortorder text DEFAULT 'asc'::text) RETURNS TABLE(name text, id uuid, updated_at timestamp with time zone, created_at timestamp with time zone, last_accessed_at timestamp with time zone, metadata jsonb)
    LANGUAGE plpgsql
    AS $$
declare
    can_bypass_rls BOOLEAN;
begin
    SELECT rolbypassrls
    INTO can_bypass_rls
    FROM pg_roles
    WHERE rolname = coalesce(nullif(current_setting('role', true), 'none'), current_user);

    IF can_bypass_rls THEN
        RETURN QUERY SELECT * FROM storage.search_v1_optimised(prefix, bucketname, limits, levels, offsets, search, sortcolumn, sortorder);
    ELSE
        RETURN QUERY SELECT * FROM storage.search_legacy_v1(prefix, bucketname, limits, levels, offsets, search, sortcolumn, sortorder);
    END IF;
end;
$$;


ALTER FUNCTION storage.search(prefix text, bucketname text, limits integer, levels integer, offsets integer, search text, sortcolumn text, sortorder text) OWNER TO supabase_storage_admin;

--
-- Name: search_legacy_v1(text, text, integer, integer, integer, text, text, text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.search_legacy_v1(prefix text, bucketname text, limits integer DEFAULT 100, levels integer DEFAULT 1, offsets integer DEFAULT 0, search text DEFAULT ''::text, sortcolumn text DEFAULT 'name'::text, sortorder text DEFAULT 'asc'::text) RETURNS TABLE(name text, id uuid, updated_at timestamp with time zone, created_at timestamp with time zone, last_accessed_at timestamp with time zone, metadata jsonb)
    LANGUAGE plpgsql STABLE
    AS $_$
declare
    v_order_by text;
    v_sort_order text;
begin
    case
        when sortcolumn = 'name' then
            v_order_by = 'name';
        when sortcolumn = 'updated_at' then
            v_order_by = 'updated_at';
        when sortcolumn = 'created_at' then
            v_order_by = 'created_at';
        when sortcolumn = 'last_accessed_at' then
            v_order_by = 'last_accessed_at';
        else
            v_order_by = 'name';
        end case;

    case
        when sortorder = 'asc' then
            v_sort_order = 'asc';
        when sortorder = 'desc' then
            v_sort_order = 'desc';
        else
            v_sort_order = 'asc';
        end case;

    v_order_by = v_order_by || ' ' || v_sort_order;

    return query execute
        'with folders as (
           select path_tokens[$1] as folder
           from storage.objects
             where objects.name ilike $2 || $3 || ''%''
               and bucket_id = $4
               and array_length(objects.path_tokens, 1) <> $1
           group by folder
           order by folder ' || v_sort_order || '
     )
     (select folder as "name",
            null as id,
            null as updated_at,
            null as created_at,
            null as last_accessed_at,
            null as metadata from folders)
     union all
     (select path_tokens[$1] as "name",
            id,
            updated_at,
            created_at,
            last_accessed_at,
            metadata
     from storage.objects
     where objects.name ilike $2 || $3 || ''%''
       and bucket_id = $4
       and array_length(objects.path_tokens, 1) = $1
     order by ' || v_order_by || ')
     limit $5
     offset $6' using levels, prefix, search, bucketname, limits, offsets;
end;
$_$;


ALTER FUNCTION storage.search_legacy_v1(prefix text, bucketname text, limits integer, levels integer, offsets integer, search text, sortcolumn text, sortorder text) OWNER TO supabase_storage_admin;

--
-- Name: search_v1_optimised(text, text, integer, integer, integer, text, text, text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.search_v1_optimised(prefix text, bucketname text, limits integer DEFAULT 100, levels integer DEFAULT 1, offsets integer DEFAULT 0, search text DEFAULT ''::text, sortcolumn text DEFAULT 'name'::text, sortorder text DEFAULT 'asc'::text) RETURNS TABLE(name text, id uuid, updated_at timestamp with time zone, created_at timestamp with time zone, last_accessed_at timestamp with time zone, metadata jsonb)
    LANGUAGE plpgsql STABLE
    AS $_$
declare
    v_order_by text;
    v_sort_order text;
begin
    case
        when sortcolumn = 'name' then
            v_order_by = 'name';
        when sortcolumn = 'updated_at' then
            v_order_by = 'updated_at';
        when sortcolumn = 'created_at' then
            v_order_by = 'created_at';
        when sortcolumn = 'last_accessed_at' then
            v_order_by = 'last_accessed_at';
        else
            v_order_by = 'name';
        end case;

    case
        when sortorder = 'asc' then
            v_sort_order = 'asc';
        when sortorder = 'desc' then
            v_sort_order = 'desc';
        else
            v_sort_order = 'asc';
        end case;

    v_order_by = v_order_by || ' ' || v_sort_order;

    return query execute
        'with folders as (
           select (string_to_array(name, ''/''))[level] as name
           from storage.prefixes
             where lower(prefixes.name) like lower($2 || $3) || ''%''
               and bucket_id = $4
               and level = $1
           order by name ' || v_sort_order || '
     )
     (select name,
            null as id,
            null as updated_at,
            null as created_at,
            null as last_accessed_at,
            null as metadata from folders)
     union all
     (select path_tokens[level] as "name",
            id,
            updated_at,
            created_at,
            last_accessed_at,
            metadata
     from storage.objects
     where lower(objects.name) like lower($2 || $3) || ''%''
       and bucket_id = $4
       and level = $1
     order by ' || v_order_by || ')
     limit $5
     offset $6' using levels, prefix, search, bucketname, limits, offsets;
end;
$_$;


ALTER FUNCTION storage.search_v1_optimised(prefix text, bucketname text, limits integer, levels integer, offsets integer, search text, sortcolumn text, sortorder text) OWNER TO supabase_storage_admin;

--
-- Name: search_v2(text, text, integer, integer, text, text, text, text); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.search_v2(prefix text, bucket_name text, limits integer DEFAULT 100, levels integer DEFAULT 1, start_after text DEFAULT ''::text, sort_order text DEFAULT 'asc'::text, sort_column text DEFAULT 'name'::text, sort_column_after text DEFAULT ''::text) RETURNS TABLE(key text, name text, id uuid, updated_at timestamp with time zone, created_at timestamp with time zone, last_accessed_at timestamp with time zone, metadata jsonb)
    LANGUAGE plpgsql STABLE
    AS $_$
DECLARE
    sort_col text;
    sort_ord text;
    cursor_op text;
    cursor_expr text;
    sort_expr text;
BEGIN
    -- Validate sort_order
    sort_ord := lower(sort_order);
    IF sort_ord NOT IN ('asc', 'desc') THEN
        sort_ord := 'asc';
    END IF;

    -- Determine cursor comparison operator
    IF sort_ord = 'asc' THEN
        cursor_op := '>';
    ELSE
        cursor_op := '<';
    END IF;
    
    sort_col := lower(sort_column);
    -- Validate sort column  
    IF sort_col IN ('updated_at', 'created_at') THEN
        cursor_expr := format(
            '($5 = '''' OR ROW(date_trunc(''milliseconds'', %I), name COLLATE "C") %s ROW(COALESCE(NULLIF($6, '''')::timestamptz, ''epoch''::timestamptz), $5))',
            sort_col, cursor_op
        );
        sort_expr := format(
            'COALESCE(date_trunc(''milliseconds'', %I), ''epoch''::timestamptz) %s, name COLLATE "C" %s',
            sort_col, sort_ord, sort_ord
        );
    ELSE
        cursor_expr := format('($5 = '''' OR name COLLATE "C" %s $5)', cursor_op);
        sort_expr := format('name COLLATE "C" %s', sort_ord);
    END IF;

    RETURN QUERY EXECUTE format(
        $sql$
        SELECT * FROM (
            (
                SELECT
                    split_part(name, '/', $4) AS key,
                    name,
                    NULL::uuid AS id,
                    updated_at,
                    created_at,
                    NULL::timestamptz AS last_accessed_at,
                    NULL::jsonb AS metadata
                FROM storage.prefixes
                WHERE name COLLATE "C" LIKE $1 || '%%'
                    AND bucket_id = $2
                    AND level = $4
                    AND %s
                ORDER BY %s
                LIMIT $3
            )
            UNION ALL
            (
                SELECT
                    split_part(name, '/', $4) AS key,
                    name,
                    id,
                    updated_at,
                    created_at,
                    last_accessed_at,
                    metadata
                FROM storage.objects
                WHERE name COLLATE "C" LIKE $1 || '%%'
                    AND bucket_id = $2
                    AND level = $4
                    AND %s
                ORDER BY %s
                LIMIT $3
            )
        ) obj
        ORDER BY %s
        LIMIT $3
        $sql$,
        cursor_expr,    -- prefixes WHERE
        sort_expr,      -- prefixes ORDER BY
        cursor_expr,    -- objects WHERE
        sort_expr,      -- objects ORDER BY
        sort_expr       -- final ORDER BY
    )
    USING prefix, bucket_name, limits, levels, start_after, sort_column_after;
END;
$_$;


ALTER FUNCTION storage.search_v2(prefix text, bucket_name text, limits integer, levels integer, start_after text, sort_order text, sort_column text, sort_column_after text) OWNER TO supabase_storage_admin;

--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION storage.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW; 
END;
$$;


ALTER FUNCTION storage.update_updated_at_column() OWNER TO supabase_storage_admin;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: audit_log_entries; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.audit_log_entries (
    instance_id uuid,
    id uuid NOT NULL,
    payload json,
    created_at timestamp with time zone,
    ip_address character varying(64) DEFAULT ''::character varying NOT NULL
);


ALTER TABLE auth.audit_log_entries OWNER TO supabase_auth_admin;

--
-- Name: TABLE audit_log_entries; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.audit_log_entries IS 'Auth: Audit trail for user actions.';


--
-- Name: flow_state; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.flow_state (
    id uuid NOT NULL,
    user_id uuid,
    auth_code text NOT NULL,
    code_challenge_method auth.code_challenge_method NOT NULL,
    code_challenge text NOT NULL,
    provider_type text NOT NULL,
    provider_access_token text,
    provider_refresh_token text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    authentication_method text NOT NULL,
    auth_code_issued_at timestamp with time zone
);


ALTER TABLE auth.flow_state OWNER TO supabase_auth_admin;

--
-- Name: TABLE flow_state; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.flow_state IS 'stores metadata for pkce logins';


--
-- Name: identities; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.identities (
    provider_id text NOT NULL,
    user_id uuid NOT NULL,
    identity_data jsonb NOT NULL,
    provider text NOT NULL,
    last_sign_in_at timestamp with time zone,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    email text GENERATED ALWAYS AS (lower((identity_data ->> 'email'::text))) STORED,
    id uuid DEFAULT gen_random_uuid() NOT NULL
);


ALTER TABLE auth.identities OWNER TO supabase_auth_admin;

--
-- Name: TABLE identities; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.identities IS 'Auth: Stores identities associated to a user.';


--
-- Name: COLUMN identities.email; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN auth.identities.email IS 'Auth: Email is a generated column that references the optional email property in the identity_data';


--
-- Name: instances; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.instances (
    id uuid NOT NULL,
    uuid uuid,
    raw_base_config text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE auth.instances OWNER TO supabase_auth_admin;

--
-- Name: TABLE instances; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.instances IS 'Auth: Manages users across multiple sites.';


--
-- Name: mfa_amr_claims; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.mfa_amr_claims (
    session_id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    authentication_method text NOT NULL,
    id uuid NOT NULL
);


ALTER TABLE auth.mfa_amr_claims OWNER TO supabase_auth_admin;

--
-- Name: TABLE mfa_amr_claims; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.mfa_amr_claims IS 'auth: stores authenticator method reference claims for multi factor authentication';


--
-- Name: mfa_challenges; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.mfa_challenges (
    id uuid NOT NULL,
    factor_id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    verified_at timestamp with time zone,
    ip_address inet NOT NULL,
    otp_code text,
    web_authn_session_data jsonb
);


ALTER TABLE auth.mfa_challenges OWNER TO supabase_auth_admin;

--
-- Name: TABLE mfa_challenges; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.mfa_challenges IS 'auth: stores metadata about challenge requests made';


--
-- Name: mfa_factors; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.mfa_factors (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    friendly_name text,
    factor_type auth.factor_type NOT NULL,
    status auth.factor_status NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    secret text,
    phone text,
    last_challenged_at timestamp with time zone,
    web_authn_credential jsonb,
    web_authn_aaguid uuid,
    last_webauthn_challenge_data jsonb
);


ALTER TABLE auth.mfa_factors OWNER TO supabase_auth_admin;

--
-- Name: TABLE mfa_factors; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.mfa_factors IS 'auth: stores metadata about factors';


--
-- Name: COLUMN mfa_factors.last_webauthn_challenge_data; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN auth.mfa_factors.last_webauthn_challenge_data IS 'Stores the latest WebAuthn challenge data including attestation/assertion for customer verification';


--
-- Name: oauth_authorizations; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.oauth_authorizations (
    id uuid NOT NULL,
    authorization_id text NOT NULL,
    client_id uuid NOT NULL,
    user_id uuid,
    redirect_uri text NOT NULL,
    scope text NOT NULL,
    state text,
    resource text,
    code_challenge text,
    code_challenge_method auth.code_challenge_method,
    response_type auth.oauth_response_type DEFAULT 'code'::auth.oauth_response_type NOT NULL,
    status auth.oauth_authorization_status DEFAULT 'pending'::auth.oauth_authorization_status NOT NULL,
    authorization_code text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone DEFAULT (now() + '00:03:00'::interval) NOT NULL,
    approved_at timestamp with time zone,
    CONSTRAINT oauth_authorizations_authorization_code_length CHECK ((char_length(authorization_code) <= 255)),
    CONSTRAINT oauth_authorizations_code_challenge_length CHECK ((char_length(code_challenge) <= 128)),
    CONSTRAINT oauth_authorizations_expires_at_future CHECK ((expires_at > created_at)),
    CONSTRAINT oauth_authorizations_redirect_uri_length CHECK ((char_length(redirect_uri) <= 2048)),
    CONSTRAINT oauth_authorizations_resource_length CHECK ((char_length(resource) <= 2048)),
    CONSTRAINT oauth_authorizations_scope_length CHECK ((char_length(scope) <= 4096)),
    CONSTRAINT oauth_authorizations_state_length CHECK ((char_length(state) <= 4096))
);


ALTER TABLE auth.oauth_authorizations OWNER TO supabase_auth_admin;

--
-- Name: oauth_clients; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.oauth_clients (
    id uuid NOT NULL,
    client_secret_hash text,
    registration_type auth.oauth_registration_type NOT NULL,
    redirect_uris text NOT NULL,
    grant_types text NOT NULL,
    client_name text,
    client_uri text,
    logo_uri text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    client_type auth.oauth_client_type DEFAULT 'confidential'::auth.oauth_client_type NOT NULL,
    CONSTRAINT oauth_clients_client_name_length CHECK ((char_length(client_name) <= 1024)),
    CONSTRAINT oauth_clients_client_uri_length CHECK ((char_length(client_uri) <= 2048)),
    CONSTRAINT oauth_clients_logo_uri_length CHECK ((char_length(logo_uri) <= 2048))
);


ALTER TABLE auth.oauth_clients OWNER TO supabase_auth_admin;

--
-- Name: oauth_consents; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.oauth_consents (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    client_id uuid NOT NULL,
    scopes text NOT NULL,
    granted_at timestamp with time zone DEFAULT now() NOT NULL,
    revoked_at timestamp with time zone,
    CONSTRAINT oauth_consents_revoked_after_granted CHECK (((revoked_at IS NULL) OR (revoked_at >= granted_at))),
    CONSTRAINT oauth_consents_scopes_length CHECK ((char_length(scopes) <= 2048)),
    CONSTRAINT oauth_consents_scopes_not_empty CHECK ((char_length(TRIM(BOTH FROM scopes)) > 0))
);


ALTER TABLE auth.oauth_consents OWNER TO supabase_auth_admin;

--
-- Name: one_time_tokens; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.one_time_tokens (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    token_type auth.one_time_token_type NOT NULL,
    token_hash text NOT NULL,
    relates_to text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    CONSTRAINT one_time_tokens_token_hash_check CHECK ((char_length(token_hash) > 0))
);


ALTER TABLE auth.one_time_tokens OWNER TO supabase_auth_admin;

--
-- Name: refresh_tokens; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.refresh_tokens (
    instance_id uuid,
    id bigint NOT NULL,
    token character varying(255),
    user_id character varying(255),
    revoked boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    parent character varying(255),
    session_id uuid
);


ALTER TABLE auth.refresh_tokens OWNER TO supabase_auth_admin;

--
-- Name: TABLE refresh_tokens; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.refresh_tokens IS 'Auth: Store of tokens used to refresh JWT tokens once they expire.';


--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE; Schema: auth; Owner: supabase_auth_admin
--

CREATE SEQUENCE auth.refresh_tokens_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE auth.refresh_tokens_id_seq OWNER TO supabase_auth_admin;

--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: auth; Owner: supabase_auth_admin
--

ALTER SEQUENCE auth.refresh_tokens_id_seq OWNED BY auth.refresh_tokens.id;


--
-- Name: saml_providers; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.saml_providers (
    id uuid NOT NULL,
    sso_provider_id uuid NOT NULL,
    entity_id text NOT NULL,
    metadata_xml text NOT NULL,
    metadata_url text,
    attribute_mapping jsonb,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    name_id_format text,
    CONSTRAINT "entity_id not empty" CHECK ((char_length(entity_id) > 0)),
    CONSTRAINT "metadata_url not empty" CHECK (((metadata_url = NULL::text) OR (char_length(metadata_url) > 0))),
    CONSTRAINT "metadata_xml not empty" CHECK ((char_length(metadata_xml) > 0))
);


ALTER TABLE auth.saml_providers OWNER TO supabase_auth_admin;

--
-- Name: TABLE saml_providers; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.saml_providers IS 'Auth: Manages SAML Identity Provider connections.';


--
-- Name: saml_relay_states; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.saml_relay_states (
    id uuid NOT NULL,
    sso_provider_id uuid NOT NULL,
    request_id text NOT NULL,
    for_email text,
    redirect_to text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    flow_state_id uuid,
    CONSTRAINT "request_id not empty" CHECK ((char_length(request_id) > 0))
);


ALTER TABLE auth.saml_relay_states OWNER TO supabase_auth_admin;

--
-- Name: TABLE saml_relay_states; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.saml_relay_states IS 'Auth: Contains SAML Relay State information for each Service Provider initiated login.';


--
-- Name: schema_migrations; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.schema_migrations (
    version character varying(255) NOT NULL
);


ALTER TABLE auth.schema_migrations OWNER TO supabase_auth_admin;

--
-- Name: TABLE schema_migrations; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.schema_migrations IS 'Auth: Manages updates to the auth system.';


--
-- Name: sessions; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.sessions (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    factor_id uuid,
    aal auth.aal_level,
    not_after timestamp with time zone,
    refreshed_at timestamp without time zone,
    user_agent text,
    ip inet,
    tag text,
    oauth_client_id uuid,
    refresh_token_hmac_key text,
    refresh_token_counter bigint
);


ALTER TABLE auth.sessions OWNER TO supabase_auth_admin;

--
-- Name: TABLE sessions; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.sessions IS 'Auth: Stores session data associated to a user.';


--
-- Name: COLUMN sessions.not_after; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN auth.sessions.not_after IS 'Auth: Not after is a nullable column that contains a timestamp after which the session should be regarded as expired.';


--
-- Name: COLUMN sessions.refresh_token_hmac_key; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN auth.sessions.refresh_token_hmac_key IS 'Holds a HMAC-SHA256 key used to sign refresh tokens for this session.';


--
-- Name: COLUMN sessions.refresh_token_counter; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN auth.sessions.refresh_token_counter IS 'Holds the ID (counter) of the last issued refresh token.';


--
-- Name: sso_domains; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.sso_domains (
    id uuid NOT NULL,
    sso_provider_id uuid NOT NULL,
    domain text NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    CONSTRAINT "domain not empty" CHECK ((char_length(domain) > 0))
);


ALTER TABLE auth.sso_domains OWNER TO supabase_auth_admin;

--
-- Name: TABLE sso_domains; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.sso_domains IS 'Auth: Manages SSO email address domain mapping to an SSO Identity Provider.';


--
-- Name: sso_providers; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.sso_providers (
    id uuid NOT NULL,
    resource_id text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    disabled boolean,
    CONSTRAINT "resource_id not empty" CHECK (((resource_id = NULL::text) OR (char_length(resource_id) > 0)))
);


ALTER TABLE auth.sso_providers OWNER TO supabase_auth_admin;

--
-- Name: TABLE sso_providers; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.sso_providers IS 'Auth: Manages SSO identity provider information; see saml_providers for SAML.';


--
-- Name: COLUMN sso_providers.resource_id; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN auth.sso_providers.resource_id IS 'Auth: Uniquely identifies a SSO provider according to a user-chosen resource ID (case insensitive), useful in infrastructure as code.';


--
-- Name: users; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE auth.users (
    instance_id uuid,
    id uuid NOT NULL,
    aud character varying(255),
    role character varying(255),
    email character varying(255),
    encrypted_password character varying(255),
    email_confirmed_at timestamp with time zone,
    invited_at timestamp with time zone,
    confirmation_token character varying(255),
    confirmation_sent_at timestamp with time zone,
    recovery_token character varying(255),
    recovery_sent_at timestamp with time zone,
    email_change_token_new character varying(255),
    email_change character varying(255),
    email_change_sent_at timestamp with time zone,
    last_sign_in_at timestamp with time zone,
    raw_app_meta_data jsonb,
    raw_user_meta_data jsonb,
    is_super_admin boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    phone text DEFAULT NULL::character varying,
    phone_confirmed_at timestamp with time zone,
    phone_change text DEFAULT ''::character varying,
    phone_change_token character varying(255) DEFAULT ''::character varying,
    phone_change_sent_at timestamp with time zone,
    confirmed_at timestamp with time zone GENERATED ALWAYS AS (LEAST(email_confirmed_at, phone_confirmed_at)) STORED,
    email_change_token_current character varying(255) DEFAULT ''::character varying,
    email_change_confirm_status smallint DEFAULT 0,
    banned_until timestamp with time zone,
    reauthentication_token character varying(255) DEFAULT ''::character varying,
    reauthentication_sent_at timestamp with time zone,
    is_sso_user boolean DEFAULT false NOT NULL,
    deleted_at timestamp with time zone,
    is_anonymous boolean DEFAULT false NOT NULL,
    CONSTRAINT users_email_change_confirm_status_check CHECK (((email_change_confirm_status >= 0) AND (email_change_confirm_status <= 2)))
);


ALTER TABLE auth.users OWNER TO supabase_auth_admin;

--
-- Name: TABLE users; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE auth.users IS 'Auth: Stores user login data within a secure schema.';


--
-- Name: COLUMN users.is_sso_user; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN auth.users.is_sso_user IS 'Auth: Set this column to true when the account comes from SSO. These accounts can have duplicate emails.';


--
-- Name: auth_group; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auth_group (
    id integer NOT NULL,
    name character varying(150) NOT NULL
);


ALTER TABLE public.auth_group OWNER TO postgres;

--
-- Name: auth_group_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.auth_group ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.auth_group_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: auth_group_permissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auth_group_permissions (
    id bigint NOT NULL,
    group_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_group_permissions OWNER TO postgres;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.auth_group_permissions ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.auth_group_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: auth_permission; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auth_permission (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    content_type_id integer NOT NULL,
    codename character varying(100) NOT NULL
);


ALTER TABLE public.auth_permission OWNER TO postgres;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.auth_permission ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.auth_permission_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: auth_user; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auth_user (
    id integer NOT NULL,
    password character varying(128) NOT NULL,
    last_login timestamp with time zone,
    is_superuser boolean NOT NULL,
    username character varying(150) NOT NULL,
    first_name character varying(150) NOT NULL,
    last_name character varying(150) NOT NULL,
    email character varying(254) NOT NULL,
    is_staff boolean NOT NULL,
    is_active boolean NOT NULL,
    date_joined timestamp with time zone NOT NULL
);


ALTER TABLE public.auth_user OWNER TO postgres;

--
-- Name: auth_user_groups; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auth_user_groups (
    id bigint NOT NULL,
    user_id integer NOT NULL,
    group_id integer NOT NULL
);


ALTER TABLE public.auth_user_groups OWNER TO postgres;

--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.auth_user_groups ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.auth_user_groups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: auth_user_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.auth_user ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.auth_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: auth_user_user_permissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auth_user_user_permissions (
    id bigint NOT NULL,
    user_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_user_user_permissions OWNER TO postgres;

--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.auth_user_user_permissions ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.auth_user_user_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: core_announcement; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.core_announcement (
    id bigint NOT NULL,
    titulo character varying(200) NOT NULL,
    cuerpo text NOT NULL,
    visible_hasta date,
    creado_en timestamp with time zone NOT NULL,
    creado_por_id integer,
    importante boolean NOT NULL
);


ALTER TABLE public.core_announcement OWNER TO postgres;

--
-- Name: core_announcement_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.core_announcement ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.core_announcement_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: core_document; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.core_document (
    id bigint NOT NULL,
    created_at timestamp with time zone NOT NULL,
    archivo character varying(100) NOT NULL,
    categoria_id bigint,
    titulo character varying(200) NOT NULL,
    descripcion text NOT NULL,
    is_active boolean NOT NULL,
    subido_por_id integer,
    updated_at timestamp with time zone NOT NULL,
    visibilidad character varying(12) NOT NULL,
    CONSTRAINT document_title_not_blank CHECK (((titulo)::text ~ '.*\S.*'::text))
);


ALTER TABLE public.core_document OWNER TO postgres;

--
-- Name: core_document_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.core_document ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.core_document_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: core_documentcategory; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.core_documentcategory (
    id bigint NOT NULL,
    nombre character varying(100) NOT NULL,
    descripcion text NOT NULL
);


ALTER TABLE public.core_documentcategory OWNER TO postgres;

--
-- Name: core_documentcategory_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.core_documentcategory ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.core_documentcategory_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: core_fee; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.core_fee (
    id bigint NOT NULL,
    period character varying(100) NOT NULL,
    amount numeric(10,2)
);


ALTER TABLE public.core_fee OWNER TO postgres;

--
-- Name: core_fee_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.core_fee ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.core_fee_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: core_household; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.core_household (
    id bigint NOT NULL,
    direccion character varying(200) NOT NULL,
    numero character varying(20) NOT NULL,
    referencia character varying(200) NOT NULL
);


ALTER TABLE public.core_household OWNER TO postgres;

--
-- Name: core_household_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.core_household ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.core_household_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: core_household_residents; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.core_household_residents (
    id bigint NOT NULL,
    household_id bigint NOT NULL,
    resident_id bigint NOT NULL
);


ALTER TABLE public.core_household_residents OWNER TO postgres;

--
-- Name: core_household_residents_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.core_household_residents ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.core_household_residents_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: core_incident; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.core_incident (
    id bigint NOT NULL,
    titulo character varying(200) NOT NULL,
    descripcion text NOT NULL,
    foto character varying(100),
    status character varying(20) NOT NULL,
    nota_resolucion text NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    closed_at timestamp with time zone,
    asignada_a_id integer,
    reportado_por_id integer NOT NULL,
    categoria_id bigint
);


ALTER TABLE public.core_incident OWNER TO postgres;

--
-- Name: core_incident_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.core_incident ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.core_incident_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: core_incidentcategory; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.core_incidentcategory (
    id bigint NOT NULL,
    nombre character varying(100) NOT NULL,
    descripcion text NOT NULL
);


ALTER TABLE public.core_incidentcategory OWNER TO postgres;

--
-- Name: core_incidentcategory_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.core_incidentcategory ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.core_incidentcategory_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: core_inscriptionevidence; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.core_inscriptionevidence (
    id bigint NOT NULL,
    file character varying(100) NOT NULL,
    status character varying(10) NOT NULL,
    validated_at timestamp with time zone,
    note text NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    resident_id bigint,
    submitted_by_id integer,
    validated_by_id integer,
    email character varying(254),
    address character varying(255),
    first_name character varying(100),
    last_name character varying(100),
    rut character varying(12),
    desired_role character varying(20)
);


ALTER TABLE public.core_inscriptionevidence OWNER TO postgres;

--
-- Name: core_inscriptionevidence_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.core_inscriptionevidence ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.core_inscriptionevidence_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: core_meeting; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.core_meeting (
    id bigint NOT NULL,
    fecha timestamp with time zone NOT NULL,
    lugar character varying(200) NOT NULL,
    tema character varying(200) NOT NULL,
    creado_en timestamp with time zone NOT NULL,
    creado_por_id integer
);


ALTER TABLE public.core_meeting OWNER TO postgres;

--
-- Name: core_meeting_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.core_meeting ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.core_meeting_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: core_minutes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.core_minutes (
    id bigint NOT NULL,
    texto text NOT NULL,
    archivo character varying(100),
    creado_en timestamp with time zone NOT NULL,
    meeting_id bigint NOT NULL
);


ALTER TABLE public.core_minutes OWNER TO postgres;

--
-- Name: core_minutes_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.core_minutes ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.core_minutes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: core_notification; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.core_notification (
    id bigint NOT NULL,
    title character varying(200),
    body text,
    url character varying(255) NOT NULL,
    icon character varying(20),
    is_read boolean NOT NULL,
    created_at timestamp with time zone NOT NULL,
    user_id integer NOT NULL,
    type character varying(20) DEFAULT 'announcement'::character varying NOT NULL,
    message text,
    is_important boolean NOT NULL
);


ALTER TABLE public.core_notification OWNER TO postgres;

--
-- Name: core_notification_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.core_notification ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.core_notification_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: core_payment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.core_payment (
    id bigint NOT NULL,
    amount numeric(9,2) NOT NULL,
    status character varying(20) NOT NULL,
    paid_at timestamp with time zone,
    created_at timestamp with time zone NOT NULL,
    fee_id bigint,
    resident_id integer NOT NULL,
    origin character varying(20) NOT NULL,
    reservation_id bigint,
    receipt_file character varying(100),
    receipt_uploaded_at timestamp with time zone,
    review_comment text,
    reviewed_at timestamp with time zone,
    reviewed_by_id integer
);


ALTER TABLE public.core_payment OWNER TO postgres;

--
-- Name: core_payment_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.core_payment ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.core_payment_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: core_reservation; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.core_reservation (
    id bigint NOT NULL,
    title character varying(200) NOT NULL,
    notes text NOT NULL,
    start_at timestamp with time zone NOT NULL,
    end_at timestamp with time zone NOT NULL,
    status character varying(12) NOT NULL,
    approved_at timestamp with time zone,
    cancelled_at timestamp with time zone,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    approved_by_id integer,
    requested_by_id integer NOT NULL,
    resource_id bigint NOT NULL,
    cancel_reason text
);


ALTER TABLE public.core_reservation OWNER TO postgres;

--
-- Name: core_reservation_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.core_reservation ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.core_reservation_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: core_resident; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.core_resident (
    id bigint NOT NULL,
    nombre character varying(120) NOT NULL,
    email character varying(254),
    telefono character varying(30) NOT NULL,
    direccion character varying(200) NOT NULL,
    activo boolean NOT NULL,
    user_id integer,
    rut character varying(12)
);


ALTER TABLE public.core_resident OWNER TO postgres;

--
-- Name: core_resident_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.core_resident ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.core_resident_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: core_resource; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.core_resource (
    id bigint NOT NULL,
    nombre character varying(150) NOT NULL,
    descripcion text NOT NULL,
    activo boolean NOT NULL,
    open_time time without time zone,
    close_time time without time zone,
    categoria_id bigint,
    precio_por_hora numeric(9,2)
);


ALTER TABLE public.core_resource OWNER TO postgres;

--
-- Name: core_resource_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.core_resource ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.core_resource_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: core_resourcecategory; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.core_resourcecategory (
    id bigint NOT NULL,
    nombre character varying(120) NOT NULL,
    descripcion text NOT NULL
);


ALTER TABLE public.core_resourcecategory OWNER TO postgres;

--
-- Name: core_resourcecategory_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.core_resourcecategory ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.core_resourcecategory_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: django_admin_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.django_admin_log (
    id integer NOT NULL,
    action_time timestamp with time zone NOT NULL,
    object_id text,
    object_repr character varying(200) NOT NULL,
    action_flag smallint NOT NULL,
    change_message text NOT NULL,
    content_type_id integer,
    user_id integer NOT NULL,
    CONSTRAINT django_admin_log_action_flag_check CHECK ((action_flag >= 0))
);


ALTER TABLE public.django_admin_log OWNER TO postgres;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.django_admin_log ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.django_admin_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: django_content_type; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.django_content_type (
    id integer NOT NULL,
    app_label character varying(100) NOT NULL,
    model character varying(100) NOT NULL
);


ALTER TABLE public.django_content_type OWNER TO postgres;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.django_content_type ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.django_content_type_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: django_migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.django_migrations (
    id bigint NOT NULL,
    app character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    applied timestamp with time zone NOT NULL
);


ALTER TABLE public.django_migrations OWNER TO postgres;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.django_migrations ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.django_migrations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: django_session; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.django_session (
    session_key character varying(40) NOT NULL,
    session_data text NOT NULL,
    expire_date timestamp with time zone NOT NULL
);


ALTER TABLE public.django_session OWNER TO postgres;

--
-- Name: messages; Type: TABLE; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE TABLE realtime.messages (
    topic text NOT NULL,
    extension text NOT NULL,
    payload jsonb,
    event text,
    private boolean DEFAULT false,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    inserted_at timestamp without time zone DEFAULT now() NOT NULL,
    id uuid DEFAULT gen_random_uuid() NOT NULL
)
PARTITION BY RANGE (inserted_at);


ALTER TABLE realtime.messages OWNER TO supabase_realtime_admin;

--
-- Name: schema_migrations; Type: TABLE; Schema: realtime; Owner: supabase_admin
--

CREATE TABLE realtime.schema_migrations (
    version bigint NOT NULL,
    inserted_at timestamp(0) without time zone
);


ALTER TABLE realtime.schema_migrations OWNER TO supabase_admin;

--
-- Name: subscription; Type: TABLE; Schema: realtime; Owner: supabase_admin
--

CREATE TABLE realtime.subscription (
    id bigint NOT NULL,
    subscription_id uuid NOT NULL,
    entity regclass NOT NULL,
    filters realtime.user_defined_filter[] DEFAULT '{}'::realtime.user_defined_filter[] NOT NULL,
    claims jsonb NOT NULL,
    claims_role regrole GENERATED ALWAYS AS (realtime.to_regrole((claims ->> 'role'::text))) STORED NOT NULL,
    created_at timestamp without time zone DEFAULT timezone('utc'::text, now()) NOT NULL
);


ALTER TABLE realtime.subscription OWNER TO supabase_admin;

--
-- Name: subscription_id_seq; Type: SEQUENCE; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE realtime.subscription ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME realtime.subscription_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: buckets; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE storage.buckets (
    id text NOT NULL,
    name text NOT NULL,
    owner uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    public boolean DEFAULT false,
    avif_autodetection boolean DEFAULT false,
    file_size_limit bigint,
    allowed_mime_types text[],
    owner_id text,
    type storage.buckettype DEFAULT 'STANDARD'::storage.buckettype NOT NULL
);


ALTER TABLE storage.buckets OWNER TO supabase_storage_admin;

--
-- Name: COLUMN buckets.owner; Type: COMMENT; Schema: storage; Owner: supabase_storage_admin
--

COMMENT ON COLUMN storage.buckets.owner IS 'Field is deprecated, use owner_id instead';


--
-- Name: buckets_analytics; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE storage.buckets_analytics (
    name text NOT NULL,
    type storage.buckettype DEFAULT 'ANALYTICS'::storage.buckettype NOT NULL,
    format text DEFAULT 'ICEBERG'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE storage.buckets_analytics OWNER TO supabase_storage_admin;

--
-- Name: buckets_vectors; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE storage.buckets_vectors (
    id text NOT NULL,
    type storage.buckettype DEFAULT 'VECTOR'::storage.buckettype NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE storage.buckets_vectors OWNER TO supabase_storage_admin;

--
-- Name: migrations; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE storage.migrations (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    hash character varying(40) NOT NULL,
    executed_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE storage.migrations OWNER TO supabase_storage_admin;

--
-- Name: objects; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE storage.objects (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    bucket_id text,
    name text,
    owner uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    last_accessed_at timestamp with time zone DEFAULT now(),
    metadata jsonb,
    path_tokens text[] GENERATED ALWAYS AS (string_to_array(name, '/'::text)) STORED,
    version text,
    owner_id text,
    user_metadata jsonb,
    level integer
);


ALTER TABLE storage.objects OWNER TO supabase_storage_admin;

--
-- Name: COLUMN objects.owner; Type: COMMENT; Schema: storage; Owner: supabase_storage_admin
--

COMMENT ON COLUMN storage.objects.owner IS 'Field is deprecated, use owner_id instead';


--
-- Name: prefixes; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE storage.prefixes (
    bucket_id text NOT NULL,
    name text NOT NULL COLLATE pg_catalog."C",
    level integer GENERATED ALWAYS AS (storage.get_level(name)) STORED NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE storage.prefixes OWNER TO supabase_storage_admin;

--
-- Name: s3_multipart_uploads; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE storage.s3_multipart_uploads (
    id text NOT NULL,
    in_progress_size bigint DEFAULT 0 NOT NULL,
    upload_signature text NOT NULL,
    bucket_id text NOT NULL,
    key text NOT NULL COLLATE pg_catalog."C",
    version text NOT NULL,
    owner_id text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    user_metadata jsonb
);


ALTER TABLE storage.s3_multipart_uploads OWNER TO supabase_storage_admin;

--
-- Name: s3_multipart_uploads_parts; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE storage.s3_multipart_uploads_parts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    upload_id text NOT NULL,
    size bigint DEFAULT 0 NOT NULL,
    part_number integer NOT NULL,
    bucket_id text NOT NULL,
    key text NOT NULL COLLATE pg_catalog."C",
    etag text NOT NULL,
    owner_id text,
    version text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE storage.s3_multipart_uploads_parts OWNER TO supabase_storage_admin;

--
-- Name: vector_indexes; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE storage.vector_indexes (
    id text DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL COLLATE pg_catalog."C",
    bucket_id text NOT NULL,
    data_type text NOT NULL,
    dimension integer NOT NULL,
    distance_metric text NOT NULL,
    metadata_configuration jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE storage.vector_indexes OWNER TO supabase_storage_admin;

--
-- Name: refresh_tokens id; Type: DEFAULT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.refresh_tokens ALTER COLUMN id SET DEFAULT nextval('auth.refresh_tokens_id_seq'::regclass);


--
-- Data for Name: audit_log_entries; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.audit_log_entries (instance_id, id, payload, created_at, ip_address) FROM stdin;
\.


--
-- Data for Name: flow_state; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.flow_state (id, user_id, auth_code, code_challenge_method, code_challenge, provider_type, provider_access_token, provider_refresh_token, created_at, updated_at, authentication_method, auth_code_issued_at) FROM stdin;
\.


--
-- Data for Name: identities; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.identities (provider_id, user_id, identity_data, provider, last_sign_in_at, created_at, updated_at, id) FROM stdin;
\.


--
-- Data for Name: instances; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.instances (id, uuid, raw_base_config, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: mfa_amr_claims; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.mfa_amr_claims (session_id, created_at, updated_at, authentication_method, id) FROM stdin;
\.


--
-- Data for Name: mfa_challenges; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.mfa_challenges (id, factor_id, created_at, verified_at, ip_address, otp_code, web_authn_session_data) FROM stdin;
\.


--
-- Data for Name: mfa_factors; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.mfa_factors (id, user_id, friendly_name, factor_type, status, created_at, updated_at, secret, phone, last_challenged_at, web_authn_credential, web_authn_aaguid, last_webauthn_challenge_data) FROM stdin;
\.


--
-- Data for Name: oauth_authorizations; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.oauth_authorizations (id, authorization_id, client_id, user_id, redirect_uri, scope, state, resource, code_challenge, code_challenge_method, response_type, status, authorization_code, created_at, expires_at, approved_at) FROM stdin;
\.


--
-- Data for Name: oauth_clients; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.oauth_clients (id, client_secret_hash, registration_type, redirect_uris, grant_types, client_name, client_uri, logo_uri, created_at, updated_at, deleted_at, client_type) FROM stdin;
\.


--
-- Data for Name: oauth_consents; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.oauth_consents (id, user_id, client_id, scopes, granted_at, revoked_at) FROM stdin;
\.


--
-- Data for Name: one_time_tokens; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.one_time_tokens (id, user_id, token_type, token_hash, relates_to, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: refresh_tokens; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.refresh_tokens (instance_id, id, token, user_id, revoked, created_at, updated_at, parent, session_id) FROM stdin;
\.


--
-- Data for Name: saml_providers; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.saml_providers (id, sso_provider_id, entity_id, metadata_xml, metadata_url, attribute_mapping, created_at, updated_at, name_id_format) FROM stdin;
\.


--
-- Data for Name: saml_relay_states; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.saml_relay_states (id, sso_provider_id, request_id, for_email, redirect_to, created_at, updated_at, flow_state_id) FROM stdin;
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.schema_migrations (version) FROM stdin;
20171026211738
20171026211808
20171026211834
20180103212743
20180108183307
20180119214651
20180125194653
00
20210710035447
20210722035447
20210730183235
20210909172000
20210927181326
20211122151130
20211124214934
20211202183645
20220114185221
20220114185340
20220224000811
20220323170000
20220429102000
20220531120530
20220614074223
20220811173540
20221003041349
20221003041400
20221011041400
20221020193600
20221021073300
20221021082433
20221027105023
20221114143122
20221114143410
20221125140132
20221208132122
20221215195500
20221215195800
20221215195900
20230116124310
20230116124412
20230131181311
20230322519590
20230402418590
20230411005111
20230508135423
20230523124323
20230818113222
20230914180801
20231027141322
20231114161723
20231117164230
20240115144230
20240214120130
20240306115329
20240314092811
20240427152123
20240612123726
20240729123726
20240802193726
20240806073726
20241009103726
20250717082212
20250731150234
20250804100000
20250901200500
20250903112500
20250904133000
20250925093508
20251007112900
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.sessions (id, user_id, created_at, updated_at, factor_id, aal, not_after, refreshed_at, user_agent, ip, tag, oauth_client_id, refresh_token_hmac_key, refresh_token_counter) FROM stdin;
\.


--
-- Data for Name: sso_domains; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.sso_domains (id, sso_provider_id, domain, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: sso_providers; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.sso_providers (id, resource_id, created_at, updated_at, disabled) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY auth.users (instance_id, id, aud, role, email, encrypted_password, email_confirmed_at, invited_at, confirmation_token, confirmation_sent_at, recovery_token, recovery_sent_at, email_change_token_new, email_change, email_change_sent_at, last_sign_in_at, raw_app_meta_data, raw_user_meta_data, is_super_admin, created_at, updated_at, phone, phone_confirmed_at, phone_change, phone_change_token, phone_change_sent_at, email_change_token_current, email_change_confirm_status, banned_until, reauthentication_token, reauthentication_sent_at, is_sso_user, deleted_at, is_anonymous) FROM stdin;
\.


--
-- Data for Name: auth_group; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auth_group (id, name) FROM stdin;
1	Admin
2	Secretario
3	Revisor
4	Vecino
6	Tesorero
5	Presidente
7	Delegado
\.


--
-- Data for Name: auth_group_permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auth_group_permissions (id, group_id, permission_id) FROM stdin;
61	1	33
62	1	34
63	1	35
64	1	36
65	1	40
66	1	37
67	1	38
68	1	39
69	1	41
70	1	42
71	1	43
72	1	44
73	1	48
74	1	45
75	1	46
76	1	47
77	1	49
78	1	50
79	1	51
80	1	52
81	1	25
82	1	26
83	1	27
84	1	28
85	1	80
86	1	77
87	1	78
88	1	79
89	1	65
90	1	66
91	1	67
92	1	68
93	1	56
94	1	53
95	1	54
96	1	55
97	1	81
98	1	82
99	1	83
100	1	84
101	5	33
102	5	34
103	5	35
104	5	36
105	5	40
106	5	37
107	5	38
108	5	39
109	5	41
110	5	42
111	5	43
112	5	44
113	5	56
114	5	53
115	5	54
116	5	55
117	5	80
118	5	77
119	5	78
120	5	79
121	5	65
122	5	66
123	5	67
124	5	68
125	5	48
126	5	52
127	5	25
128	5	26
129	5	27
130	5	28
131	5	82
132	5	84
133	2	33
134	2	34
135	2	35
136	2	36
137	2	40
138	2	37
139	2	38
140	2	39
141	2	41
142	2	42
143	2	43
144	2	44
145	2	48
146	2	52
147	2	56
148	2	53
149	2	54
150	2	55
151	2	80
152	2	77
153	2	78
154	2	79
155	2	65
156	2	66
157	2	67
158	2	68
159	2	28
160	2	82
161	2	84
162	6	48
163	6	45
164	6	46
165	6	47
166	6	49
167	6	50
168	6	51
169	6	52
170	6	36
171	6	40
172	6	44
173	6	56
174	6	53
175	6	54
176	6	55
177	6	80
178	6	77
179	6	78
180	6	79
181	6	65
182	6	66
183	6	67
184	6	68
185	7	33
186	7	34
187	7	35
188	7	36
189	7	41
190	7	42
191	7	43
192	7	44
193	7	40
194	7	48
195	7	52
196	7	56
197	7	53
198	7	54
199	7	55
200	7	80
201	7	77
202	7	78
203	7	79
204	7	65
205	7	66
206	7	67
207	7	68
208	4	36
209	4	56
210	4	48
211	4	52
212	4	80
213	4	77
214	4	78
215	4	65
216	4	66
217	4	67
218	4	68
222	5	49
223	5	50
224	5	51
\.


--
-- Data for Name: auth_permission; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auth_permission (id, name, content_type_id, codename) FROM stdin;
1	Can add log entry	1	add_logentry
2	Can change log entry	1	change_logentry
3	Can delete log entry	1	delete_logentry
4	Can view log entry	1	view_logentry
5	Can add permission	2	add_permission
6	Can change permission	2	change_permission
7	Can delete permission	2	delete_permission
8	Can view permission	2	view_permission
9	Can add group	3	add_group
10	Can change group	3	change_group
11	Can delete group	3	delete_group
12	Can view group	3	view_group
13	Can add user	4	add_user
14	Can change user	4	change_user
15	Can delete user	4	delete_user
16	Can view user	4	view_user
17	Can add content type	5	add_contenttype
18	Can change content type	5	change_contenttype
19	Can delete content type	5	delete_contenttype
20	Can view content type	5	view_contenttype
21	Can add session	6	add_session
22	Can change session	6	change_session
23	Can delete session	6	delete_session
24	Can view session	6	view_session
25	Can add resident	7	add_resident
26	Can change resident	7	change_resident
27	Can delete resident	7	delete_resident
28	Can view resident	7	view_resident
29	Can add household	8	add_household
30	Can change household	8	change_household
31	Can delete household	8	delete_household
32	Can view household	8	view_household
33	Can add announcement	9	add_announcement
34	Can change announcement	9	change_announcement
35	Can delete announcement	9	delete_announcement
36	Can view announcement	9	view_announcement
37	Can add meeting	10	add_meeting
38	Can change meeting	10	change_meeting
39	Can delete meeting	10	delete_meeting
40	Can view meeting	10	view_meeting
41	Can add minutes	11	add_minutes
42	Can change minutes	11	change_minutes
43	Can delete minutes	11	delete_minutes
44	Can view minutes	11	view_minutes
45	Can add Deuda	12	add_fee
46	Can change Deuda	12	change_fee
47	Can delete Deuda	12	delete_fee
48	Can view Deuda	12	view_fee
49	Can add Pago	13	add_payment
50	Can change Pago	13	change_payment
51	Can delete Pago	13	delete_payment
52	Can view Pago	13	view_payment
53	Can add Documento	14	add_document
54	Can change Documento	14	change_document
55	Can delete Documento	14	delete_document
56	Can view Documento	14	view_document
57	Can add Categoría de documento	15	add_documentcategory
58	Can change Categoría de documento	15	change_documentcategory
59	Can delete Categoría de documento	15	delete_documentcategory
60	Can view Categoría de documento	15	view_documentcategory
61	Can add Categoría de incidencia	16	add_incidentcategory
62	Can change Categoría de incidencia	16	change_incidentcategory
63	Can delete Categoría de incidencia	16	delete_incidentcategory
64	Can view Categoría de incidencia	16	view_incidentcategory
65	Can add Incidencia	17	add_incident
66	Can change Incidencia	17	change_incident
67	Can delete Incidencia	17	delete_incident
68	Can view Incidencia	17	view_incident
69	Can add Categoría de recurso	18	add_resourcecategory
70	Can change Categoría de recurso	18	change_resourcecategory
71	Can delete Categoría de recurso	18	delete_resourcecategory
72	Can view Categoría de recurso	18	view_resourcecategory
73	Can add Recurso	19	add_resource
74	Can change Recurso	19	change_resource
75	Can delete Recurso	19	delete_resource
76	Can view Recurso	19	view_resource
77	Can add Reserva	20	add_reservation
78	Can change Reserva	20	change_reservation
79	Can delete Reserva	20	delete_reservation
80	Can view Reserva	20	view_reservation
81	Can add inscription evidence	21	add_inscriptionevidence
82	Can change inscription evidence	21	change_inscriptionevidence
83	Can delete inscription evidence	21	delete_inscriptionevidence
84	Can view inscription evidence	21	view_inscriptionevidence
85	Can add notification	22	add_notification
86	Can change notification	22	change_notification
87	Can delete notification	22	delete_notification
88	Can view notification	22	view_notification
\.


--
-- Data for Name: auth_user; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auth_user (id, password, last_login, is_superuser, username, first_name, last_name, email, is_staff, is_active, date_joined) FROM stdin;
8	pbkdf2_sha256$720000$pym5FSvPL9snR59Zf0DpSL$1vud6hv4qWlc9pYBVxAZqWMqqmFmZFZnndOFJV6UI7g=	2025-11-17 00:06:24.726042+00	f	lucas.saez	Lucas	Saez	mi.medina@duocuc.cl	f	t	2025-11-17 00:05:23.071621+00
14	pbkdf2_sha256$720000$BhacBYKYyOD2ffEeNBkUGV$WCB5uPWJ+04ugPhP78mOGN2kIgxQeqsnK9CPqORlK0Y=	2025-11-25 15:54:24.122101+00	f	rodrigo.leyton	rodrigo	leyton	mi.medina@duocuc.cl	f	t	2025-11-25 15:53:40.473082+00
2	pbkdf2_sha256$720000$ThtMfxsJiPvzFYchnhf0Zf$W/W1kmsrzaO9CaM/Io+geeqaB+cdpGdnNbLcpUnW1yo=	2025-11-23 02:18:25.428428+00	f	matias.tesorero	Matías	Tesorero	matias.tesorero@example.com	f	t	2025-11-16 22:53:45.434356+00
13	pbkdf2_sha256$720000$RrwFUcVZBzvfEJ0o6lWVAl$mWX6PlIe+pbROmQy5yjOE5+qKDtp9/uFoWiXnewyhWo=	2025-11-24 22:35:28.659115+00	f	matias.cardenas2	Matías	Cárdenas	matiascardenas512@gmail.com	f	t	2025-11-24 22:34:47.345396+00
4	pbkdf2_sha256$720000$eOn5R5HJ61hxpVz0m4Ngd2$KWLVnC57dMTvgqlgSfShLFoSv2kjvALZWlfMX25TQ+M=	2025-11-23 18:42:46.284456+00	f	miguel.secretario	Miguel	Secretario	miguel.secretario@example.com	f	t	2025-11-16 22:53:47.135178+00
6	pbkdf2_sha256$720000$9prpVOyzHwMzt7ibIOLKtc$UrEomee8FGNkAPHQGC7IqbMRbGSIj+ITxmOd7XeTPo0=	2025-11-23 18:48:55.983144+00	t	admin				t	t	2025-11-16 23:48:16.790715+00
3	pbkdf2_sha256$720000$E11mA3KuVYECVzYsrVw8qV$5NzMO1KjHx05zsMJ44cJzO+2lM4aV23nycck1updjM0=	2025-11-22 22:50:51.263737+00	f	lucas.delegado	Lucas	Delegado	lucas.delegado@example.com	f	t	2025-11-16 22:53:46.287319+00
10	pbkdf2_sha256$720000$h7E67obzVbAKeRzS128YLu$YDSLQxUneoD6FqooYZ9r2JqXzj0Pws9NVkDb2mW5960=	2025-11-25 14:35:00.905482+00	f	william.lopez	William	López	wi.lopezc@duocuc.cl	f	t	2025-11-19 01:09:58.042894+00
9	pbkdf2_sha256$720000$6B0D0WvW8rpBkMXW31DXux$9rJMhD2qGI7HDQLE3aX0jJPj95eXE1FcPeGPVTrGcb0=	2025-11-20 23:09:04.771148+00	f	renato.arratia	renato	Arratia	mi.medina@duocuc.cl	f	t	2025-11-18 15:22:25.954855+00
11	pbkdf2_sha256$720000$f2X9XmoRwn3bSiaMFXdsc4$bahR8tNTw8Uqv2eQMl90Kmq5OcwPG4CAGYftl0Xvpgc=	\N	f	matias.medina	Matias	Medina	mi.medina@duocuc.cl	f	f	2025-11-22 23:54:38.039197+00
7	pbkdf2_sha256$720000$dMdvYXxClMxATC8tED6zSZ$8S7B6301PKQWTtXC85paFxY4QlcehxI4HeBwgwGclcc=	2025-11-17 00:03:02.423513+00	f	matias.cardenas	matias	cardenas	mi.medina@duocuc.cl	f	f	2025-11-17 00:02:19.793318+00
5	pbkdf2_sha256$720000$z7c7NTTWeDq2qebD9YfJK9$hOQniBdS9N3E0vUEQAMqqkFKlS8w+soDgMdAEXBfgAU=	2025-11-25 15:47:30.218146+00	f	daniel.vecino	Daniel	Vecino	daniel.vecino@example.com	f	t	2025-11-16 22:53:47+00
1	pbkdf2_sha256$720000$JUlEWKURSNTEuSYeP58P2i$QbXCiky+WAygBYzP+Dufy4ZSko50Fec0PMJoSW4Zph0=	2025-11-25 15:52:09.905186+00	f	william.presidente	William	Presidente	william.presidente@example.com	f	t	2025-11-16 22:53:44+00
\.


--
-- Data for Name: auth_user_groups; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auth_user_groups (id, user_id, group_id) FROM stdin;
1	1	5
2	2	6
3	3	7
4	4	2
5	5	4
6	7	4
7	8	2
8	9	4
9	10	4
10	11	4
12	13	4
13	14	4
\.


--
-- Data for Name: auth_user_user_permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auth_user_user_permissions (id, user_id, permission_id) FROM stdin;
\.


--
-- Data for Name: core_announcement; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.core_announcement (id, titulo, cuerpo, visible_hasta, creado_en, creado_por_id, importante) FROM stdin;
1	corte de luz	corte de luz a las 2	2025-11-17	2025-11-16 23:44:46.259912+00	1	f
5	corte en la calle diego de meza	Se cortara la calle diego de meza para el evento de mañana	2025-11-21	2025-11-20 17:16:39.394303+00	1	f
6	evento de navidad	Les comunicamos que el dia 12 de diciembre a las 20:00 horas se hara en la cancha de futbol el evento de navidad	2025-11-29	2025-11-20 20:44:32.355364+00	1	f
7	evento año nuevo	les comunicamos que para el 31 de diciembre se hará una celebración de año nuevo para toda la junta de vecinos en el salón de eventos	2025-12-31	2025-11-21 00:47:37.555178+00	1	f
8	corte de luz	Se hara un corte de luz en el sector alrededor de las 20:00 horas	2025-11-22	2025-11-21 01:32:44.806246+00	1	f
9	corte de agua	La municipalidad nos comunico que se hará un corte de agua en el sector a las 20:00 horas	2025-11-22	2025-11-21 01:39:26.882075+00	1	f
10	corte de calle	se cortara la calle llico por el evento de navidad	2025-11-22	2025-11-21 01:46:35.240772+00	1	f
11	evento fiestas patrias	les comunicamos que comenzaremos durante la semana las actividades para recaudar fondos para el evento de fiestas patrias del próximo año	2025-11-22	2025-11-21 01:58:03.276293+00	1	f
12	corte de agua	Corte de agua programado para el día 23 a las 20:00 horas	2025-11-24	2025-11-21 02:06:08.98658+00	1	f
13	calle cortada	Recuerden que se cortara la calle diego de meza para el evento de navidad	2025-11-26	2025-11-21 22:22:34.254143+00	3	f
14	aniversario junta de vecinos	Les comunicamos que la próxima semana se celebrara el aniversario de la junta de vecinos en el salón de eventos\r\n\r\nLos próximos días confirmaremos el día y la hora	2025-11-29	2025-11-21 22:34:27.861514+00	3	f
\.


--
-- Data for Name: core_document; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.core_document (id, created_at, archivo, categoria_id, titulo, descripcion, is_active, subido_por_id, updated_at, visibilidad) FROM stdin;
\.


--
-- Data for Name: core_documentcategory; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.core_documentcategory (id, nombre, descripcion) FROM stdin;
\.


--
-- Data for Name: core_fee; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.core_fee (id, period, amount) FROM stdin;
\.


--
-- Data for Name: core_household; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.core_household (id, direccion, numero, referencia) FROM stdin;
\.


--
-- Data for Name: core_household_residents; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.core_household_residents (id, household_id, resident_id) FROM stdin;
\.


--
-- Data for Name: core_incident; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.core_incident (id, titulo, descripcion, foto, status, nota_resolucion, created_at, updated_at, closed_at, asignada_a_id, reportado_por_id, categoria_id) FROM stdin;
1	agujero en la calle	agujero en digo de meza, cerca de la plaza de la esquina		OPEN		2025-11-16 23:45:41.834928+00	2025-11-20 01:03:58.20255+00	\N	\N	1	\N
2	cuidado en la calle llico	están robando mucho en la calle llico		OPEN		2025-11-18 00:12:12.254583+00	2025-11-20 01:04:19.092509+00	\N	\N	5	\N
3	robo de bicicleta	Quiero reportar el robo de mi bicicleta en la calle ureta cox, por si la ven en algun lado	incidencias/3/20251120_010506_1395aa25ffe147ac9d21ab25c15fa1d4.jpg	OPEN		2025-11-20 01:05:06.806985+00	2025-11-20 01:05:06.807001+00	\N	\N	3	\N
4	asalto en la cancha de futbol anoce	alrededor de las 21:00 horas robaron el celular a mi hijo en las canchas de futbol anoche, para que tengan cuidado		OPEN		2025-11-20 18:38:40.794836+00	2025-11-20 18:38:40.794845+00	\N	\N	5	\N
5	asalto en la cancha de futbol anoce	alrededor de las 21:00 horas robaron el celular a mi hijo en las canchas de futbol anoche, para que tengan cuidado		OPEN		2025-11-20 18:39:24.74086+00	2025-11-20 18:39:24.740869+00	\N	\N	5	\N
6	asalto en la cancha de futbol anoce	alrededor de las 21:00 horas robaron el celular a mi hijo en las canchas de futbol anoche, para que tengan cuidado		OPEN		2025-11-20 19:17:38.253371+00	2025-11-20 19:17:38.253383+00	\N	\N	5	\N
7	robo de cables	se robaron los cables anoche		OPEN		2025-11-20 19:38:09.044073+00	2025-11-20 19:38:09.044083+00	\N	\N	5	\N
8	accidente de autos en departamental	fuerte choque en departamental		OPEN		2025-11-20 19:46:55.303794+00	2025-11-20 19:46:55.303807+00	\N	\N	4	\N
9	aumento de robos en calle llico	tengan cuidado por esa calle, están robando mucho		OPEN		2025-11-20 20:21:55.244809+00	2025-11-20 20:21:55.244819+00	\N	\N	4	\N
10	Robo de celular	El dia de hoy cerca de diego de meza alrededor de las 20:00 hroas me robaron el celular, era un tipo alto vestido de negro.		OPEN		2025-11-20 23:52:53.731286+00	2025-11-20 23:52:53.731295+00	\N	\N	5	\N
11	Cuidado en diego de meza	Vi a un grupo extraño		OPEN		2025-11-21 01:01:48.420953+00	2025-11-21 01:01:48.420967+00	\N	\N	5	\N
12	cuidado en santa rosa cerca del unimarc	en la esquina del unimarc se han reportado muchos robos la ultima semana		OPEN		2025-11-21 01:07:33.071662+00	2025-11-21 01:07:33.071672+00	\N	\N	5	\N
13	robo cerca del salon de eventos	ayer a mi hijo le robaron su celular cerca del salón de eventos alrededor de las 20:00 horas		OPEN		2025-11-21 01:31:26.924083+00	2025-11-21 01:31:26.924101+00	\N	\N	5	\N
14	peligro cerca de la cancha de padel	anoche vi a un grupo extraño que no es de la zona alrededor de la cancha de padel		OPEN		2025-11-21 01:35:07.343075+00	2025-11-21 01:35:07.343088+00	\N	\N	2	\N
15	gente peligrosa	el viernes cerca de la cancha de basquetbol andaba un grupo que no era de la zona		OPEN		2025-11-21 01:59:41.46486+00	2025-11-21 01:59:41.46487+00	\N	\N	1	\N
16	zona peligrosa	robos continuos cerca de las canchas durante la noche		OPEN		2025-11-21 02:12:00.035261+00	2025-11-21 02:12:00.035273+00	\N	\N	5	\N
17	choque de vehiculo	accidente en diego de meza		OPEN		2025-11-21 02:23:06.412382+00	2025-11-21 02:23:06.412393+00	\N	\N	3	\N
18	choque de vehiculo	accidente en diego de meza		OPEN		2025-11-21 02:23:20.934379+00	2025-11-21 02:23:20.934389+00	\N	\N	3	\N
19	accidente en la cancha	un niño se quebró la pierna jugando a la pelota		OPEN		2025-11-21 02:29:22.912608+00	2025-11-21 02:29:22.912618+00	\N	\N	3	\N
20	hoyo en calle	Diego de meza tiene un hoyo tenga cuidado		OPEN		2025-11-21 02:37:07.910367+00	2025-11-21 02:37:07.910377+00	\N	\N	5	\N
22	robo de celular	Quiero reportar el robo de mi celular hace unas dos horas cerca de las canchas		OPEN		2025-11-21 22:23:08.360179+00	2025-11-21 22:23:08.36019+00	\N	\N	3	\N
23	robo de bicicleta	Quiero comunicar que el día de ayer cerca de la cancha me robaron mi bici, por si la ven en algún lado	incidencias/3/20251121_223515_25ded01205c44ecd8f73f975104cf6aa.jpg	OPEN		2025-11-21 22:35:15.953686+00	2025-11-21 22:35:15.953696+00	\N	\N	3	\N
\.


--
-- Data for Name: core_incidentcategory; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.core_incidentcategory (id, nombre, descripcion) FROM stdin;
\.


--
-- Data for Name: core_inscriptionevidence; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.core_inscriptionevidence (id, file, status, validated_at, note, created_at, updated_at, resident_id, submitted_by_id, validated_by_id, email, address, first_name, last_name, rut, desired_role) FROM stdin;
1	evidencias_inscripcion/2025/11/17/c7e4cd0bcc31414cadabba4a67bc7181.jpg	APPROVED	2025-11-17 00:02:19.71476+00		2025-11-17 00:01:57.546881+00	2025-11-17 00:02:20.670023+00	6	\N	1	mi.medina@duocuc.cl	departamental 432	matias	cardenas	32.124.654-3	VECINO
2	evidencias_inscripcion/2025/11/17/c7e4cd0bcc31414cadabba4a67bc7181_ZV9ZYue.jpg	APPROVED	2025-11-17 00:05:23.004681+00		2025-11-17 00:04:52.692664+00	2025-11-17 00:05:24.109808+00	7	\N	1	mi.medina@duocuc.cl	departamental 65	Lucas	Saez	45.123.764-3	SECRETARIO
3	evidencias_inscripcion/2025/11/18/Imagen_de_WhatsApp_2025-09-08_a_las_17.35.54_41be639d.jpg	APPROVED	2025-11-18 15:22:25.871459+00		2025-11-18 15:20:52.91016+00	2025-11-18 15:22:27.131462+00	8	\N	4	mi.medina@duocuc.cl	Diego De Meza 5431	renato	Arratia	12.123.123-3	VECINO
4	evidencias_inscripcion/2025/11/19/CEN_2025-11-18_report.pdf	APPROVED	2025-11-19 01:09:57.986135+00		2025-11-19 01:09:35.775962+00	2025-11-19 01:09:58.776528+00	9	\N	1	wi.lopezc@duocuc.cl	Santa Clara 5751	William	López	21.201.554-7	VECINO
5	evidencias_inscripcion/2025/11/22/bici.jpg	PENDING	\N		2025-11-22 00:48:28.883216+00	2025-11-22 00:48:28.88323+00	\N	\N	\N	mi.medina@duocuc.cl	Diego de meza 5431	Maria	Avalos	12.123.123-1	\N
12	evidencias_inscripcion/2025/11/24/lol.jpeg	REJECTED	2025-11-25 15:48:57.737701+00	ola	2025-11-24 22:34:04.312707+00	2025-11-25 15:48:57.737993+00	12	\N	1	matiascardenas512@gmail.com	Mi casa	Matías	Cárdenas	20.921.789-9	VECINO
13	evidencias_inscripcion/2025/11/25/Imagen_de_WhatsApp_2025-09-08_a_las_17.35.54_41be639d.jpg	APPROVED	2025-11-25 15:53:40.297851+00		2025-11-25 15:51:50.364809+00	2025-11-25 15:53:43.265139+00	13	\N	1	mi.medina@duocuc.cl	Diego de meza 5431	rodrigo	leyton	21.075.540-3	VECINO
6	evidencias_inscripcion/2025/11/22/bici_Eas26af.jpg	REJECTED	2025-11-23 02:15:27.128587+00		2025-11-22 02:14:51.325835+00	2025-11-23 02:15:27.128735+00	10	\N	4	mi.medina@duocuc.cl	departamental 432	Matias	Medina	13.123.123-1	VECINO
7	evidencias_inscripcion/2025/11/23/Imagen_de_WhatsApp_2025-10-17_a_las_15.20.14_95b5d0b5.jpg	PENDING	\N		2025-11-23 02:25:00.380581+00	2025-11-23 02:25:00.380591+00	\N	\N	\N	mi.medina@duocuc.cl	diego de meza 1234	nicolas	medina	14.123.123-1	\N
8	evidencias_inscripcion/2025/11/23/c7e4cd0bcc31414cadabba4a67bc7181.jpg	PENDING	\N		2025-11-23 19:41:25.218768+00	2025-11-23 19:41:25.218787+00	\N	\N	\N	mi.medina@duocuc.cl	departamentar 452	rene	medina	15-113-123-1	\N
9	evidencias_inscripcion/2025/11/23/c7e4cd0bcc31414cadabba4a67bc7181_8NQHnle.jpg	PENDING	\N		2025-11-23 19:41:58.49232+00	2025-11-23 19:41:58.49233+00	\N	\N	\N	mi.medina@duocuc.cl	departamental 152	pedro	vazques	16-123-123-1	\N
10	evidencias_inscripcion/2025/11/23/c7e4cd0bcc31414cadabba4a67bc7181_YHSrwDc.jpg	PENDING	\N		2025-11-23 19:47:37.516883+00	2025-11-23 19:47:37.516896+00	\N	\N	\N	mi.medina@duocuc.cl	puente alto 212	antonia	moreno	17-123-123-1	\N
\.


--
-- Data for Name: core_meeting; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.core_meeting (id, fecha, lugar, tema, creado_en, creado_por_id) FROM stdin;
1	2025-11-20 22:44:00+00	Salon de eventos	Navidad	2025-11-16 23:45:09.03767+00	\N
2	2025-11-21 16:15:00+00	casa de william	Gestion junta de vecinos	2025-11-20 23:55:00.715704+00	\N
3	2025-11-29 22:30:00+00	Salon de eventos	proximo evento junta de vecinos	2025-11-21 23:35:13.322532+00	\N
4	2025-11-22 21:45:00+00	prueba	prueba noti	2025-11-22 00:34:32.31168+00	\N
5	2025-11-22 21:40:00+00	prueba 2	prueba noti 2	2025-11-22 00:34:58.033469+00	\N
6	2025-11-29 22:34:00+00	Salon de prueba luego de ajuste	prueba	2025-11-22 01:32:44.167598+00	\N
7	2025-11-28 00:39:00+00	prueba 2	prueba noti	2025-11-22 01:37:37.741583+00	\N
8	2025-11-30 23:20:00+00	prueba "final" noti	prueba	2025-11-22 02:14:21.256274+00	4
\.


--
-- Data for Name: core_minutes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.core_minutes (id, texto, archivo, creado_en, meeting_id) FROM stdin;
\.


--
-- Data for Name: core_notification; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.core_notification (id, title, body, url, icon, is_read, created_at, user_id, type, message, is_important) FROM stdin;
89	\N	\N	#	\N	f	2025-11-21 02:29:23.237588+00	8	incident	Se ha registrado una nueva incidencia.	f
91	\N	\N	/incidencias/mis-incidencias/	\N	f	2025-11-21 02:37:08.03914+00	8	incident	Se ha registrado una nueva incidencia en la Junta.	f
97	\N	\N	/incidencias/mis-incidencias/	\N	f	2025-11-21 02:38:51.243677+00	8	incident	Se ha registrado una nueva incidencia en la Junta.	f
100	\N	\N	/avisos/	\N	f	2025-11-21 22:22:34.386641+00	8	announcement	Se ha publicado un nuevo aviso en la Junta.	f
108	\N	\N	/avisos/	\N	f	2025-11-21 22:22:34.386787+00	9	announcement	Se ha publicado un nuevo aviso en la Junta.	f
111	\N	\N	/incidencias/mis-incidencias/	\N	f	2025-11-21 22:23:08.4915+00	8	incident	Se ha registrado una nueva incidencia en la Junta.	f
114	\N	\N	/avisos/	\N	f	2025-11-21 22:34:27.992991+00	8	announcement	Se ha publicado un nuevo aviso en la Junta.	f
122	\N	\N	/avisos/	\N	f	2025-11-21 22:34:27.993134+00	9	announcement	Se ha publicado un nuevo aviso en la Junta.	f
125	\N	\N	/incidencias/mis-incidencias/	\N	f	2025-11-21 22:35:16.080993+00	8	incident	Se ha registrado una nueva incidencia en la Junta.	f
128	\N	\N	/avisos/	\N	f	2025-11-21 22:36:52.400064+00	8	announcement	Se ha publicado un nuevo aviso en la Junta.	f
134	\N	\N	/avisos/	\N	f	2025-11-21 22:36:52.400169+00	9	announcement	Se ha publicado un nuevo aviso en la Junta.	f
137	\N	\N	/avisos/	\N	f	2025-11-21 22:42:44.084572+00	8	announcement	Se ha publicado un nuevo aviso en la Junta.	f
143	\N	\N	/avisos/	\N	f	2025-11-21 22:42:44.084678+00	9	announcement	Se ha publicado un nuevo aviso en la Junta.	f
88	\N	\N	#	\N	t	2025-11-21 02:29:23.175141+00	3	incident	Se ha registrado una nueva incidencia.	f
87	\N	\N	#	\N	t	2025-11-21 02:29:23.11352+00	1	incident	Se ha registrado una nueva incidencia.	f
93	\N	\N	/incidencias/mis-incidencias/	\N	t	2025-11-21 02:37:08.039178+00	1	incident	Se ha registrado una nueva incidencia en la Junta.	f
99	\N	\N	/incidencias/mis-incidencias/	\N	t	2025-11-21 02:38:51.24372+00	1	incident	Se ha registrado una nueva incidencia en la Junta.	f
101	\N	\N	/avisos/	\N	t	2025-11-21 22:22:34.386667+00	1	announcement	Se ha publicado un nuevo aviso en la Junta.	f
110	\N	\N	/incidencias/mis-incidencias/	\N	t	2025-11-21 22:23:08.491482+00	1	incident	Se ha registrado una nueva incidencia en la Junta.	f
119	\N	\N	/avisos/	\N	t	2025-11-21 22:34:27.993085+00	1	announcement	Se ha publicado un nuevo aviso en la Junta.	f
126	\N	\N	/incidencias/mis-incidencias/	\N	t	2025-11-21 22:35:16.081022+00	1	incident	Se ha registrado una nueva incidencia en la Junta.	f
92	\N	\N	/incidencias/mis-incidencias/	\N	t	2025-11-21 02:37:08.03916+00	2	incident	Se ha registrado una nueva incidencia en la Junta.	f
98	\N	\N	/incidencias/mis-incidencias/	\N	t	2025-11-21 02:38:51.243696+00	2	incident	Se ha registrado una nueva incidencia en la Junta.	f
105	\N	\N	/avisos/	\N	t	2025-11-21 22:22:34.386737+00	2	announcement	Se ha publicado un nuevo aviso en la Junta.	f
109	\N	\N	/incidencias/mis-incidencias/	\N	t	2025-11-21 22:23:08.491455+00	2	incident	Se ha registrado una nueva incidencia en la Junta.	f
117	\N	\N	/avisos/	\N	t	2025-11-21 22:34:27.993053+00	2	announcement	Se ha publicado un nuevo aviso en la Junta.	f
124	\N	\N	/incidencias/mis-incidencias/	\N	t	2025-11-21 22:35:16.080972+00	2	incident	Se ha registrado una nueva incidencia en la Junta.	f
131	\N	\N	/avisos/	\N	t	2025-11-21 22:36:52.400122+00	2	announcement	Se ha publicado un nuevo aviso en la Junta.	f
140	\N	\N	/avisos/	\N	t	2025-11-21 22:42:44.084632+00	2	announcement	Se ha publicado un nuevo aviso en la Junta.	f
86	\N	\N	#	\N	t	2025-11-21 02:29:23.046974+00	4	incident	Se ha registrado una nueva incidencia.	f
90	\N	\N	/incidencias/mis-incidencias/	\N	t	2025-11-21 02:37:08.039105+00	4	incident	Se ha registrado una nueva incidencia en la Junta.	f
95	\N	\N	/incidencias/mis-incidencias/	\N	t	2025-11-21 02:38:51.243623+00	4	incident	Se ha registrado una nueva incidencia en la Junta.	f
102	\N	\N	/avisos/	\N	t	2025-11-21 22:22:34.386684+00	4	announcement	Se ha publicado un nuevo aviso en la Junta.	f
112	\N	\N	/incidencias/mis-incidencias/	\N	t	2025-11-21 22:23:08.491516+00	4	incident	Se ha registrado una nueva incidencia en la Junta.	f
118	\N	\N	/avisos/	\N	t	2025-11-21 22:34:27.993069+00	4	announcement	Se ha publicado un nuevo aviso en la Junta.	f
127	\N	\N	/incidencias/mis-incidencias/	\N	t	2025-11-21 22:35:16.08104+00	4	incident	Se ha registrado una nueva incidencia en la Junta.	f
132	\N	\N	/avisos/	\N	t	2025-11-21 22:36:52.400138+00	4	announcement	Se ha publicado un nuevo aviso en la Junta.	f
141	\N	\N	/avisos/	\N	t	2025-11-21 22:42:44.084647+00	4	announcement	Se ha publicado un nuevo aviso en la Junta.	f
104	\N	\N	/avisos/	\N	t	2025-11-21 22:22:34.386721+00	5	announcement	Se ha publicado un nuevo aviso en la Junta.	f
120	\N	\N	/avisos/	\N	t	2025-11-21 22:34:27.993102+00	5	announcement	Se ha publicado un nuevo aviso en la Junta.	f
135	\N	\N	/avisos/	\N	t	2025-11-21 22:36:52.400185+00	5	announcement	Se ha publicado un nuevo aviso en la Junta.	f
144	\N	\N	/avisos/	\N	t	2025-11-21 22:42:44.084694+00	5	announcement	Se ha publicado un nuevo aviso en la Junta.	f
146	\N	\N	/incidencias/mis-incidencias/	\N	f	2025-11-21 22:43:06.032296+00	8	incident	Se ha registrado una nueva incidencia en la Junta.	f
152	\N	\N	/incidencias/mis-incidencias/	\N	f	2025-11-21 22:43:06.03243+00	9	incident	Se ha registrado una nueva incidencia en la Junta.	f
154	\N	\N	/incidencias/mis-incidencias/	\N	f	2025-11-21 22:44:51.585964+00	8	incident	Se ha registrado una nueva incidencia en la Junta.	f
160	\N	\N	/incidencias/mis-incidencias/	\N	f	2025-11-21 22:44:51.586087+00	9	incident	Se ha registrado una nueva incidencia en la Junta.	f
103	\N	\N	/avisos/	\N	t	2025-11-21 22:22:34.386703+00	10	announcement	Se ha publicado un nuevo aviso en la Junta.	f
115	\N	\N	/avisos/	\N	t	2025-11-21 22:34:27.993018+00	10	announcement	Se ha publicado un nuevo aviso en la Junta.	f
129	\N	\N	/avisos/	\N	t	2025-11-21 22:36:52.40009+00	10	announcement	Se ha publicado un nuevo aviso en la Junta.	f
138	\N	\N	/avisos/	\N	t	2025-11-21 22:42:44.084598+00	10	announcement	Se ha publicado un nuevo aviso en la Junta.	f
147	\N	\N	/incidencias/mis-incidencias/	\N	t	2025-11-21 22:43:06.032328+00	10	incident	Se ha registrado una nueva incidencia en la Junta.	f
162	\N	\N	/avisos/	\N	f	2025-11-21 22:48:51.996181+00	8	announcement	Se ha publicado un nuevo aviso en la Junta.	f
169	\N	\N	/avisos/	\N	f	2025-11-21 22:48:51.996325+00	9	announcement	Se ha publicado un nuevo aviso en la Junta.	f
94	\N	\N	/incidencias/mis-incidencias/	\N	t	2025-11-21 02:37:08.039198+00	3	incident	Se ha registrado una nueva incidencia en la Junta.	f
96	\N	\N	/incidencias/mis-incidencias/	\N	t	2025-11-21 02:38:51.243657+00	3	incident	Se ha registrado una nueva incidencia en la Junta.	f
107	\N	\N	/avisos/	\N	t	2025-11-21 22:22:34.38677+00	3	announcement	Se ha publicado un nuevo aviso en la Junta.	f
113	\N	\N	/incidencias/mis-incidencias/	\N	t	2025-11-21 22:23:08.491532+00	3	incident	Se ha registrado una nueva incidencia en la Junta.	f
121	\N	\N	/avisos/	\N	t	2025-11-21 22:34:27.993118+00	3	announcement	Se ha publicado un nuevo aviso en la Junta.	f
123	\N	\N	/incidencias/mis-incidencias/	\N	t	2025-11-21 22:35:16.080932+00	3	incident	Se ha registrado una nueva incidencia en la Junta.	f
136	\N	\N	/avisos/	\N	t	2025-11-21 22:36:52.4002+00	3	announcement	Se ha publicado un nuevo aviso en la Junta.	f
145	\N	\N	/avisos/	\N	t	2025-11-21 22:42:44.08471+00	3	announcement	Se ha publicado un nuevo aviso en la Junta.	f
161	\N	\N	/incidencias/mis-incidencias/	\N	t	2025-11-21 22:44:51.586104+00	3	incident	Se ha registrado una nueva incidencia en la Junta.	f
133	\N	\N	/avisos/	\N	t	2025-11-21 22:36:52.400154+00	1	announcement	Se ha publicado un nuevo aviso en la Junta.	f
142	\N	\N	/avisos/	\N	t	2025-11-21 22:42:44.084663+00	1	announcement	Se ha publicado un nuevo aviso en la Junta.	f
151	\N	\N	/incidencias/mis-incidencias/	\N	t	2025-11-21 22:43:06.03241+00	1	incident	Se ha registrado una nueva incidencia en la Junta.	f
159	\N	\N	/incidencias/mis-incidencias/	\N	t	2025-11-21 22:44:51.58607+00	1	incident	Se ha registrado una nueva incidencia en la Junta.	f
168	\N	\N	/avisos/	\N	t	2025-11-21 22:48:51.996309+00	1	announcement	Se ha publicado un nuevo aviso en la Junta.	f
149	\N	\N	/incidencias/mis-incidencias/	\N	t	2025-11-21 22:43:06.03237+00	2	incident	Se ha registrado una nueva incidencia en la Junta.	f
157	\N	\N	/incidencias/mis-incidencias/	\N	t	2025-11-21 22:44:51.586036+00	2	incident	Se ha registrado una nueva incidencia en la Junta.	f
166	\N	\N	/avisos/	\N	t	2025-11-21 22:48:51.996268+00	2	announcement	Se ha publicado un nuevo aviso en la Junta.	f
150	\N	\N	/incidencias/mis-incidencias/	\N	t	2025-11-21 22:43:06.03239+00	4	incident	Se ha registrado una nueva incidencia en la Junta.	f
158	\N	\N	/incidencias/mis-incidencias/	\N	t	2025-11-21 22:44:51.586054+00	4	incident	Se ha registrado una nueva incidencia en la Junta.	f
167	\N	\N	/avisos/	\N	t	2025-11-21 22:48:51.996293+00	4	announcement	Se ha publicado un nuevo aviso en la Junta.	f
170	\N	\N	/avisos/	\N	f	2025-11-21 23:06:39.274956+00	8	announcement	Se ha publicado un nuevo aviso en la Junta.	f
177	\N	\N	/avisos/	\N	f	2025-11-21 23:06:39.275123+00	9	announcement	Se ha publicado un nuevo aviso en la Junta.	f
153	\N	\N	/incidencias/mis-incidencias/	\N	t	2025-11-21 22:43:06.03245+00	5	incident	Se ha registrado una nueva incidencia en la Junta.	f
163	\N	\N	/avisos/	\N	t	2025-11-21 22:48:51.996208+00	5	announcement	Se ha publicado un nuevo aviso en la Junta.	f
171	\N	\N	/avisos/	\N	t	2025-11-21 23:06:39.274984+00	5	announcement	Se ha publicado un nuevo aviso en la Junta.	f
172	\N	\N	/avisos/	\N	t	2025-11-21 23:06:39.275002+00	3	announcement	Se ha publicado un nuevo aviso en la Junta.	f
178	\N	\N	/incidencias/mis-incidencias/	\N	f	2025-11-21 23:07:50.135444+00	8	incident	Se ha registrado una nueva incidencia en la Junta.	f
185	\N	\N	/incidencias/mis-incidencias/	\N	f	2025-11-21 23:07:50.135667+00	9	incident	Se ha registrado una nueva incidencia en la Junta.	f
182	\N	\N	/incidencias/mis-incidencias/	\N	t	2025-11-21 23:07:50.135577+00	5	incident	Se ha registrado una nueva incidencia en la Junta.	f
186	\N	\N	/incidencias/mis-incidencias/	\N	f	2025-11-21 23:14:00.175702+00	8	incident	Se ha registrado una nueva incidencia en la Junta.	f
191	\N	\N	/incidencias/mis-incidencias/	\N	t	2025-11-21 23:14:00.175827+00	3	incident	Se ha registrado una nueva incidencia en la Junta.	f
174	\N	\N	/avisos/	\N	t	2025-11-21 23:06:39.275053+00	2	announcement	Se ha publicado un nuevo aviso en la Junta.	f
173	\N	\N	/avisos/	\N	t	2025-11-21 23:06:39.275025+00	1	announcement	Se ha publicado un nuevo aviso en la Junta.	f
179	\N	\N	/incidencias/mis-incidencias/	\N	t	2025-11-21 23:07:50.135485+00	1	incident	Se ha registrado una nueva incidencia en la Junta.	f
187	\N	\N	/incidencias/mis-incidencias/	\N	t	2025-11-21 23:14:00.175741+00	1	incident	Se ha registrado una nueva incidencia en la Junta.	f
181	\N	\N	/incidencias/mis-incidencias/	\N	t	2025-11-21 23:07:50.13555+00	4	incident	Se ha registrado una nueva incidencia en la Junta.	f
189	\N	\N	/incidencias/mis-incidencias/	\N	t	2025-11-21 23:14:00.175794+00	4	incident	Se ha registrado una nueva incidencia en la Junta.	f
193	\N	\N	/incidencias/mis-incidencias/	\N	f	2025-11-21 23:14:00.17586+00	9	incident	Se ha registrado una nueva incidencia en la Junta.	f
194	\N	\N	/avisos/	\N	f	2025-11-21 23:14:39.736775+00	8	announcement	Se ha publicado un nuevo aviso en la Junta.	f
201	\N	\N	/avisos/	\N	f	2025-11-21 23:14:39.736919+00	9	announcement	Se ha publicado un nuevo aviso en la Junta.	f
199	\N	\N	/avisos/	\N	t	2025-11-21 23:14:39.736887+00	5	announcement	Se ha publicado un nuevo aviso en la Junta.	f
180	\N	\N	/incidencias/mis-incidencias/	\N	t	2025-11-21 23:07:50.13552+00	2	incident	Se ha registrado una nueva incidencia en la Junta.	f
188	\N	\N	/incidencias/mis-incidencias/	\N	t	2025-11-21 23:14:00.175775+00	2	incident	Se ha registrado una nueva incidencia en la Junta.	f
196	\N	\N	/avisos/	\N	t	2025-11-21 23:14:39.736836+00	2	announcement	Se ha publicado un nuevo aviso en la Junta.	f
164	\N	\N	/avisos/	\N	t	2025-11-21 22:48:51.996226+00	10	announcement	Se ha publicado un nuevo aviso en la Junta.	f
175	\N	\N	/avisos/	\N	t	2025-11-21 23:06:39.275086+00	10	announcement	Se ha publicado un nuevo aviso en la Junta.	f
183	\N	\N	/incidencias/mis-incidencias/	\N	t	2025-11-21 23:07:50.135605+00	10	incident	Se ha registrado una nueva incidencia en la Junta.	f
190	\N	\N	/incidencias/mis-incidencias/	\N	t	2025-11-21 23:14:00.175811+00	10	incident	Se ha registrado una nueva incidencia en la Junta.	f
198	\N	\N	/avisos/	\N	t	2025-11-21 23:14:39.73687+00	10	announcement	Se ha publicado un nuevo aviso en la Junta.	f
195	\N	\N	/avisos/	\N	t	2025-11-21 23:14:39.736815+00	1	announcement	Se ha publicado un nuevo aviso en la Junta.	f
202	\N	\N	/reuniones/	\N	t	2025-11-21 23:35:13.450914+00	2	meeting	Se ha programado una nueva reunión de la Junta.	f
204	\N	\N	/pagos/admin/	\N	t	2025-11-21 23:36:38.591201+00	2	payment_review	Hay un nuevo pago pendiente de revisión.	t
205	\N	\N	/pagos/admin/	\N	t	2025-11-21 23:36:38.591288+00	1	payment_review	Hay un nuevo pago pendiente de revisión.	f
209	\N	\N	/pagos/admin/	\N	t	2025-11-22 00:17:09.30227+00	1	payment_review	Hay un nuevo pago pendiente de revisión.	t
197	\N	\N	/avisos/	\N	t	2025-11-21 23:14:39.736853+00	4	announcement	Se ha publicado un nuevo aviso en la Junta.	f
207	\N	\N	/pagos/admin/	\N	t	2025-11-22 00:17:09.302218+00	2	payment_review	Hay un nuevo pago pendiente de revisión.	t
203	\N	\N	/reuniones/	\N	t	2025-11-21 23:35:13.450952+00	3	meeting	Se ha programado una nueva reunión de la Junta.	f
206	\N	\N	/pagos/admin/	\N	t	2025-11-21 23:36:38.591334+00	3	payment_review	Hay un nuevo pago pendiente de revisión.	f
208	\N	\N	/pagos/admin/	\N	t	2025-11-22 00:17:09.302248+00	3	payment_review	Hay un nuevo pago pendiente de revisión.	f
210	\N	\N	/avisos/	\N	f	2025-11-22 00:32:31.674678+00	8	announcement	Se ha publicado un nuevo aviso en la Junta.	f
214	\N	\N	/avisos/	\N	f	2025-11-22 00:32:31.674766+00	9	announcement	Se ha publicado un nuevo aviso en la Junta.	f
218	\N	\N	/avisos/	\N	t	2025-11-22 00:32:31.67484+00	4	announcement	Se ha publicado un nuevo aviso en la Junta.	f
219	\N	\N	/avisos/	\N	f	2025-11-22 00:32:53.166982+00	8	announcement	Se ha publicado un nuevo aviso en la Junta.	f
223	\N	\N	/avisos/	\N	f	2025-11-22 00:32:53.167127+00	9	announcement	Se ha publicado un nuevo aviso en la Junta.	f
217	\N	\N	/avisos/	\N	t	2025-11-22 00:32:31.674822+00	1	announcement	Se ha publicado un nuevo aviso en la Junta.	f
226	\N	\N	/avisos/	\N	t	2025-11-22 00:32:53.167224+00	1	announcement	Se ha publicado un nuevo aviso en la Junta.	f
228	\N	\N	/avisos/	\N	f	2025-11-22 00:34:03.14974+00	8	announcement	Se ha publicado un nuevo aviso en la Junta.	f
232	\N	\N	/avisos/	\N	f	2025-11-22 00:34:03.149849+00	9	announcement	Se ha publicado un nuevo aviso en la Junta.	f
236	\N	\N	/avisos/	\N	t	2025-11-22 00:34:03.14994+00	1	announcement	Se ha publicado un nuevo aviso en la Junta.	f
237	\N	\N	/reuniones/	\N	f	2025-11-22 00:34:32.439969+00	8	meeting	Se ha programado una nueva reunión de la Junta.	f
241	\N	\N	/reuniones/	\N	t	2025-11-22 00:34:32.440075+00	1	meeting	Se ha programado una nueva reunión de la Junta.	f
242	\N	\N	/reuniones/	\N	f	2025-11-22 00:34:58.159343+00	8	meeting	Se ha programado una nueva reunión de la Junta.	f
246	\N	\N	/reuniones/	\N	t	2025-11-22 00:34:58.159433+00	1	meeting	Se ha programado una nueva reunión de la Junta.	f
247	\N	\N	/incidencias/mis-incidencias/	\N	f	2025-11-22 00:36:30.738469+00	8	incident	Se ha registrado una nueva incidencia en la Junta.	f
251	\N	\N	/incidencias/mis-incidencias/	\N	t	2025-11-22 00:36:30.738567+00	1	incident	Se ha registrado una nueva incidencia en la Junta.	f
213	\N	\N	/avisos/	\N	t	2025-11-22 00:32:31.674747+00	5	announcement	Se ha publicado un nuevo aviso en la Junta.	f
222	\N	\N	/avisos/	\N	t	2025-11-22 00:32:53.167095+00	5	announcement	Se ha publicado un nuevo aviso en la Junta.	f
231	\N	\N	/avisos/	\N	t	2025-11-22 00:34:03.14983+00	5	announcement	Se ha publicado un nuevo aviso en la Junta.	f
215	\N	\N	/avisos/	\N	t	2025-11-22 00:32:31.674785+00	2	announcement	Se ha publicado un nuevo aviso en la Junta.	f
224	\N	\N	/avisos/	\N	t	2025-11-22 00:32:53.167157+00	2	announcement	Se ha publicado un nuevo aviso en la Junta.	f
233	\N	\N	/avisos/	\N	t	2025-11-22 00:34:03.149868+00	2	announcement	Se ha publicado un nuevo aviso en la Junta.	f
240	\N	\N	/reuniones/	\N	t	2025-11-22 00:34:32.440053+00	2	meeting	Se ha programado una nueva reunión de la Junta.	f
245	\N	\N	/reuniones/	\N	t	2025-11-22 00:34:58.159415+00	2	meeting	Se ha programado una nueva reunión de la Junta.	f
250	\N	\N	/incidencias/mis-incidencias/	\N	t	2025-11-22 00:36:30.738546+00	2	incident	Se ha registrado una nueva incidencia en la Junta.	f
216	\N	\N	/avisos/	\N	t	2025-11-22 00:32:31.674803+00	3	announcement	Se ha publicado un nuevo aviso en la Junta.	f
225	\N	\N	/avisos/	\N	t	2025-11-22 00:32:53.167191+00	3	announcement	Se ha publicado un nuevo aviso en la Junta.	f
234	\N	\N	/avisos/	\N	t	2025-11-22 00:34:03.149886+00	3	announcement	Se ha publicado un nuevo aviso en la Junta.	f
239	\N	\N	/reuniones/	\N	t	2025-11-22 00:34:32.44003+00	3	meeting	Se ha programado una nueva reunión de la Junta.	f
244	\N	\N	/reuniones/	\N	t	2025-11-22 00:34:58.159395+00	3	meeting	Se ha programado una nueva reunión de la Junta.	f
249	\N	\N	/incidencias/mis-incidencias/	\N	t	2025-11-22 00:36:30.738525+00	3	incident	Se ha registrado una nueva incidencia en la Junta.	f
227	\N	\N	/avisos/	\N	t	2025-11-22 00:32:53.167258+00	4	announcement	Se ha publicado un nuevo aviso en la Junta.	f
235	\N	\N	/avisos/	\N	t	2025-11-22 00:34:03.14992+00	4	announcement	Se ha publicado un nuevo aviso en la Junta.	f
238	\N	\N	/reuniones/	\N	t	2025-11-22 00:34:32.440004+00	4	meeting	Se ha programado una nueva reunión de la Junta.	f
243	\N	\N	/reuniones/	\N	t	2025-11-22 00:34:58.159374+00	4	meeting	Se ha programado una nueva reunión de la Junta.	f
248	\N	\N	/incidencias/mis-incidencias/	\N	t	2025-11-22 00:36:30.738502+00	4	incident	Se ha registrado una nueva incidencia en la Junta.	f
255	\N	\N	/pagos/admin/	\N	f	2025-11-22 00:40:48.408246+00	8	payment	Hay un nuevo pago pendiente de revisión.	f
253	\N	\N	/pagos/admin/	\N	t	2025-11-22 00:40:48.4082+00	4	payment	Hay un nuevo pago pendiente de revisión.	f
256	\N	\N	/pagos/admin/	\N	t	2025-11-22 00:40:48.408269+00	2	payment	Hay un nuevo pago pendiente de revisión.	t
259	\N	\N	/inscripcion/admin/	\N	f	2025-11-22 00:48:29.033736+00	8	subscription	Hay una nueva solicitud de inscripción pendiente de revisión.	t
252	\N	\N	/pagos/admin/	\N	t	2025-11-22 00:40:48.408166+00	1	payment	Hay un nuevo pago pendiente de revisión.	t
257	\N	\N	/inscripcion/admin/	\N	t	2025-11-22 00:48:29.033687+00	1	subscription	Hay una nueva solicitud de inscripción pendiente de revisión.	t
262	\N	\N	/incidencias/mis-incidencias/	\N	f	2025-11-22 01:14:52.012116+00	8	incident	Se ha registrado una nueva incidencia en la Junta.	f
263	\N	\N	/incidencias/mis-incidencias/	\N	t	2025-11-22 01:14:52.012142+00	1	incident	Se ha registrado una nueva incidencia en la Junta.	f
265	\N	\N	/avisos/	\N	f	2025-11-22 01:30:32.50264+00	8	announcement	Se ha publicado un nuevo aviso en la Junta.	f
254	\N	\N	/pagos/admin/	\N	t	2025-11-22 00:40:48.408223+00	3	payment	Hay un nuevo pago pendiente de revisión.	f
261	\N	\N	/incidencias/mis-incidencias/	\N	t	2025-11-22 01:14:52.012069+00	3	incident	Se ha registrado una nueva incidencia en la Junta.	f
266	\N	\N	/avisos/	\N	t	2025-11-22 01:30:32.502688+00	3	announcement	Se ha publicado un nuevo aviso en la Junta.	f
260	\N	\N	/incidencias/mis-incidencias/	\N	t	2025-11-22 01:14:52.011989+00	2	incident	Se ha registrado una nueva incidencia en la Junta.	f
212	\N	\N	/avisos/	\N	t	2025-11-22 00:32:31.674727+00	6	announcement	Se ha publicado un nuevo aviso en la Junta.	f
221	\N	\N	/avisos/	\N	t	2025-11-22 00:32:53.167062+00	6	announcement	Se ha publicado un nuevo aviso en la Junta.	f
230	\N	\N	/avisos/	\N	t	2025-11-22 00:34:03.149809+00	6	announcement	Se ha publicado un nuevo aviso en la Junta.	f
211	\N	\N	/avisos/	\N	t	2025-11-22 00:32:31.674706+00	10	announcement	Se ha publicado un nuevo aviso en la Junta.	f
220	\N	\N	/avisos/	\N	t	2025-11-22 00:32:53.167026+00	10	announcement	Se ha publicado un nuevo aviso en la Junta.	f
229	\N	\N	/avisos/	\N	t	2025-11-22 00:34:03.149771+00	10	announcement	Se ha publicado un nuevo aviso en la Junta.	f
273	\N	\N	/avisos/	\N	f	2025-11-22 01:30:32.50304+00	9	announcement	Se ha publicado un nuevo aviso en la Junta.	f
270	\N	\N	/avisos/	\N	t	2025-11-22 01:30:32.502913+00	1	announcement	Se ha publicado un nuevo aviso en la Junta.	f
258	\N	\N	/inscripcion/admin/	\N	t	2025-11-22 00:48:29.033717+00	4	subscription	Hay una nueva solicitud de inscripción pendiente de revisión.	t
264	\N	\N	/incidencias/mis-incidencias/	\N	t	2025-11-22 01:14:52.012162+00	4	incident	Se ha registrado una nueva incidencia en la Junta.	f
267	\N	\N	/avisos/	\N	t	2025-11-22 01:30:32.502741+00	4	announcement	Se ha publicado un nuevo aviso en la Junta.	f
274	\N	\N	/avisos/	\N	f	2025-11-22 01:31:32.49807+00	8	announcement	Se ha publicado un nuevo aviso en la Junta.	f
282	\N	\N	/avisos/	\N	f	2025-11-22 01:31:32.498231+00	9	announcement	Se ha publicado un nuevo aviso en la Junta.	f
279	\N	\N	/avisos/	\N	t	2025-11-22 01:31:32.498177+00	4	announcement	Se ha publicado un nuevo aviso en la Junta.	f
285	\N	\N	/reuniones/	\N	f	2025-11-22 01:32:44.295222+00	8	meeting	Se ha programado una nueva reunión de la Junta.	f
290	\N	\N	/incidencias/mis-incidencias/	\N	f	2025-11-22 01:33:21.296726+00	8	incident	Se ha registrado una nueva incidencia en la Junta.	f
286	\N	\N	/reuniones/	\N	t	2025-11-22 01:32:44.295245+00	4	meeting	Se ha programado una nueva reunión de la Junta.	f
291	\N	\N	/incidencias/mis-incidencias/	\N	t	2025-11-22 01:33:21.296745+00	4	incident	Se ha registrado una nueva incidencia en la Junta.	f
293	\N	\N	/avisos/	\N	f	2025-11-22 01:37:05.033536+00	8	announcement	Se ha publicado un nuevo aviso en la Junta.	f
301	\N	\N	/avisos/	\N	f	2025-11-22 01:37:05.033699+00	9	announcement	Se ha publicado un nuevo aviso en la Junta.	f
298	\N	\N	/avisos/	\N	t	2025-11-22 01:37:05.033644+00	4	announcement	Se ha publicado un nuevo aviso en la Junta.	f
304	\N	\N	/reuniones/	\N	f	2025-11-22 01:37:37.871305+00	8	meeting	Se ha programado una nueva reunión de la Junta.	f
309	\N	\N	/incidencias/mis-incidencias/	\N	f	2025-11-22 01:38:13.823098+00	8	incident	Se ha registrado una nueva incidencia en la Junta.	f
305	\N	\N	/reuniones/	\N	t	2025-11-22 01:37:37.871337+00	4	meeting	Se ha programado una nueva reunión de la Junta.	f
310	\N	\N	/incidencias/mis-incidencias/	\N	t	2025-11-22 01:38:13.823121+00	4	incident	Se ha registrado una nueva incidencia en la Junta.	f
312	\N	\N	/avisos/	\N	f	2025-11-22 02:13:06.196009+00	8	announcement	Se ha publicado un nuevo aviso en la Junta.	f
319	\N	\N	/avisos/	\N	f	2025-11-22 02:13:06.196154+00	9	announcement	Se ha publicado un nuevo aviso en la Junta.	f
322	\N	\N	/incidencias/mis-incidencias/	\N	f	2025-11-22 02:13:45.471455+00	8	incident	Se ha registrado una nueva incidencia en la Junta.	f
268	\N	\N	/avisos/	\N	t	2025-11-22 01:30:32.502786+00	2	announcement	Se ha publicado un nuevo aviso en la Junta.	f
276	\N	\N	/avisos/	\N	t	2025-11-22 01:31:32.49812+00	2	announcement	Se ha publicado un nuevo aviso en la Junta.	f
283	\N	\N	/reuniones/	\N	t	2025-11-22 01:32:44.295158+00	2	meeting	Se ha programado una nueva reunión de la Junta.	f
288	\N	\N	/incidencias/mis-incidencias/	\N	t	2025-11-22 01:33:21.296673+00	2	incident	Se ha registrado una nueva incidencia en la Junta.	f
295	\N	\N	/avisos/	\N	t	2025-11-22 01:37:05.033588+00	2	announcement	Se ha publicado un nuevo aviso en la Junta.	f
302	\N	\N	/reuniones/	\N	t	2025-11-22 01:37:37.871225+00	2	meeting	Se ha programado una nueva reunión de la Junta.	f
307	\N	\N	/incidencias/mis-incidencias/	\N	t	2025-11-22 01:38:13.823035+00	2	incident	Se ha registrado una nueva incidencia en la Junta.	f
314	\N	\N	/avisos/	\N	t	2025-11-22 02:13:06.19606+00	2	announcement	Se ha publicado un nuevo aviso en la Junta.	f
269	\N	\N	/avisos/	\N	t	2025-11-22 01:30:32.502829+00	5	announcement	Se ha publicado un nuevo aviso en la Junta.	f
277	\N	\N	/avisos/	\N	t	2025-11-22 01:31:32.498139+00	5	announcement	Se ha publicado un nuevo aviso en la Junta.	f
296	\N	\N	/avisos/	\N	t	2025-11-22 01:37:05.033608+00	5	announcement	Se ha publicado un nuevo aviso en la Junta.	f
315	\N	\N	/avisos/	\N	t	2025-11-22 02:13:06.19608+00	5	announcement	Se ha publicado un nuevo aviso en la Junta.	f
278	\N	\N	/avisos/	\N	t	2025-11-22 01:31:32.498157+00	1	announcement	Se ha publicado un nuevo aviso en la Junta.	f
287	\N	\N	/reuniones/	\N	t	2025-11-22 01:32:44.295269+00	1	meeting	Se ha programado una nueva reunión de la Junta.	f
292	\N	\N	/incidencias/mis-incidencias/	\N	t	2025-11-22 01:33:21.296763+00	1	incident	Se ha registrado una nueva incidencia en la Junta.	f
297	\N	\N	/avisos/	\N	t	2025-11-22 01:37:05.033626+00	1	announcement	Se ha publicado un nuevo aviso en la Junta.	f
306	\N	\N	/reuniones/	\N	t	2025-11-22 01:37:37.87137+00	1	meeting	Se ha programado una nueva reunión de la Junta.	f
311	\N	\N	/incidencias/mis-incidencias/	\N	t	2025-11-22 01:38:13.823145+00	1	incident	Se ha registrado una nueva incidencia en la Junta.	f
316	\N	\N	/avisos/	\N	t	2025-11-22 02:13:06.196098+00	1	announcement	Se ha publicado un nuevo aviso en la Junta.	f
272	\N	\N	/avisos/	\N	t	2025-11-22 01:30:32.503011+00	6	announcement	Se ha publicado un nuevo aviso en la Junta.	f
281	\N	\N	/avisos/	\N	t	2025-11-22 01:31:32.498213+00	6	announcement	Se ha publicado un nuevo aviso en la Junta.	f
300	\N	\N	/avisos/	\N	t	2025-11-22 01:37:05.033681+00	6	announcement	Se ha publicado un nuevo aviso en la Junta.	f
318	\N	\N	/avisos/	\N	t	2025-11-22 02:13:06.196135+00	6	announcement	Se ha publicado un nuevo aviso en la Junta.	f
271	\N	\N	/avisos/	\N	t	2025-11-22 01:30:32.502968+00	10	announcement	Se ha publicado un nuevo aviso en la Junta.	f
280	\N	\N	/avisos/	\N	t	2025-11-22 01:31:32.498195+00	10	announcement	Se ha publicado un nuevo aviso en la Junta.	f
299	\N	\N	/avisos/	\N	t	2025-11-22 01:37:05.033662+00	10	announcement	Se ha publicado un nuevo aviso en la Junta.	f
317	\N	\N	/avisos/	\N	t	2025-11-22 02:13:06.196117+00	10	announcement	Se ha publicado un nuevo aviso en la Junta.	f
326	\N	\N	/reuniones/	\N	f	2025-11-22 02:14:21.38665+00	8	meeting	Se ha programado una nueva reunión de la Junta.	f
329	\N	\N	/inscripcion/admin/	\N	f	2025-11-22 02:14:51.464728+00	8	subscription	Hay una nueva solicitud de inscripción pendiente de revisión.	t
330	\N	\N	/inscripcion/admin/	\N	t	2025-11-22 02:14:51.464755+00	4	subscription	Hay una nueva solicitud de inscripción pendiente de revisión.	t
275	\N	\N	/avisos/	\N	t	2025-11-22 01:31:32.498099+00	3	announcement	Se ha publicado un nuevo aviso en la Junta.	f
284	\N	\N	/reuniones/	\N	t	2025-11-22 01:32:44.295196+00	3	meeting	Se ha programado una nueva reunión de la Junta.	f
289	\N	\N	/incidencias/mis-incidencias/	\N	t	2025-11-22 01:33:21.296705+00	3	incident	Se ha registrado una nueva incidencia en la Junta.	f
294	\N	\N	/avisos/	\N	t	2025-11-22 01:37:05.033567+00	3	announcement	Se ha publicado un nuevo aviso en la Junta.	f
303	\N	\N	/reuniones/	\N	t	2025-11-22 01:37:37.871272+00	3	meeting	Se ha programado una nueva reunión de la Junta.	f
308	\N	\N	/incidencias/mis-incidencias/	\N	t	2025-11-22 01:38:13.823072+00	3	incident	Se ha registrado una nueva incidencia en la Junta.	f
313	\N	\N	/avisos/	\N	t	2025-11-22 02:13:06.19604+00	3	announcement	Se ha publicado un nuevo aviso en la Junta.	f
321	\N	\N	/incidencias/mis-incidencias/	\N	t	2025-11-22 02:13:45.471411+00	3	incident	Se ha registrado una nueva incidencia en la Junta.	f
325	\N	\N	/reuniones/	\N	t	2025-11-22 02:14:21.386621+00	3	meeting	Se ha programado una nueva reunión de la Junta.	f
334	\N	\N	/pagos/admin/	\N	f	2025-11-22 02:16:06.497217+00	8	payment	Hay un nuevo pago pendiente de revisión.	f
332	\N	\N	/pagos/admin/	\N	t	2025-11-22 02:16:06.497116+00	3	payment	Hay un nuevo pago pendiente de revisión.	f
320	\N	\N	/incidencias/mis-incidencias/	\N	t	2025-11-22 02:13:45.471365+00	2	incident	Se ha registrado una nueva incidencia en la Junta.	f
324	\N	\N	/reuniones/	\N	t	2025-11-22 02:14:21.386581+00	2	meeting	Se ha programado una nueva reunión de la Junta.	f
331	\N	\N	/pagos/admin/	\N	t	2025-11-22 02:16:06.497058+00	2	payment	Hay un nuevo pago pendiente de revisión.	t
338	\N	\N	/pagos/admin/	\N	f	2025-11-22 02:30:35.214069+00	8	payment	Hay un nuevo pago pendiente de revisión.	f
339	\N	\N	/pagos/admin/	\N	t	2025-11-22 02:30:35.214112+00	2	payment	Hay un nuevo pago pendiente de revisión.	t
341	\N	\N	/reservas/nueva/	\N	t	2025-11-22 02:31:09.395028+00	5	payment	Tu pago fue aprobado. Ya puedes hacer otra reserva.	f
345	\N	\N	/pagos/admin/	\N	f	2025-11-22 02:32:06.207649+00	8	payment	Hay un nuevo pago pendiente de revisión.	f
323	\N	\N	/incidencias/mis-incidencias/	\N	t	2025-11-22 02:13:45.47148+00	1	incident	Se ha registrado una nueva incidencia en la Junta.	f
327	\N	\N	/reuniones/	\N	t	2025-11-22 02:14:21.386678+00	1	meeting	Se ha programado una nueva reunión de la Junta.	f
328	\N	\N	/inscripcion/admin/	\N	t	2025-11-22 02:14:51.464692+00	1	subscription	Hay una nueva solicitud de inscripción pendiente de revisión.	t
333	\N	\N	/pagos/admin/	\N	t	2025-11-22 02:16:06.497172+00	1	payment	Hay un nuevo pago pendiente de revisión.	t
337	\N	\N	/pagos/admin/	\N	t	2025-11-22 02:30:35.214043+00	1	payment	Hay un nuevo pago pendiente de revisión.	t
344	\N	\N	/pagos/admin/	\N	t	2025-11-22 02:32:06.207629+00	1	payment	Hay un nuevo pago pendiente de revisión.	t
347	\N	\N	/mis-pagos/	\N	t	2025-11-22 02:32:40.934078+00	5	payment	Tu pago fue rechazado. Intenta nuevamente subiendo un nuevo comprobante.	f
351	\N	\N	/pagos/admin/	\N	f	2025-11-22 17:20:48.36922+00	8	payment	Hay un nuevo pago pendiente de revisión.	f
342	\N	\N	/pagos/admin/	\N	t	2025-11-22 02:32:06.20756+00	2	payment	Hay un nuevo pago pendiente de revisión.	t
349	\N	\N	/pagos/admin/	\N	t	2025-11-22 17:20:48.369166+00	2	payment	Hay un nuevo pago pendiente de revisión.	t
353	\N	\N	/reservas/nueva/	\N	t	2025-11-22 17:22:21.978613+00	5	payment	Tu pago fue aprobado. Ya puedes hacer otra reserva.	f
354	\N	\N	/reservas/nueva/	\N	t	2025-11-22 17:22:32.382926+00	5	payment	Tu pago fue aprobado. Ya puedes hacer otra reserva.	f
357	\N	\N	/pagos/admin/	\N	f	2025-11-22 17:23:48.959733+00	8	payment	Hay un nuevo pago pendiente de revisión.	f
361	\N	\N	/incidencias/mis-incidencias/	\N	f	2025-11-22 17:26:15.054151+00	8	incident	Se ha registrado una nueva incidencia en la Junta.	f
366	\N	\N	/incidencias/mis-incidencias/	\N	f	2025-11-22 17:42:02.373258+00	8	incident	Se ha registrado una nueva incidencia en la Junta.	f
371	\N	\N	/incidencias/mis-incidencias/	\N	f	2025-11-22 17:50:46.27801+00	8	incident	Se ha registrado una nueva incidencia en la Junta.	f
336	\N	\N	/pagos/admin/	\N	t	2025-11-22 02:30:35.213992+00	3	payment	Hay un nuevo pago pendiente de revisión.	f
343	\N	\N	/pagos/admin/	\N	t	2025-11-22 02:32:06.207606+00	3	payment	Hay un nuevo pago pendiente de revisión.	f
350	\N	\N	/pagos/admin/	\N	t	2025-11-22 17:20:48.369197+00	3	payment	Hay un nuevo pago pendiente de revisión.	f
335	\N	\N	/pagos/admin/	\N	t	2025-11-22 02:16:06.49726+00	4	payment	Hay un nuevo pago pendiente de revisión.	f
340	\N	\N	/pagos/admin/	\N	t	2025-11-22 02:30:35.214152+00	4	payment	Hay un nuevo pago pendiente de revisión.	f
346	\N	\N	/pagos/admin/	\N	t	2025-11-22 02:32:06.207668+00	4	payment	Hay un nuevo pago pendiente de revisión.	f
352	\N	\N	/pagos/admin/	\N	t	2025-11-22 17:20:48.369242+00	4	payment	Hay un nuevo pago pendiente de revisión.	f
358	\N	\N	/pagos/admin/	\N	t	2025-11-22 17:23:48.959754+00	4	payment	Hay un nuevo pago pendiente de revisión.	f
363	\N	\N	/incidencias/mis-incidencias/	\N	t	2025-11-22 17:26:15.054233+00	4	incident	Se ha registrado una nueva incidencia en la Junta.	f
368	\N	\N	/incidencias/mis-incidencias/	\N	t	2025-11-22 17:42:02.373299+00	4	incident	Se ha registrado una nueva incidencia en la Junta.	f
348	\N	\N	/pagos/admin/	\N	t	2025-11-22 17:20:48.369119+00	1	payment	Hay un nuevo pago pendiente de revisión.	t
355	\N	\N	/pagos/admin/	\N	t	2025-11-22 17:23:48.959675+00	1	payment	Hay un nuevo pago pendiente de revisión.	t
362	\N	\N	/incidencias/mis-incidencias/	\N	t	2025-11-22 17:26:15.054194+00	1	incident	Se ha registrado una nueva incidencia en la Junta.	f
367	\N	\N	/incidencias/mis-incidencias/	\N	t	2025-11-22 17:42:02.373278+00	1	incident	Se ha registrado una nueva incidencia en la Junta.	f
359	\N	\N	/pagos/admin/	\N	t	2025-11-22 17:23:48.959775+00	2	payment	Hay un nuevo pago pendiente de revisión.	t
364	\N	\N	/incidencias/mis-incidencias/	\N	t	2025-11-22 17:26:15.054272+00	2	incident	Se ha registrado una nueva incidencia en la Junta.	f
369	\N	\N	/incidencias/mis-incidencias/	\N	t	2025-11-22 17:42:02.373317+00	2	incident	Se ha registrado una nueva incidencia en la Junta.	f
374	\N	\N	/incidencias/mis-incidencias/	\N	t	2025-11-22 17:50:46.278125+00	2	incident	Se ha registrado una nueva incidencia en la Junta.	f
375	\N	\N	/mis-pagos/	\N	t	2025-11-22 18:28:38.106306+00	5	payment	Tu pago fue rechazado. Intenta nuevamente subiendo un nuevo comprobante.	f
378	\N	\N	/pagos/admin/	\N	f	2025-11-22 18:39:54.381888+00	8	payment	Hay un nuevo pago pendiente de revisión.	f
380	\N	\N	/pagos/admin/	\N	t	2025-11-22 18:39:54.382095+00	2	payment	Hay un nuevo pago pendiente de revisión.	t
381	\N	\N	/mis-pagos/	\N	t	2025-11-22 18:42:40.442505+00	5	payment	Tu pago fue rechazado. Intenta nuevamente subiendo un nuevo comprobante.	f
382	\N	\N	/reservas/nueva/	\N	t	2025-11-22 18:44:40.061761+00	5	payment	Tu pago fue aprobado. Ya puedes hacer otra reserva.	f
383	\N	\N	/mis-pagos/	\N	t	2025-11-22 18:44:40.127747+00	5	payment	Tu pago fue aprobado. Ya puedes hacer otra reserva.	f
386	\N	\N	/pagos/admin/	\N	f	2025-11-22 18:47:08.478348+00	8	payment	Hay un nuevo pago pendiente de revisión.	f
388	\N	\N	/pagos/admin/	\N	t	2025-11-22 18:47:08.478389+00	2	payment	Hay un nuevo pago pendiente de revisión.	t
389	\N	\N	/mis-pagos/	\N	t	2025-11-22 18:53:18.598909+00	5	payment	Tu pago fue rechazado. Intenta nuevamente subiendo un nuevo comprobante.	f
390	\N	\N	/mis-pagos/	\N	t	2025-11-22 18:59:35.780844+00	5	payment	Tu pago fue rechazado. Intenta nuevamente subiendo un nuevo comprobante.	f
356	\N	\N	/pagos/admin/	\N	t	2025-11-22 17:23:48.95971+00	3	payment	Hay un nuevo pago pendiente de revisión.	f
360	\N	\N	/incidencias/mis-incidencias/	\N	t	2025-11-22 17:26:15.054095+00	3	incident	Se ha registrado una nueva incidencia en la Junta.	f
365	\N	\N	/incidencias/mis-incidencias/	\N	t	2025-11-22 17:42:02.373219+00	3	incident	Se ha registrado una nueva incidencia en la Junta.	f
370	\N	\N	/incidencias/mis-incidencias/	\N	t	2025-11-22 17:50:46.277953+00	3	incident	Se ha registrado una nueva incidencia en la Junta.	f
377	\N	\N	/pagos/admin/	\N	t	2025-11-22 18:39:54.381849+00	3	payment	Hay un nuevo pago pendiente de revisión.	f
385	\N	\N	/pagos/admin/	\N	t	2025-11-22 18:47:08.478325+00	3	payment	Hay un nuevo pago pendiente de revisión.	f
391	\N	\N	/avisos/	\N	f	2025-11-22 19:33:55.897527+00	8	announcement	Se ha publicado un nuevo aviso en la Junta.	f
399	\N	\N	/avisos/	\N	f	2025-11-22 19:33:55.897714+00	9	announcement	Se ha publicado un nuevo aviso en la Junta.	f
394	\N	\N	/avisos/	\N	t	2025-11-22 19:33:55.8976+00	3	announcement	Se ha publicado un nuevo aviso en la Junta.	f
400	\N	\N	/avisos/	\N	f	2025-11-22 19:48:19.210754+00	8	announcement	Se ha publicado un nuevo aviso en la Junta.	f
408	\N	\N	/avisos/	\N	f	2025-11-22 19:48:19.21095+00	9	announcement	Se ha publicado un nuevo aviso en la Junta.	f
403	\N	\N	/avisos/	\N	t	2025-11-22 19:48:19.210833+00	3	announcement	Se ha publicado un nuevo aviso en la Junta.	f
409	\N	\N	/avisos/	\N	f	2025-11-22 19:58:32.81889+00	8	announcement	Se ha publicado un nuevo aviso en la Junta.	f
417	\N	\N	/avisos/	\N	f	2025-11-22 19:58:32.819099+00	9	announcement	Se ha publicado un nuevo aviso en la Junta.	f
412	\N	\N	/avisos/	\N	t	2025-11-22 19:58:32.818984+00	3	announcement	Se ha publicado un nuevo aviso en la Junta.	f
418	\N	\N	/avisos/	\N	f	2025-11-22 20:37:09.149824+00	8	announcement	Se ha publicado un nuevo aviso en la Junta.	f
392	\N	\N	/avisos/	\N	t	2025-11-22 19:33:55.897559+00	2	announcement	Se ha publicado un nuevo aviso en la Junta.	f
401	\N	\N	/avisos/	\N	t	2025-11-22 19:48:19.210787+00	2	announcement	Se ha publicado un nuevo aviso en la Junta.	f
410	\N	\N	/avisos/	\N	t	2025-11-22 19:58:32.818922+00	2	announcement	Se ha publicado un nuevo aviso en la Junta.	f
419	\N	\N	/avisos/	\N	t	2025-11-22 20:37:09.149854+00	2	announcement	Se ha publicado un nuevo aviso en la Junta.	f
373	\N	\N	/incidencias/mis-incidencias/	\N	t	2025-11-22 17:50:46.278087+00	4	incident	Se ha registrado una nueva incidencia en la Junta.	f
379	\N	\N	/pagos/admin/	\N	t	2025-11-22 18:39:54.382057+00	4	payment	Hay un nuevo pago pendiente de revisión.	f
387	\N	\N	/pagos/admin/	\N	t	2025-11-22 18:47:08.478369+00	4	payment	Hay un nuevo pago pendiente de revisión.	f
396	\N	\N	/avisos/	\N	t	2025-11-22 19:33:55.897637+00	4	announcement	Se ha publicado un nuevo aviso en la Junta.	f
372	\N	\N	/incidencias/mis-incidencias/	\N	t	2025-11-22 17:50:46.278053+00	1	incident	Se ha registrado una nueva incidencia en la Junta.	f
376	\N	\N	/pagos/admin/	\N	t	2025-11-22 18:39:54.38178+00	1	payment	Hay un nuevo pago pendiente de revisión.	t
384	\N	\N	/pagos/admin/	\N	t	2025-11-22 18:47:08.47828+00	1	payment	Hay un nuevo pago pendiente de revisión.	t
398	\N	\N	/avisos/	\N	t	2025-11-22 19:33:55.897677+00	1	announcement	Se ha publicado un nuevo aviso en la Junta.	f
407	\N	\N	/avisos/	\N	t	2025-11-22 19:48:19.210927+00	1	announcement	Se ha publicado un nuevo aviso en la Junta.	f
416	\N	\N	/avisos/	\N	t	2025-11-22 19:58:32.819069+00	1	announcement	Se ha publicado un nuevo aviso en la Junta.	f
397	\N	\N	/avisos/	\N	t	2025-11-22 19:33:55.897655+00	6	announcement	Se ha publicado un nuevo aviso en la Junta.	f
406	\N	\N	/avisos/	\N	t	2025-11-22 19:48:19.210902+00	6	announcement	Se ha publicado un nuevo aviso en la Junta.	f
415	\N	\N	/avisos/	\N	t	2025-11-22 19:58:32.819043+00	6	announcement	Se ha publicado un nuevo aviso en la Junta.	f
423	\N	\N	/avisos/	\N	t	2025-11-22 20:37:09.149933+00	6	announcement	Se ha publicado un nuevo aviso en la Junta.	f
395	\N	\N	/avisos/	\N	t	2025-11-22 19:33:55.897619+00	10	announcement	Se ha publicado un nuevo aviso en la Junta.	f
404	\N	\N	/avisos/	\N	t	2025-11-22 19:48:19.210856+00	10	announcement	Se ha publicado un nuevo aviso en la Junta.	f
413	\N	\N	/avisos/	\N	t	2025-11-22 19:58:32.819005+00	10	announcement	Se ha publicado un nuevo aviso en la Junta.	f
421	\N	\N	/avisos/	\N	t	2025-11-22 20:37:09.149895+00	10	announcement	Se ha publicado un nuevo aviso en la Junta.	f
425	\N	\N	/avisos/	\N	f	2025-11-22 20:37:09.149971+00	9	announcement	Se ha publicado un nuevo aviso en la Junta.	f
427	\N	\N	/incidencias/mis-incidencias/	\N	f	2025-11-22 20:46:16.747561+00	8	incident	Se ha registrado una nueva incidencia en la Junta.	f
431	\N	\N	/incidencias/mis-incidencias/	\N	f	2025-11-22 20:47:56.047145+00	8	incident	Se ha registrado una nueva incidencia en la Junta.	f
393	\N	\N	/avisos/	\N	t	2025-11-22 19:33:55.89758+00	5	announcement	Se ha publicado un nuevo aviso en la Junta.	f
402	\N	\N	/avisos/	\N	t	2025-11-22 19:48:19.210811+00	5	announcement	Se ha publicado un nuevo aviso en la Junta.	f
411	\N	\N	/avisos/	\N	t	2025-11-22 19:58:32.818954+00	5	announcement	Se ha publicado un nuevo aviso en la Junta.	f
420	\N	\N	/avisos/	\N	t	2025-11-22 20:37:09.149875+00	5	announcement	Se ha publicado un nuevo aviso en la Junta.	f
436	\N	\N	/pagos/admin/	\N	f	2025-11-22 21:19:10.547075+00	8	payment	Hay un nuevo pago pendiente de revisión.	f
438	\N	\N	/pagos/admin/	\N	t	2025-11-22 21:19:10.54713+00	3	payment	Hay un nuevo pago pendiente de revisión.	f
426	\N	\N	/incidencias/mis-incidencias/	\N	t	2025-11-22 20:46:16.747521+00	2	incident	Se ha registrado una nueva incidencia en la Junta.	f
430	\N	\N	/incidencias/mis-incidencias/	\N	t	2025-11-22 20:47:56.047109+00	2	incident	Se ha registrado una nueva incidencia en la Junta.	f
435	\N	\N	/pagos/admin/	\N	t	2025-11-22 21:19:10.547046+00	2	payment	Hay un nuevo pago pendiente de revisión.	t
439	\N	\N	/reservas/nueva/	\N	t	2025-11-22 21:20:07.104569+00	3	payment	Tu pago fue aprobado. Ya puedes hacer otra reserva.	f
440	\N	\N	/mis-pagos/	\N	t	2025-11-22 21:20:07.171538+00	3	payment	Tu pago fue aprobado. Ya puedes hacer otra reserva.	f
441	\N	\N	/mis-pagos/	\N	t	2025-11-22 21:20:07.553304+00	3	payment	Tu pago fue aprobado. Ya puedes hacer otra reserva.	f
405	\N	\N	/avisos/	\N	t	2025-11-22 19:48:19.210879+00	4	announcement	Se ha publicado un nuevo aviso en la Junta.	f
414	\N	\N	/avisos/	\N	t	2025-11-22 19:58:32.819024+00	4	announcement	Se ha publicado un nuevo aviso en la Junta.	f
422	\N	\N	/avisos/	\N	t	2025-11-22 20:37:09.149914+00	4	announcement	Se ha publicado un nuevo aviso en la Junta.	f
429	\N	\N	/incidencias/mis-incidencias/	\N	t	2025-11-22 20:46:16.747616+00	4	incident	Se ha registrado una nueva incidencia en la Junta.	f
433	\N	\N	/incidencias/mis-incidencias/	\N	t	2025-11-22 20:47:56.047198+00	4	incident	Se ha registrado una nueva incidencia en la Junta.	f
437	\N	\N	/pagos/admin/	\N	t	2025-11-22 21:19:10.547103+00	4	payment	Hay un nuevo pago pendiente de revisión.	f
444	\N	\N	/pagos/admin/	\N	f	2025-11-22 23:24:23.802617+00	3	payment	Hay un nuevo pago pendiente de revisión.	f
446	\N	\N	/pagos/admin/	\N	f	2025-11-22 23:24:23.80272+00	8	payment	Hay un nuevo pago pendiente de revisión.	f
445	\N	\N	/pagos/admin/	\N	t	2025-11-22 23:24:23.802669+00	2	payment	Hay un nuevo pago pendiente de revisión.	t
442	\N	\N	/pagos/admin/	\N	t	2025-11-22 23:24:23.802499+00	4	payment	Hay un nuevo pago pendiente de revisión.	f
447	\N	\N	/avisos/	\N	f	2025-11-22 23:57:48.162707+00	8	announcement	Se ha publicado un nuevo aviso en la Junta.	f
450	\N	\N	/avisos/	\N	f	2025-11-22 23:57:48.16279+00	3	announcement	Se ha publicado un nuevo aviso en la Junta.	f
454	\N	\N	/avisos/	\N	f	2025-11-22 23:57:48.162871+00	9	announcement	Se ha publicado un nuevo aviso en la Junta.	f
455	\N	\N	/avisos/	\N	f	2025-11-22 23:57:48.162888+00	11	announcement	Se ha publicado un nuevo aviso en la Junta.	f
453	\N	\N	/avisos/	\N	t	2025-11-22 23:57:48.162853+00	2	announcement	Se ha publicado un nuevo aviso en la Junta.	f
456	\N	\N	/mis-pagos/	\N	f	2025-11-23 01:33:17.950668+00	3	payment	Tu pago fue rechazado. Intenta nuevamente subiendo un nuevo comprobante.	f
457	\N	\N	/reservas/nueva/	\N	f	2025-11-23 01:33:47.118474+00	3	payment	Tu pago fue aprobado. Ya puedes hacer otra reserva.	f
458	\N	\N	/mis-pagos/	\N	f	2025-11-23 01:33:47.327067+00	3	payment	Tu pago fue aprobado. Ya puedes hacer otra reserva.	f
459	\N	\N	/mis-pagos/	\N	f	2025-11-23 01:47:14.899899+00	3	payment	Tu pago fue rechazado. Intenta nuevamente subiendo un nuevo comprobante.	f
460	\N	\N	/reservas/nueva/	\N	f	2025-11-23 01:50:08.093273+00	3	payment	Tu pago fue aprobado. Ya puedes hacer otra reserva.	f
461	\N	\N	/mis-pagos/	\N	f	2025-11-23 01:50:08.296896+00	3	payment	Tu pago fue aprobado. Ya puedes hacer otra reserva.	f
462	\N	\N	/mis-pagos/	\N	f	2025-11-23 01:50:56.27055+00	3	payment	Tu pago fue rechazado. Intenta nuevamente subiendo un nuevo comprobante.	f
463	\N	\N	/reservas/nueva/	\N	f	2025-11-23 01:56:03.037764+00	3	payment	Tu pago fue aprobado. Ya puedes hacer otra reserva.	f
464	\N	\N	/mis-pagos/	\N	f	2025-11-23 01:56:03.238985+00	3	payment	Tu pago fue aprobado. Ya puedes hacer otra reserva.	f
465	\N	\N	/mis-pagos/	\N	f	2025-11-23 02:08:01.413861+00	3	payment	Tu pago fue rechazado. Intenta nuevamente subiendo un nuevo comprobante.	f
466	\N	\N	/reservas/nueva/	\N	f	2025-11-23 02:08:13.354184+00	3	payment	Tu pago fue aprobado. Ya puedes hacer otra reserva.	f
467	\N	\N	/mis-pagos/	\N	f	2025-11-23 02:08:13.419866+00	3	payment	Tu pago fue aprobado. Ya puedes hacer otra reserva.	f
468	\N	\N	/mis-pagos/	\N	f	2025-11-23 02:09:06.081309+00	3	payment	Tu pago fue rechazado. Intenta nuevamente subiendo un nuevo comprobante.	f
469	\N	\N	/reservas/nueva/	\N	f	2025-11-23 02:14:31.986996+00	3	payment	Tu pago fue aprobado. Ya puedes hacer otra reserva.	f
470	\N	\N	/mis-pagos/	\N	f	2025-11-23 02:14:32.099066+00	3	payment	Tu pago fue aprobado. Ya puedes hacer otra reserva.	f
473	\N	\N	/inscripcion/admin/	\N	f	2025-11-23 02:25:00.619264+00	8	subscription	Hay una nueva solicitud de inscripción pendiente de revisión.	t
424	\N	\N	/avisos/	\N	t	2025-11-22 20:37:09.149952+00	1	announcement	Se ha publicado un nuevo aviso en la Junta.	f
434	\N	\N	/pagos/admin/	\N	t	2025-11-22 21:19:10.547006+00	1	payment	Hay un nuevo pago pendiente de revisión.	t
449	\N	\N	/avisos/	\N	t	2025-11-22 23:57:48.162766+00	6	announcement	Se ha publicado un nuevo aviso en la Junta.	f
452	\N	\N	/avisos/	\N	t	2025-11-22 23:57:48.162834+00	5	announcement	Se ha publicado un nuevo aviso en la Junta.	f
448	\N	\N	/avisos/	\N	t	2025-11-22 23:57:48.162741+00	10	announcement	Se ha publicado un nuevo aviso en la Junta.	f
472	\N	\N	/inscripcion/admin/	\N	t	2025-11-23 02:25:00.619226+00	4	subscription	Hay una nueva solicitud de inscripción pendiente de revisión.	t
428	\N	\N	/incidencias/mis-incidencias/	\N	t	2025-11-22 20:46:16.747588+00	1	incident	Se ha registrado una nueva incidencia en la Junta.	f
432	\N	\N	/incidencias/mis-incidencias/	\N	t	2025-11-22 20:47:56.047173+00	1	incident	Se ha registrado una nueva incidencia en la Junta.	f
443	\N	\N	/pagos/admin/	\N	t	2025-11-22 23:24:23.802565+00	1	payment	Hay un nuevo pago pendiente de revisión.	t
451	\N	\N	/avisos/	\N	t	2025-11-22 23:57:48.162812+00	1	announcement	Se ha publicado un nuevo aviso en la Junta.	f
471	\N	\N	/inscripcion/admin/	\N	t	2025-11-23 02:25:00.619154+00	1	subscription	Hay una nueva solicitud de inscripción pendiente de revisión.	t
106	\N	\N	/avisos/	\N	t	2025-11-21 22:22:34.386754+00	6	announcement	Se ha publicado un nuevo aviso en la Junta.	f
116	\N	\N	/avisos/	\N	t	2025-11-21 22:34:27.993036+00	6	announcement	Se ha publicado un nuevo aviso en la Junta.	f
130	\N	\N	/avisos/	\N	t	2025-11-21 22:36:52.400106+00	6	announcement	Se ha publicado un nuevo aviso en la Junta.	f
139	\N	\N	/avisos/	\N	t	2025-11-21 22:42:44.084616+00	6	announcement	Se ha publicado un nuevo aviso en la Junta.	f
148	\N	\N	/incidencias/mis-incidencias/	\N	t	2025-11-21 22:43:06.03235+00	6	incident	Se ha registrado una nueva incidencia en la Junta.	f
156	\N	\N	/incidencias/mis-incidencias/	\N	t	2025-11-21 22:44:51.586019+00	6	incident	Se ha registrado una nueva incidencia en la Junta.	f
165	\N	\N	/avisos/	\N	t	2025-11-21 22:48:51.996243+00	6	announcement	Se ha publicado un nuevo aviso en la Junta.	f
176	\N	\N	/avisos/	\N	t	2025-11-21 23:06:39.275106+00	6	announcement	Se ha publicado un nuevo aviso en la Junta.	f
184	\N	\N	/incidencias/mis-incidencias/	\N	t	2025-11-21 23:07:50.135633+00	6	incident	Se ha registrado una nueva incidencia en la Junta.	f
192	\N	\N	/incidencias/mis-incidencias/	\N	t	2025-11-21 23:14:00.175844+00	6	incident	Se ha registrado una nueva incidencia en la Junta.	f
200	\N	\N	/avisos/	\N	t	2025-11-21 23:14:39.736903+00	6	announcement	Se ha publicado un nuevo aviso en la Junta.	f
475	\N	\N	/inscripcion/admin/	\N	f	2025-11-23 19:41:25.38553+00	4	subscription	Hay una nueva solicitud de inscripción pendiente de revisión.	t
476	\N	\N	/inscripcion/admin/	\N	f	2025-11-23 19:41:25.385578+00	8	subscription	Hay una nueva solicitud de inscripción pendiente de revisión.	t
478	\N	\N	/inscripcion/admin/	\N	f	2025-11-23 19:41:58.632481+00	4	subscription	Hay una nueva solicitud de inscripción pendiente de revisión.	t
479	\N	\N	/inscripcion/admin/	\N	f	2025-11-23 19:41:58.632512+00	8	subscription	Hay una nueva solicitud de inscripción pendiente de revisión.	t
481	\N	\N	/inscripcion/admin/	\N	f	2025-11-23 19:47:37.666947+00	4	subscription	Hay una nueva solicitud de inscripción pendiente de revisión.	t
482	\N	\N	/inscripcion/admin/	\N	f	2025-11-23 19:47:37.666986+00	8	subscription	Hay una nueva solicitud de inscripción pendiente de revisión.	t
484	\N	\N	/inscripcion/admin/	\N	f	2025-11-24 19:01:58.683258+00	4	subscription	Hay una nueva solicitud de inscripción pendiente de revisión.	t
485	\N	\N	/inscripcion/admin/	\N	f	2025-11-24 19:01:58.683283+00	8	subscription	Hay una nueva solicitud de inscripción pendiente de revisión.	t
474	\N	\N	/inscripcion/admin/	\N	t	2025-11-23 19:41:25.385473+00	1	subscription	Hay una nueva solicitud de inscripción pendiente de revisión.	t
477	\N	\N	/inscripcion/admin/	\N	t	2025-11-23 19:41:58.632433+00	1	subscription	Hay una nueva solicitud de inscripción pendiente de revisión.	t
480	\N	\N	/inscripcion/admin/	\N	t	2025-11-23 19:47:37.666897+00	1	subscription	Hay una nueva solicitud de inscripción pendiente de revisión.	t
483	\N	\N	/inscripcion/admin/	\N	t	2025-11-24 19:01:58.683217+00	1	subscription	Hay una nueva solicitud de inscripción pendiente de revisión.	t
155	\N	\N	/incidencias/mis-incidencias/	\N	t	2025-11-21 22:44:51.586+00	10	incident	Se ha registrado una nueva incidencia en la Junta.	f
486	\N	\N	/inscripcion/admin/	\N	f	2025-11-24 22:34:04.671114+00	4	subscription	Hay una nueva solicitud de inscripción pendiente de revisión.	t
487	\N	\N	/inscripcion/admin/	\N	f	2025-11-24 22:34:04.671154+00	8	subscription	Hay una nueva solicitud de inscripción pendiente de revisión.	t
488	\N	\N	/inscripcion/admin/	\N	t	2025-11-24 22:34:04.671181+00	1	subscription	Hay una nueva solicitud de inscripción pendiente de revisión.	t
489	\N	\N	/incidencias/mis-incidencias/	\N	f	2025-11-25 14:41:28.766994+00	2	incident	Se ha registrado una nueva incidencia en la Junta.	f
490	\N	\N	/incidencias/mis-incidencias/	\N	f	2025-11-25 14:41:28.767031+00	3	incident	Se ha registrado una nueva incidencia en la Junta.	f
491	\N	\N	/incidencias/mis-incidencias/	\N	f	2025-11-25 14:41:28.767055+00	8	incident	Se ha registrado una nueva incidencia en la Junta.	f
493	\N	\N	/incidencias/mis-incidencias/	\N	f	2025-11-25 14:41:28.76712+00	4	incident	Se ha registrado una nueva incidencia en la Junta.	f
494	\N	\N	/pagos/admin/	\N	f	2025-11-25 14:42:52.978488+00	2	payment	Hay un nuevo pago pendiente de revisión.	t
495	\N	\N	/pagos/admin/	\N	f	2025-11-25 14:42:52.978533+00	4	payment	Hay un nuevo pago pendiente de revisión.	f
496	\N	\N	/pagos/admin/	\N	f	2025-11-25 14:42:52.97856+00	3	payment	Hay un nuevo pago pendiente de revisión.	f
497	\N	\N	/pagos/admin/	\N	f	2025-11-25 14:42:52.978584+00	8	payment	Hay un nuevo pago pendiente de revisión.	f
492	\N	\N	/incidencias/mis-incidencias/	\N	t	2025-11-25 14:41:28.767078+00	1	incident	Se ha registrado una nueva incidencia en la Junta.	f
498	\N	\N	/pagos/admin/	\N	t	2025-11-25 14:42:52.978608+00	1	payment	Hay un nuevo pago pendiente de revisión.	t
500	\N	\N	/inscripcion/admin/	\N	f	2025-11-25 15:51:50.740929+00	4	subscription	Hay una nueva solicitud de inscripción pendiente de revisión.	t
501	\N	\N	/inscripcion/admin/	\N	f	2025-11-25 15:51:50.740973+00	8	subscription	Hay una nueva solicitud de inscripción pendiente de revisión.	t
499	\N	\N	/inscripcion/admin/	\N	t	2025-11-25 15:51:50.740876+00	1	subscription	Hay una nueva solicitud de inscripción pendiente de revisión.	t
502	\N	\N	/pagos/admin/	\N	f	2025-11-25 15:55:08.648193+00	2	payment	Hay un nuevo pago pendiente de revisión.	t
503	\N	\N	/pagos/admin/	\N	f	2025-11-25 15:55:08.648236+00	4	payment	Hay un nuevo pago pendiente de revisión.	f
504	\N	\N	/pagos/admin/	\N	f	2025-11-25 15:55:08.648261+00	1	payment	Hay un nuevo pago pendiente de revisión.	t
505	\N	\N	/pagos/admin/	\N	f	2025-11-25 15:55:08.648285+00	3	payment	Hay un nuevo pago pendiente de revisión.	f
506	\N	\N	/pagos/admin/	\N	f	2025-11-25 15:55:08.648308+00	8	payment	Hay un nuevo pago pendiente de revisión.	f
\.


--
-- Data for Name: core_payment; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.core_payment (id, amount, status, paid_at, created_at, fee_id, resident_id, origin, reservation_id, receipt_file, receipt_uploaded_at, review_comment, reviewed_at, reviewed_by_id) FROM stdin;
34	25000.00	paid	2025-11-22 21:20:06.899787+00	2025-11-22 21:19:10.050173+00	\N	3	reservation	36		\N		2025-11-23 02:14:31.653137+00	2
36	20000.00	pending	\N	2025-11-25 14:42:51.727664+00	\N	10	reservation	38		\N	\N	\N	\N
3	25000.00	paid	2025-11-18 04:45:01.38441+00	2025-11-17 23:26:49.941571+00	\N	5	reservation	3		\N		2025-11-18 04:45:01.384406+00	2
37	25000.00	pending_review	\N	2025-11-25 15:55:07.407272+00	\N	14	reservation	39	payment_receipts/Imagen_de_WhatsApp_2025-09-08_a_las_17.35.54_a25aaba6.jpg	2025-11-25 15:55:53.389552+00	\N	\N	\N
10	20000.00	paid	2025-11-20 18:16:47.769131+00	2025-11-20 16:34:37.11251+00	\N	10	reservation	11		\N		2025-11-20 18:16:47.769126+00	2
9	25000.00	paid	2025-11-20 18:16:55.684643+00	2025-11-20 16:32:07.672784+00	\N	10	reservation	10		\N		2025-11-20 18:16:55.684639+00	2
8	20000.00	paid	2025-11-20 18:17:04.377997+00	2025-11-20 02:30:48.979799+00	\N	10	reservation	8		\N		2025-11-20 18:17:04.377993+00	2
7	20000.00	paid	2025-11-20 18:17:17.098046+00	2025-11-20 00:59:48.701948+00	\N	5	reservation	7		\N		2025-11-20 18:17:17.098041+00	2
22	20000.00	paid	2025-11-20 23:55:31.866804+00	2025-11-20 23:49:44.937516+00	\N	5	reservation	23		\N		2025-11-21 00:04:19.83139+00	2
24	20000.00	paid	2025-11-22 00:15:45.433706+00	2025-11-21 23:36:38.267961+00	\N	5	reservation	26		\N		2025-11-22 00:15:45.4337+00	2
25	20000.00	paid	2025-11-22 00:35:36.891138+00	2025-11-22 00:17:08.990793+00	\N	3	reservation	27		\N		2025-11-22 00:35:36.891129+00	1
28	25000.00	paid	2025-11-22 02:31:09.206907+00	2025-11-22 02:30:34.78096+00	\N	5	reservation	30	payment_receipts/bici.jpg	2025-11-22 02:30:47.338962+00		2025-11-22 02:31:09.206901+00	2
29	25000.00	paid	2025-11-22 17:22:21.777248+00	2025-11-22 02:32:05.769961+00	\N	5	reservation	31		\N		2025-11-22 17:22:21.777243+00	2
30	20000.00	paid	2025-11-22 17:22:32.181878+00	2025-11-22 17:20:47.849609+00	\N	5	reservation	32		\N		2025-11-22 17:22:32.181873+00	2
32	20000.00	paid	2025-11-22 18:44:39.86438+00	2025-11-22 18:39:53.904452+00	\N	5	reservation	34	payment_receipts/certificado_residencia_1_Q8xEAW7.pdf	2025-11-22 18:43:08.31508+00		2025-11-22 18:44:39.864374+00	2
\.


--
-- Data for Name: core_reservation; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.core_reservation (id, title, notes, start_at, end_at, status, approved_at, cancelled_at, created_at, updated_at, approved_by_id, requested_by_id, resource_id, cancel_reason) FROM stdin;
1	Uso cancha de futbol 2		2025-11-17 20:59:00+00	2025-11-17 21:59:00+00	PENDING	\N	\N	2025-11-16 23:59:10.102557+00	2025-11-16 23:59:10.102569+00	\N	1	2	\N
3	Uso cancha de padel 2		2025-11-21 20:26:00+00	2025-11-21 21:26:00+00	PENDING	\N	\N	2025-11-17 23:26:49.865815+00	2025-11-17 23:26:49.865827+00	\N	5	6	\N
2	Uso cancha de padel 1		2025-11-17 21:00:00+00	2025-11-17 22:00:00+00	CANCELLED	\N	2025-11-17 23:26:56.240671+00	2025-11-17 00:00:05.530432+00	2025-11-17 23:26:56.427304+00	\N	5	5	\N
4	Uso cancha de basquetbol 1		2025-11-21 23:05:00+00	2025-11-22 00:05:00+00	PENDING	\N	\N	2025-11-18 02:06:01.27959+00	2025-11-18 02:06:01.279599+00	\N	3	3	\N
6	Uso cancha de padel 2		2025-11-23 12:00:00+00	2025-11-23 13:00:00+00	PENDING	\N	\N	2025-11-18 15:25:14.389765+00	2025-11-18 15:25:14.389775+00	\N	5	6	\N
7	Uso cancha de futbol 1		2025-11-20 22:00:00+00	2025-11-20 23:00:00+00	PENDING	\N	\N	2025-11-20 00:59:48.632136+00	2025-11-20 00:59:48.632146+00	\N	5	1	\N
8	Uso cancha de futbol 1		2025-11-20 17:00:00+00	2025-11-20 18:00:00+00	CANCELLED	\N	2025-11-20 16:09:50.989498+00	2025-11-20 02:30:48.89193+00	2025-11-20 16:09:51.152088+00	\N	10	1	\N
9	Subathon	Subathon benefica para mi hijo	2025-11-20 16:00:00+00	2025-11-20 17:00:00+00	CANCELLED	\N	2025-11-20 16:12:02.770988+00	2025-11-20 16:11:55.510896+00	2025-11-20 16:12:02.931967+00	\N	10	7	\N
10	Uso cancha de padel 2		2025-11-21 16:00:00+00	2025-11-21 17:00:00+00	CANCELLED	\N	2025-11-20 16:32:45.30353+00	2025-11-20 16:32:07.59689+00	2025-11-20 16:32:07.596899+00	\N	10	6	No se podra asistir
12	Uso cancha de basquetbol 2		2025-11-25 16:00:00+00	2025-11-25 17:00:00+00	PENDING	\N	\N	2025-11-20 18:18:37.215146+00	2025-11-20 18:18:37.215155+00	\N	5	4	\N
13	Uso cancha de futbol 1		2025-11-21 13:00:00+00	2025-11-21 14:00:00+00	PENDING	\N	\N	2025-11-20 19:08:14.635628+00	2025-11-20 19:08:14.635639+00	\N	4	1	\N
14	Uso cancha de padel 2		2025-11-22 15:00:00+00	2025-11-22 16:00:00+00	CANCELLED	\N	2025-11-20 19:11:43.749976+00	2025-11-20 19:10:28.165163+00	2025-11-20 19:10:28.165174+00	\N	10	6	Cancelación repentina (no hay personas para hacer uso)
5	Uso cancha de basquetbol 1		2025-11-21 01:49:00+00	2025-11-21 02:49:00+00	CANCELLED	\N	2025-11-20 20:54:33.421446+00	2025-11-18 04:50:03.343338+00	2025-11-18 04:50:03.34335+00	\N	2	3	cambio de planes
15	Uso cancha de futbol 2		2025-11-20 18:00:00+00	2025-11-20 19:00:00+00	PENDING	\N	\N	2025-11-20 20:54:45.994537+00	2025-11-20 20:54:45.994546+00	\N	2	2	\N
16	Uso cancha de padel 1		2025-11-30 17:00:00+00	2025-11-30 18:00:00+00	PENDING	\N	\N	2025-11-20 21:21:56.453064+00	2025-11-20 21:21:56.453075+00	\N	2	5	\N
17	Uso cancha de padel 1		2025-11-27 17:00:00+00	2025-11-27 18:00:00+00	PENDING	\N	\N	2025-11-20 21:29:18.111921+00	2025-11-20 21:29:18.111934+00	\N	2	5	\N
18	Uso cancha de basquetbol 2		2025-11-23 14:00:00+00	2025-11-23 15:00:00+00	PENDING	\N	\N	2025-11-20 22:04:36.765297+00	2025-11-20 22:04:36.765306+00	\N	2	4	\N
19	Uso cancha de padel 1		2025-11-28 16:00:00+00	2025-11-28 17:00:00+00	PENDING	\N	\N	2025-11-20 22:10:40.072123+00	2025-11-20 22:10:40.072135+00	\N	2	5	\N
20	Uso cancha de basquetbol 1		2025-11-23 17:00:00+00	2025-11-23 18:00:00+00	PENDING	\N	\N	2025-11-20 22:20:57.244708+00	2025-11-20 22:20:57.244719+00	\N	2	3	\N
21	Uso cancha de padel 1		2025-11-29 16:00:00+00	2025-11-29 17:00:00+00	PENDING	\N	\N	2025-11-20 22:25:46.543215+00	2025-11-20 22:25:46.543224+00	\N	2	5	\N
22	Uso cancha de padel 2		2025-11-25 18:00:00+00	2025-11-25 19:00:00+00	PENDING	\N	\N	2025-11-20 22:31:51.125263+00	2025-11-20 22:31:51.125271+00	\N	2	6	\N
23	Uso cancha de basquetbol 1		2025-11-21 19:00:00+00	2025-11-21 20:00:00+00	PENDING	\N	\N	2025-11-20 23:49:44.857907+00	2025-11-20 23:49:44.857915+00	\N	5	3	\N
24	Cumpleaños	Celebrare el cumpleaños de mi hijo	2025-11-21 14:00:00+00	2025-11-21 15:00:00+00	PENDING	\N	\N	2025-11-21 00:03:54.104302+00	2025-11-21 00:03:54.104313+00	\N	2	7	\N
25	Uso cancha de futbol 1		2025-11-21 19:00:00+00	2025-11-21 20:00:00+00	PENDING	\N	\N	2025-11-21 03:27:02.328161+00	2025-11-21 03:27:02.32817+00	\N	5	1	\N
26	Uso cancha de basquetbol 1		2025-11-26 14:00:00+00	2025-11-26 15:00:00+00	PENDING	\N	\N	2025-11-21 23:36:38.197185+00	2025-11-21 23:36:38.197197+00	\N	5	3	\N
27	Uso cancha de basquetbol 1		2025-11-27 16:00:00+00	2025-11-27 17:00:00+00	PENDING	\N	\N	2025-11-22 00:17:08.914919+00	2025-11-22 00:17:08.914931+00	\N	3	3	\N
28	Uso cancha de padel 2		2025-11-23 17:00:00+00	2025-11-23 18:00:00+00	PENDING	\N	\N	2025-11-22 00:40:47.895818+00	2025-11-22 00:40:47.895827+00	\N	4	6	\N
29	Uso cancha de futbol 2		2025-11-28 20:00:00+00	2025-11-28 21:00:00+00	PENDING	\N	\N	2025-11-22 02:16:05.98237+00	2025-11-22 02:16:05.982384+00	\N	3	2	\N
30	Uso cancha de padel 2		2025-11-28 16:00:00+00	2025-11-28 17:00:00+00	PENDING	\N	\N	2025-11-22 02:30:34.714942+00	2025-11-22 02:30:34.714952+00	\N	5	6	\N
31	Uso cancha de padel 2		2025-11-28 14:00:00+00	2025-11-28 15:00:00+00	PENDING	\N	\N	2025-11-22 02:32:05.703767+00	2025-11-22 02:32:05.703775+00	\N	5	6	\N
32	Uso cancha de basquetbol 2		2025-11-27 17:00:00+00	2025-11-27 18:00:00+00	PENDING	\N	\N	2025-11-22 17:20:47.755629+00	2025-11-22 17:20:47.755643+00	\N	5	4	\N
33	Uso cancha de basquetbol 2		2025-11-26 17:00:00+00	2025-11-26 18:00:00+00	PENDING	\N	\N	2025-11-22 17:23:48.417641+00	2025-11-22 17:23:48.417651+00	\N	5	4	\N
34	Uso cancha de futbol 1		2025-11-29 15:00:00+00	2025-11-29 16:00:00+00	PENDING	\N	\N	2025-11-22 18:39:53.825142+00	2025-11-22 18:39:53.825156+00	\N	5	1	\N
35	Uso cancha de futbol 1		2025-11-28 13:00:00+00	2025-11-28 14:00:00+00	PENDING	\N	\N	2025-11-22 18:47:07.954234+00	2025-11-22 18:47:07.954243+00	\N	5	1	\N
36	Uso cancha de padel 1		2025-11-28 18:00:00+00	2025-11-28 19:00:00+00	PENDING	\N	\N	2025-11-22 21:19:09.972761+00	2025-11-22 21:19:09.972771+00	\N	3	5	\N
37	Uso cancha de futbol 1		2025-11-27 10:00:00+00	2025-11-27 11:00:00+00	PENDING	\N	\N	2025-11-22 23:24:23.25869+00	2025-11-22 23:24:23.258704+00	\N	5	1	\N
38	Uso cancha de basquetbol 1		2025-12-01 10:00:00+00	2025-12-01 11:00:00+00	PENDING	\N	\N	2025-11-25 14:42:51.541737+00	2025-11-25 14:42:51.541746+00	\N	10	3	\N
11	Uso cancha de futbol 1		2025-11-22 21:00:00+00	2025-11-22 22:00:00+00	CANCELLED	\N	2025-11-25 14:43:30.506528+00	2025-11-20 16:34:37.057267+00	2025-11-20 16:34:37.057275+00	\N	10	1	Se cancelo por falta de gente
39	Uso cancha de padel 2		2025-11-28 18:00:00+00	2025-11-28 19:00:00+00	PENDING	\N	\N	2025-11-25 15:55:07.22412+00	2025-11-25 15:55:07.224131+00	\N	14	6	\N
\.


--
-- Data for Name: core_resident; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.core_resident (id, nombre, email, telefono, direccion, activo, user_id, rut) FROM stdin;
1	Miguel Medina	m.medina.sa03@gmail.com	+56 9 8765 4321	Diego de meza 5431	t	5	21.236.262-K
2	William Lopez	william.lopez@gmail.com	+59 9 1234 5678	santa rosa 4321	t	3	12.123.345-2
3	Lionel Messi	lionel.messi@gmail.com	+59 9 1234 9876	santa rosa 543	t	2	23.123.675-3
7	Lucas Saez	mi.medina@duocuc.cl		departamental 65	t	8	45.123.764-3
8	renato Arratia	mi.medina@duocuc.cl		Diego De Meza 5431	t	9	12.123.123-3
4	Cristiano Ronaldo	cristiano.ronaldo@gmail.com	+59 9 5431 7890	santa rosa 654	t	4	56.123.876-2
9	William López	wi.lopezc@duocuc.cl		Santa Clara 5751	t	10	21.201.554-7
10	Matias Medina	mi.medina@duocuc.cl		departamental 432	f	11	13.123.123-1
12	Matías Cárdenas	matiascardenas512@gmail.com		Mi casa	t	13	20.921.789-9
5	Alexis Sanchez	alexis.sanchez@gmail.com	+59 9 4325 9876	santa rosa 987	f	1	54.765.234-4
6	matias cardenas	mi.medina@duocuc.cl		departamental 432	f	7	32.124.654-3
13	rodrigo leyton	mi.medina@duocuc.cl		Diego de meza 5431	t	14	21.075.540-3
\.


--
-- Data for Name: core_resource; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.core_resource (id, nombre, descripcion, activo, open_time, close_time, categoria_id, precio_por_hora) FROM stdin;
1	cancha de futbol 1		t	\N	\N	4	20000.00
2	cancha de futbol 2		t	\N	\N	1	20000.00
3	cancha de basquetbol 1		t	\N	\N	2	20000.00
4	cancha de basquetbol 2		t	\N	\N	2	20000.00
5	cancha de padel 1		t	\N	\N	3	25000.00
6	cancha de padel 2		t	\N	\N	3	25000.00
7	salon de eventos		t	\N	\N	4	\N
\.


--
-- Data for Name: core_resourcecategory; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.core_resourcecategory (id, nombre, descripcion) FROM stdin;
1	cancha de futbol	
2	cancha de basquetbol	
3	cancha de padel	
4	salon de eventos	
\.


--
-- Data for Name: django_admin_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.django_admin_log (id, action_time, object_id, object_repr, action_flag, change_message, content_type_id, user_id) FROM stdin;
1	2025-11-16 23:48:47.185411+00	1	cancha de futbol	1	[{"added": {}}]	18	6
2	2025-11-16 23:48:54.574682+00	2	cancha de basquetbol	1	[{"added": {}}]	18	6
3	2025-11-16 23:49:02.978159+00	3	cancha de padel	1	[{"added": {}}]	18	6
4	2025-11-16 23:49:13.398844+00	4	salon de eventos	1	[{"added": {}}]	18	6
5	2025-11-16 23:49:33.140537+00	1	cancha de futbol 1	1	[{"added": {}}]	19	6
6	2025-11-16 23:49:58.701737+00	2	cancha de futbol 2	1	[{"added": {}}]	19	6
7	2025-11-16 23:50:27.098328+00	3	cancha de basquetbol 1	1	[{"added": {}}]	19	6
8	2025-11-16 23:50:46.279049+00	4	cancha de basquetbol 2	1	[{"added": {}}]	19	6
9	2025-11-16 23:50:59.571833+00	5	cancha de padel 1	1	[{"added": {}}]	19	6
10	2025-11-16 23:51:17.864416+00	6	cancha de padel 2	1	[{"added": {}}]	19	6
11	2025-11-16 23:51:28.469679+00	7	salon de eventos	1	[{"added": {}}]	19	6
12	2025-11-16 23:53:35.556635+00	1	Miguel Medina	1	[{"added": {}}]	7	6
13	2025-11-16 23:54:24.060088+00	5	miguel.vecino	2	[]	4	6
14	2025-11-16 23:54:41.271294+00	1	Miguel Medina	2	[{"changed": {"fields": ["Direccion", "RUT"]}}]	7	6
15	2025-11-16 23:55:16.009846+00	2	William Lopez	1	[{"added": {}}]	7	6
16	2025-11-16 23:55:42.418416+00	3	Lionel Messi	1	[{"added": {}}]	7	6
17	2025-11-16 23:56:33.184087+00	3	Lionel Messi	2	[{"changed": {"fields": ["Telefono", "Direccion", "RUT"]}}]	7	6
18	2025-11-16 23:57:13.950774+00	4	Cristiano Ronaldo	1	[{"added": {}}]	7	6
19	2025-11-16 23:58:01.740925+00	5	Alexis Sanchez	1	[{"added": {}}]	7	6
20	2025-11-18 04:18:52.321571+00	7	Delegado	2	[{"changed": {"fields": ["Permissions"]}}]	3	6
21	2025-11-18 04:19:16.289073+00	5	Presidente	2	[{"changed": {"fields": ["Permissions"]}}]	3	6
22	2025-11-18 04:19:50.20761+00	7	Delegado	2	[{"changed": {"fields": ["Permissions"]}}]	3	6
23	2025-11-23 18:49:23.346607+00	1	william.presidente	2	[]	4	6
\.


--
-- Data for Name: django_content_type; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.django_content_type (id, app_label, model) FROM stdin;
1	admin	logentry
2	auth	permission
3	auth	group
4	auth	user
5	contenttypes	contenttype
6	sessions	session
7	core	resident
8	core	household
9	core	announcement
10	core	meeting
11	core	minutes
12	core	fee
13	core	payment
14	core	document
15	core	documentcategory
16	core	incidentcategory
17	core	incident
18	core	resourcecategory
19	core	resource
20	core	reservation
21	core	inscriptionevidence
22	core	notification
\.


--
-- Data for Name: django_migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.django_migrations (id, app, name, applied) FROM stdin;
1	contenttypes	0001_initial	2025-11-16 22:41:18.916168+00
2	auth	0001_initial	2025-11-16 22:41:20.579638+00
3	admin	0001_initial	2025-11-16 22:41:21.020037+00
4	admin	0002_logentry_remove_auto_add	2025-11-16 22:41:21.079414+00
5	admin	0003_logentry_add_action_flag_choices	2025-11-16 22:41:21.242435+00
6	contenttypes	0002_remove_content_type_name	2025-11-16 22:41:21.576399+00
7	auth	0002_alter_permission_name_max_length	2025-11-16 22:41:21.793548+00
8	auth	0003_alter_user_email_max_length	2025-11-16 22:41:22.016219+00
9	auth	0004_alter_user_username_opts	2025-11-16 22:41:22.126585+00
10	auth	0005_alter_user_last_login_null	2025-11-16 22:41:22.399273+00
11	auth	0006_require_contenttypes_0002	2025-11-16 22:41:22.506729+00
12	auth	0007_alter_validators_add_error_messages	2025-11-16 22:41:22.669937+00
13	auth	0008_alter_user_username_max_length	2025-11-16 22:41:22.943087+00
14	auth	0009_alter_user_last_name_max_length	2025-11-16 22:41:23.160184+00
15	auth	0010_alter_group_name_max_length	2025-11-16 22:41:23.386347+00
16	auth	0011_update_proxy_permissions	2025-11-16 22:41:23.49746+00
17	auth	0012_alter_user_first_name_max_length	2025-11-16 22:41:23.767369+00
18	core	0001_initial	2025-11-16 22:41:23.874356+00
19	core	0002_create_groups	2025-11-16 22:41:24.946393+00
20	core	0003_initial	2025-11-16 22:41:25.66306+00
21	core	0004_announcement	2025-11-16 22:41:25.995322+00
22	core	0005_meeting_minutes	2025-11-16 22:41:26.324716+00
23	core	0006_fee_payment_payment_uniq_paid_per_resident_fee	2025-11-16 22:41:26.940236+00
24	core	0007_alter_payment_resident	2025-11-16 22:41:27.010629+00
25	core	0008_document	2025-11-16 22:41:27.281677+00
26	core	0009_alter_document_options_and_more	2025-11-16 22:41:28.219677+00
27	core	0010_alter_document_options_remove_document_file_and_more	2025-11-16 22:41:28.999303+00
28	core	0011_documentcategory_remove_document_is_public_and_more	2025-11-16 22:41:30.430045+00
29	core	0012_incidentcategory_incident	2025-11-16 22:41:31.196596+00
30	core	0013_resourcecategory_alter_incident_foto_resource_and_more	2025-11-16 22:41:32.262504+00
31	core	0014_alter_incident_foto	2025-11-16 22:41:32.325898+00
32	core	0015_alter_incident_foto_inscriptionevidence	2025-11-16 22:41:32.998167+00
33	core	0016_alter_incident_foto	2025-11-16 22:41:33.062267+00
34	core	0017_alter_incident_foto	2025-11-16 22:41:33.231229+00
35	core	0018_alter_payment_status	2025-11-16 22:41:33.399184+00
36	core	0019_alter_payment_options_and_more	2025-11-16 22:41:34.455882+00
37	core	0020_resource_precio_por_hora	2025-11-16 22:41:34.626052+00
38	core	0021_alter_fee_options_alter_fee_amount_alter_fee_period	2025-11-16 22:41:35.124727+00
39	core	0022_inscriptionevidence_email	2025-11-16 22:41:35.353428+00
40	core	0023_inscriptionevidence_address_and_more	2025-11-16 22:41:35.747001+00
41	core	0024_remove_inscriptionevidence_address_and_more	2025-11-16 22:41:36.163402+00
42	core	0025_payment_receipt_file_payment_receipt_note_and_more	2025-11-16 22:41:36.68949+00
43	core	0026_payment_review_note	2025-11-16 22:41:36.912157+00
44	core	0027_remove_payment_staff_note_payment_reviewed_at_and_more	2025-11-16 22:41:37.477228+00
45	core	0028_rename_review_note_payment_review_comment_and_more	2025-11-16 22:41:37.708743+00
46	core	0029_announcement_importante	2025-11-16 22:41:37.987713+00
47	core	0030_rename_applicant_address_inscriptionevidence_address_and_more	2025-11-16 22:41:38.629766+00
48	core	0031_inscriptionevidence_desired_role	2025-11-16 22:41:38.804439+00
49	sessions	0001_initial	2025-11-16 22:41:39.197648+00
50	core	0032_reservation_cancel_reason	2025-11-20 16:23:07.1517+00
51	core	0032_notification	2025-11-20 17:10:46.398586+00
52	core	0033_merge_20251120_1645	2025-11-20 19:45:23.220039+00
53	core	0033_notification	2025-11-20 20:05:25.806026+00
54	core	0034_notification_is_important_alter_notification_type	2025-11-21 23:31:36.260083+00
55	core	0035_alter_notification_options_alter_notification_type	2025-11-22 00:27:05.41535+00
56	core	0036_meeting_creado_por	2025-11-22 02:09:19.823862+00
\.


--
-- Data for Name: django_session; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.django_session (session_key, session_data, expire_date) FROM stdin;
iz8pnbolc46ioyu3vuzs2d83bjgzfloy	.eJxVjUFPxCAQRv9Kw1kJ0ELbPbq3jSYmHryYNANMLdqCUvDgZv-7EPeg1--9eXMmE-S0THnHODlLDoQzcvN31GDe0Vdi38C_BmqCT9FpWhV6pTt9CBbXu6v7L7DAvtRrNnRmAK2kAmilGG3XQzsqxUXLcehmZZiYkdtedgL4OKIQTPHW6rHXg5QlajCmKeI-WUhADmfiw6YjlvizW1cHW3P_khmb2w_8LnrMqSDBqWCcStnd9mW0LqIxLviCnsAnaI4rRGhkL3l9Ebbs4Zc1pwCfuRbR-sK2kNxXKOwxZtRALpcfbQpkzQ:1vNehx:LrCoZveRW62YWkPqL9saOrr56uWfOpqJ_TMeFDXpoG4	2025-12-08 22:06:53.167937+00
54pnejoojrcvrj71sopc0xf1jng80jgs	eyJfcGFzc3dvcmRfcmVzZXRfdG9rZW4iOiJjenNseW8tZGQzNjFiOTE1MGY3MTBmMWE1ZGE4MGRhMzhkYTk2ZjAifQ:1vNetN:CShA4nFU0b2ZXJWDuNFEoU9o2M3wRT_C_SS_PmpsEu4	2025-12-08 22:18:41.782753+00
n13ezjh01pazcaucixbzlt22ve7a7coq	.eJxVjDEOAiEQRe9CbQiQYRRLe89AmGGQVQPJslsZ766bbKHtf-_9l4ppXWpch8xxyuqsvDr8bpT4IW0D-Z7arWvubZkn0puidzr0tWd5Xnb376CmUb91QLCeMwBaKSkR-BMgOIMZXXDOoidfEDwHZ7IgG0NwZHBFBMUyqfcHwYk3bg:1vNicN:j5-sNVMM7tpwzofL5JN2H39yzTKtNslEvKiBr2H6b7U	2025-12-09 02:17:23.040751+00
yunh36kt2xjkq9pyxknorwqke2kw5e8i	.eJxVjMEOwiAQRP-FsyEs7Qr16N1vIFt2K1UDSWlPxn-3JD3ocea9mbcKtK0pbFWWMLO6KFCn326k-JTcAD8o34uOJa_LPOqm6INWfSssr-vh_h0kqmlfR7bAnaDx4oxMwFEE4hl7moa-Bzt01KD3hIx2cAiCyHsE49B6qz5f64w3Sg:1vNu6w:oTT7kfAolmeFaDbO4xFf_Nilh3H3fRvB4KJBVSu8eKA	2025-12-09 14:33:42.438868+00
44ryz3m4d0jrzd3kxfpni2lzfpxgotde	.eJxVjMEOwiAQRP-FsyEs7Qr16N1vIFt2K1UDSWlPxn-3JD3ocea9mbcKtK0pbFWWMLO6KFCn326k-JTcAD8o34uOJa_LPOqm6INWfSssr-vh_h0kqmlfR7bAnaDx4oxMwFEE4hl7moa-Bzt01KD3hIx2cAiCyHsE49B6qz5f64w3Sg:1vNu89:KYPNPUoAerA5ln5cQJuCHWerVZK8896SmcMTzhJCQFw	2025-12-09 14:34:57.981193+00
8eba5t2iepdordyx4p4g1gub5tbp5lvt	.eJxVjMEOwiAQRP-FsyEs7Qr16N1vIFt2K1UDSWlPxn-3JD3ocea9mbcKtK0pbFWWMLO6KFCn326k-JTcAD8o34uOJa_LPOqm6INWfSssr-vh_h0kqmlfR7bAnaDx4oxMwFEE4hl7moa-Bzt01KD3hIx2cAiCyHsE49B6qz5f64w3Sg:1vNuMC:o4rettLEQuIgr297dlHjZFh0ecT81EwbrYjZvFhF_OI	2025-12-09 14:49:28.473779+00
7abvfq65sgb4f03fhseph21itxozjoqw	.eJxVjMFOxCAURX-FsFYCDKDt0rjSdOXWpHnAa8vYQqQwCyfz79JkFro9595zpSPUsox1xzwGT3uq6cNfZsF9YTyEP0OcE3MplhwsOybsbnc2JI_ry337L7DAvrR3Z5TQzitlBE4AVulnZZTkxhvZSSmMtnoySrtOco_GcW7Vk1NyQjQonG1Rh7mMGffRQwHaX2lMm83Y4kOYK65kQB8itGWupVEpmDwZJo18fG_Qh4zOhRSbeg04J-KRbPgDRKuTOPppq-3e0w-I5C3Bd_2snKOPzW2phEs6HOZLaBWyhTUUyPR2-wVOQGhR:1vNbsP:ZyRA5T4-4AUrkT_AslXPU_6q_TaDwDoNceBsU_uTl4s	2025-12-08 19:05:29.193164+00
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: realtime; Owner: supabase_admin
--

COPY realtime.schema_migrations (version, inserted_at) FROM stdin;
20211116024918	2025-11-16 19:45:41
20211116045059	2025-11-16 19:45:45
20211116050929	2025-11-16 19:45:49
20211116051442	2025-11-16 19:45:53
20211116212300	2025-11-16 19:45:57
20211116213355	2025-11-16 19:46:00
20211116213934	2025-11-16 19:46:03
20211116214523	2025-11-16 19:46:08
20211122062447	2025-11-16 19:46:12
20211124070109	2025-11-16 19:46:16
20211202204204	2025-11-16 19:46:19
20211202204605	2025-11-16 19:46:23
20211210212804	2025-11-16 19:46:33
20211228014915	2025-11-16 19:46:37
20220107221237	2025-11-16 19:46:40
20220228202821	2025-11-16 19:46:43
20220312004840	2025-11-16 19:46:47
20220603231003	2025-11-16 19:46:52
20220603232444	2025-11-16 19:46:55
20220615214548	2025-11-16 19:46:59
20220712093339	2025-11-16 19:47:03
20220908172859	2025-11-16 19:47:06
20220916233421	2025-11-16 19:47:09
20230119133233	2025-11-16 19:47:13
20230128025114	2025-11-16 19:47:17
20230128025212	2025-11-16 19:47:21
20230227211149	2025-11-16 19:47:24
20230228184745	2025-11-16 19:47:27
20230308225145	2025-11-16 19:47:31
20230328144023	2025-11-16 19:47:34
20231018144023	2025-11-16 19:47:38
20231204144023	2025-11-16 19:47:43
20231204144024	2025-11-16 19:47:46
20231204144025	2025-11-16 19:47:50
20240108234812	2025-11-16 19:47:53
20240109165339	2025-11-16 19:47:56
20240227174441	2025-11-16 19:48:02
20240311171622	2025-11-16 19:48:07
20240321100241	2025-11-16 19:48:14
20240401105812	2025-11-16 19:48:23
20240418121054	2025-11-16 19:48:28
20240523004032	2025-11-16 19:48:40
20240618124746	2025-11-16 19:48:43
20240801235015	2025-11-16 19:48:46
20240805133720	2025-11-16 19:48:49
20240827160934	2025-11-16 19:48:53
20240919163303	2025-11-16 19:48:57
20240919163305	2025-11-16 19:49:01
20241019105805	2025-11-16 19:49:04
20241030150047	2025-11-16 19:49:16
20241108114728	2025-11-16 19:49:21
20241121104152	2025-11-16 19:49:24
20241130184212	2025-11-16 19:49:28
20241220035512	2025-11-16 19:49:32
20241220123912	2025-11-16 19:49:35
20241224161212	2025-11-16 19:49:38
20250107150512	2025-11-16 19:49:42
20250110162412	2025-11-16 19:49:45
20250123174212	2025-11-16 19:49:48
20250128220012	2025-11-16 19:49:52
20250506224012	2025-11-16 19:49:54
20250523164012	2025-11-16 19:49:58
20250714121412	2025-11-16 19:50:01
20250905041441	2025-11-16 19:50:04
20251103001201	2025-11-16 19:50:08
\.


--
-- Data for Name: subscription; Type: TABLE DATA; Schema: realtime; Owner: supabase_admin
--

COPY realtime.subscription (id, subscription_id, entity, filters, claims, created_at) FROM stdin;
\.


--
-- Data for Name: buckets; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY storage.buckets (id, name, owner, created_at, updated_at, public, avif_autodetection, file_size_limit, allowed_mime_types, owner_id, type) FROM stdin;
\.


--
-- Data for Name: buckets_analytics; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY storage.buckets_analytics (name, type, format, created_at, updated_at, id, deleted_at) FROM stdin;
\.


--
-- Data for Name: buckets_vectors; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY storage.buckets_vectors (id, type, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: migrations; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY storage.migrations (id, name, hash, executed_at) FROM stdin;
0	create-migrations-table	e18db593bcde2aca2a408c4d1100f6abba2195df	2025-11-16 19:45:23.709485
1	initialmigration	6ab16121fbaa08bbd11b712d05f358f9b555d777	2025-11-16 19:45:23.717851
2	storage-schema	5c7968fd083fcea04050c1b7f6253c9771b99011	2025-11-16 19:45:23.72358
3	pathtoken-column	2cb1b0004b817b29d5b0a971af16bafeede4b70d	2025-11-16 19:45:23.765935
4	add-migrations-rls	427c5b63fe1c5937495d9c635c263ee7a5905058	2025-11-16 19:45:23.834151
5	add-size-functions	79e081a1455b63666c1294a440f8ad4b1e6a7f84	2025-11-16 19:45:23.837054
6	change-column-name-in-get-size	f93f62afdf6613ee5e7e815b30d02dc990201044	2025-11-16 19:45:23.843975
7	add-rls-to-buckets	e7e7f86adbc51049f341dfe8d30256c1abca17aa	2025-11-16 19:45:23.84739
8	add-public-to-buckets	fd670db39ed65f9d08b01db09d6202503ca2bab3	2025-11-16 19:45:23.850823
9	fix-search-function	3a0af29f42e35a4d101c259ed955b67e1bee6825	2025-11-16 19:45:23.85468
10	search-files-search-function	68dc14822daad0ffac3746a502234f486182ef6e	2025-11-16 19:45:23.877488
11	add-trigger-to-auto-update-updated_at-column	7425bdb14366d1739fa8a18c83100636d74dcaa2	2025-11-16 19:45:23.881929
12	add-automatic-avif-detection-flag	8e92e1266eb29518b6a4c5313ab8f29dd0d08df9	2025-11-16 19:45:23.887112
13	add-bucket-custom-limits	cce962054138135cd9a8c4bcd531598684b25e7d	2025-11-16 19:45:23.893154
14	use-bytes-for-max-size	941c41b346f9802b411f06f30e972ad4744dad27	2025-11-16 19:45:23.896233
15	add-can-insert-object-function	934146bc38ead475f4ef4b555c524ee5d66799e5	2025-11-16 19:45:23.927597
16	add-version	76debf38d3fd07dcfc747ca49096457d95b1221b	2025-11-16 19:45:23.932997
17	drop-owner-foreign-key	f1cbb288f1b7a4c1eb8c38504b80ae2a0153d101	2025-11-16 19:45:23.936686
18	add_owner_id_column_deprecate_owner	e7a511b379110b08e2f214be852c35414749fe66	2025-11-16 19:45:23.940684
19	alter-default-value-objects-id	02e5e22a78626187e00d173dc45f58fa66a4f043	2025-11-16 19:45:23.947412
20	list-objects-with-delimiter	cd694ae708e51ba82bf012bba00caf4f3b6393b7	2025-11-16 19:45:23.950271
21	s3-multipart-uploads	8c804d4a566c40cd1e4cc5b3725a664a9303657f	2025-11-16 19:45:23.955331
22	s3-multipart-uploads-big-ints	9737dc258d2397953c9953d9b86920b8be0cdb73	2025-11-16 19:45:23.969086
23	optimize-search-function	9d7e604cddc4b56a5422dc68c9313f4a1b6f132c	2025-11-16 19:45:23.987793
24	operation-function	8312e37c2bf9e76bbe841aa5fda889206d2bf8aa	2025-11-16 19:45:23.9908
25	custom-metadata	d974c6057c3db1c1f847afa0e291e6165693b990	2025-11-16 19:45:23.993731
26	objects-prefixes	ef3f7871121cdc47a65308e6702519e853422ae2	2025-11-16 19:45:23.99689
27	search-v2	33b8f2a7ae53105f028e13e9fcda9dc4f356b4a2	2025-11-16 19:45:24.009581
28	object-bucket-name-sorting	ba85ec41b62c6a30a3f136788227ee47f311c436	2025-11-16 19:45:24.017239
29	create-prefixes	a7b1a22c0dc3ab630e3055bfec7ce7d2045c5b7b	2025-11-16 19:45:24.022088
30	update-object-levels	6c6f6cc9430d570f26284a24cf7b210599032db7	2025-11-16 19:45:24.026905
31	objects-level-index	33f1fef7ec7fea08bb892222f4f0f5d79bab5eb8	2025-11-16 19:45:24.034048
32	backward-compatible-index-on-objects	2d51eeb437a96868b36fcdfb1ddefdf13bef1647	2025-11-16 19:45:24.040362
33	backward-compatible-index-on-prefixes	fe473390e1b8c407434c0e470655945b110507bf	2025-11-16 19:45:24.046122
34	optimize-search-function-v1	82b0e469a00e8ebce495e29bfa70a0797f7ebd2c	2025-11-16 19:45:24.047497
35	add-insert-trigger-prefixes	63bb9fd05deb3dc5e9fa66c83e82b152f0caf589	2025-11-16 19:45:24.052052
36	optimise-existing-functions	81cf92eb0c36612865a18016a38496c530443899	2025-11-16 19:45:24.054855
37	add-bucket-name-length-trigger	3944135b4e3e8b22d6d4cbb568fe3b0b51df15c1	2025-11-16 19:45:24.060528
38	iceberg-catalog-flag-on-buckets	19a8bd89d5dfa69af7f222a46c726b7c41e462c5	2025-11-16 19:45:24.064137
39	add-search-v2-sort-support	39cf7d1e6bf515f4b02e41237aba845a7b492853	2025-11-16 19:45:24.071703
40	fix-prefix-race-conditions-optimized	fd02297e1c67df25a9fc110bf8c8a9af7fb06d1f	2025-11-16 19:45:24.075912
41	add-object-level-update-trigger	44c22478bf01744b2129efc480cd2edc9a7d60e9	2025-11-16 19:45:24.082621
42	rollback-prefix-triggers	f2ab4f526ab7f979541082992593938c05ee4b47	2025-11-16 19:45:24.086012
43	fix-object-level	ab837ad8f1c7d00cc0b7310e989a23388ff29fc6	2025-11-16 19:45:24.09128
44	vector-bucket-type	99c20c0ffd52bb1ff1f32fb992f3b351e3ef8fb3	2025-11-17 18:19:33.073647
45	vector-buckets	049e27196d77a7cb76497a85afae669d8b230953	2025-11-17 18:19:33.10509
46	buckets-objects-grants	fedeb96d60fefd8e02ab3ded9fbde05632f84aed	2025-11-17 18:19:33.1776
47	iceberg-table-metadata	649df56855c24d8b36dd4cc1aeb8251aa9ad42c2	2025-11-17 18:19:33.181586
48	iceberg-catalog-ids	2666dff93346e5d04e0a878416be1d5fec345d6f	2025-11-17 18:19:33.184249
\.


--
-- Data for Name: objects; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY storage.objects (id, bucket_id, name, owner, created_at, updated_at, last_accessed_at, metadata, version, owner_id, user_metadata, level) FROM stdin;
\.


--
-- Data for Name: prefixes; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY storage.prefixes (bucket_id, name, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: s3_multipart_uploads; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY storage.s3_multipart_uploads (id, in_progress_size, upload_signature, bucket_id, key, version, owner_id, created_at, user_metadata) FROM stdin;
\.


--
-- Data for Name: s3_multipart_uploads_parts; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY storage.s3_multipart_uploads_parts (id, upload_id, size, part_number, bucket_id, key, etag, owner_id, version, created_at) FROM stdin;
\.


--
-- Data for Name: vector_indexes; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY storage.vector_indexes (id, name, bucket_id, data_type, dimension, distance_metric, metadata_configuration, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: secrets; Type: TABLE DATA; Schema: vault; Owner: supabase_admin
--

COPY vault.secrets (id, name, description, secret, key_id, nonce, created_at, updated_at) FROM stdin;
\.


--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE SET; Schema: auth; Owner: supabase_auth_admin
--

SELECT pg_catalog.setval('auth.refresh_tokens_id_seq', 1, false);


--
-- Name: auth_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auth_group_id_seq', 7, true);


--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auth_group_permissions_id_seq', 224, true);


--
-- Name: auth_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auth_permission_id_seq', 88, true);


--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auth_user_groups_id_seq', 13, true);


--
-- Name: auth_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auth_user_id_seq', 14, true);


--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auth_user_user_permissions_id_seq', 1, false);


--
-- Name: core_announcement_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.core_announcement_id_seq', 31, true);


--
-- Name: core_document_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.core_document_id_seq', 1, false);


--
-- Name: core_documentcategory_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.core_documentcategory_id_seq', 1, false);


--
-- Name: core_fee_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.core_fee_id_seq', 1, false);


--
-- Name: core_household_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.core_household_id_seq', 1, false);


--
-- Name: core_household_residents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.core_household_residents_id_seq', 1, false);


--
-- Name: core_incident_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.core_incident_id_seq', 38, true);


--
-- Name: core_incidentcategory_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.core_incidentcategory_id_seq', 1, false);


--
-- Name: core_inscriptionevidence_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.core_inscriptionevidence_id_seq', 13, true);


--
-- Name: core_meeting_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.core_meeting_id_seq', 8, true);


--
-- Name: core_minutes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.core_minutes_id_seq', 1, false);


--
-- Name: core_notification_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.core_notification_id_seq', 506, true);


--
-- Name: core_payment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.core_payment_id_seq', 37, true);


--
-- Name: core_reservation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.core_reservation_id_seq', 39, true);


--
-- Name: core_resident_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.core_resident_id_seq', 13, true);


--
-- Name: core_resource_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.core_resource_id_seq', 7, true);


--
-- Name: core_resourcecategory_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.core_resourcecategory_id_seq', 4, true);


--
-- Name: django_admin_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.django_admin_log_id_seq', 23, true);


--
-- Name: django_content_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.django_content_type_id_seq', 22, true);


--
-- Name: django_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.django_migrations_id_seq', 56, true);


--
-- Name: subscription_id_seq; Type: SEQUENCE SET; Schema: realtime; Owner: supabase_admin
--

SELECT pg_catalog.setval('realtime.subscription_id_seq', 1, false);


--
-- Name: mfa_amr_claims amr_id_pk; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_amr_claims
    ADD CONSTRAINT amr_id_pk PRIMARY KEY (id);


--
-- Name: audit_log_entries audit_log_entries_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.audit_log_entries
    ADD CONSTRAINT audit_log_entries_pkey PRIMARY KEY (id);


--
-- Name: flow_state flow_state_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.flow_state
    ADD CONSTRAINT flow_state_pkey PRIMARY KEY (id);


--
-- Name: identities identities_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.identities
    ADD CONSTRAINT identities_pkey PRIMARY KEY (id);


--
-- Name: identities identities_provider_id_provider_unique; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.identities
    ADD CONSTRAINT identities_provider_id_provider_unique UNIQUE (provider_id, provider);


--
-- Name: instances instances_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.instances
    ADD CONSTRAINT instances_pkey PRIMARY KEY (id);


--
-- Name: mfa_amr_claims mfa_amr_claims_session_id_authentication_method_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_amr_claims
    ADD CONSTRAINT mfa_amr_claims_session_id_authentication_method_pkey UNIQUE (session_id, authentication_method);


--
-- Name: mfa_challenges mfa_challenges_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_challenges
    ADD CONSTRAINT mfa_challenges_pkey PRIMARY KEY (id);


--
-- Name: mfa_factors mfa_factors_last_challenged_at_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_factors
    ADD CONSTRAINT mfa_factors_last_challenged_at_key UNIQUE (last_challenged_at);


--
-- Name: mfa_factors mfa_factors_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_factors
    ADD CONSTRAINT mfa_factors_pkey PRIMARY KEY (id);


--
-- Name: oauth_authorizations oauth_authorizations_authorization_code_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.oauth_authorizations
    ADD CONSTRAINT oauth_authorizations_authorization_code_key UNIQUE (authorization_code);


--
-- Name: oauth_authorizations oauth_authorizations_authorization_id_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.oauth_authorizations
    ADD CONSTRAINT oauth_authorizations_authorization_id_key UNIQUE (authorization_id);


--
-- Name: oauth_authorizations oauth_authorizations_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.oauth_authorizations
    ADD CONSTRAINT oauth_authorizations_pkey PRIMARY KEY (id);


--
-- Name: oauth_clients oauth_clients_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.oauth_clients
    ADD CONSTRAINT oauth_clients_pkey PRIMARY KEY (id);


--
-- Name: oauth_consents oauth_consents_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.oauth_consents
    ADD CONSTRAINT oauth_consents_pkey PRIMARY KEY (id);


--
-- Name: oauth_consents oauth_consents_user_client_unique; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.oauth_consents
    ADD CONSTRAINT oauth_consents_user_client_unique UNIQUE (user_id, client_id);


--
-- Name: one_time_tokens one_time_tokens_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.one_time_tokens
    ADD CONSTRAINT one_time_tokens_pkey PRIMARY KEY (id);


--
-- Name: refresh_tokens refresh_tokens_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.refresh_tokens
    ADD CONSTRAINT refresh_tokens_pkey PRIMARY KEY (id);


--
-- Name: refresh_tokens refresh_tokens_token_unique; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.refresh_tokens
    ADD CONSTRAINT refresh_tokens_token_unique UNIQUE (token);


--
-- Name: saml_providers saml_providers_entity_id_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.saml_providers
    ADD CONSTRAINT saml_providers_entity_id_key UNIQUE (entity_id);


--
-- Name: saml_providers saml_providers_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.saml_providers
    ADD CONSTRAINT saml_providers_pkey PRIMARY KEY (id);


--
-- Name: saml_relay_states saml_relay_states_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.saml_relay_states
    ADD CONSTRAINT saml_relay_states_pkey PRIMARY KEY (id);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- Name: sso_domains sso_domains_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.sso_domains
    ADD CONSTRAINT sso_domains_pkey PRIMARY KEY (id);


--
-- Name: sso_providers sso_providers_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.sso_providers
    ADD CONSTRAINT sso_providers_pkey PRIMARY KEY (id);


--
-- Name: users users_phone_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.users
    ADD CONSTRAINT users_phone_key UNIQUE (phone);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: auth_group auth_group_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_name_key UNIQUE (name);


--
-- Name: auth_group_permissions auth_group_permissions_group_id_permission_id_0cd325b0_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_permission_id_0cd325b0_uniq UNIQUE (group_id, permission_id);


--
-- Name: auth_group_permissions auth_group_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_group auth_group_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_pkey PRIMARY KEY (id);


--
-- Name: auth_permission auth_permission_content_type_id_codename_01ab375a_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_codename_01ab375a_uniq UNIQUE (content_type_id, codename);


--
-- Name: auth_permission auth_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups auth_user_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups auth_user_groups_user_id_group_id_94350c0c_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_group_id_94350c0c_uniq UNIQUE (user_id, group_id);


--
-- Name: auth_user auth_user_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user
    ADD CONSTRAINT auth_user_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions auth_user_user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions auth_user_user_permissions_user_id_permission_id_14a6b632_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_user_id_permission_id_14a6b632_uniq UNIQUE (user_id, permission_id);


--
-- Name: auth_user auth_user_username_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user
    ADD CONSTRAINT auth_user_username_key UNIQUE (username);


--
-- Name: core_announcement core_announcement_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_announcement
    ADD CONSTRAINT core_announcement_pkey PRIMARY KEY (id);


--
-- Name: core_document core_document_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_document
    ADD CONSTRAINT core_document_pkey PRIMARY KEY (id);


--
-- Name: core_documentcategory core_documentcategory_nombre_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_documentcategory
    ADD CONSTRAINT core_documentcategory_nombre_key UNIQUE (nombre);


--
-- Name: core_documentcategory core_documentcategory_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_documentcategory
    ADD CONSTRAINT core_documentcategory_pkey PRIMARY KEY (id);


--
-- Name: core_fee core_fee_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_fee
    ADD CONSTRAINT core_fee_pkey PRIMARY KEY (id);


--
-- Name: core_household core_household_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_household
    ADD CONSTRAINT core_household_pkey PRIMARY KEY (id);


--
-- Name: core_household_residents core_household_residents_household_id_resident_id_028a9394_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_household_residents
    ADD CONSTRAINT core_household_residents_household_id_resident_id_028a9394_uniq UNIQUE (household_id, resident_id);


--
-- Name: core_household_residents core_household_residents_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_household_residents
    ADD CONSTRAINT core_household_residents_pkey PRIMARY KEY (id);


--
-- Name: core_incident core_incident_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_incident
    ADD CONSTRAINT core_incident_pkey PRIMARY KEY (id);


--
-- Name: core_incidentcategory core_incidentcategory_nombre_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_incidentcategory
    ADD CONSTRAINT core_incidentcategory_nombre_key UNIQUE (nombre);


--
-- Name: core_incidentcategory core_incidentcategory_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_incidentcategory
    ADD CONSTRAINT core_incidentcategory_pkey PRIMARY KEY (id);


--
-- Name: core_inscriptionevidence core_inscriptionevidence_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_inscriptionevidence
    ADD CONSTRAINT core_inscriptionevidence_pkey PRIMARY KEY (id);


--
-- Name: core_meeting core_meeting_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_meeting
    ADD CONSTRAINT core_meeting_pkey PRIMARY KEY (id);


--
-- Name: core_minutes core_minutes_meeting_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_minutes
    ADD CONSTRAINT core_minutes_meeting_id_key UNIQUE (meeting_id);


--
-- Name: core_minutes core_minutes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_minutes
    ADD CONSTRAINT core_minutes_pkey PRIMARY KEY (id);


--
-- Name: core_notification core_notification_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_notification
    ADD CONSTRAINT core_notification_pkey PRIMARY KEY (id);


--
-- Name: core_payment core_payment_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_payment
    ADD CONSTRAINT core_payment_pkey PRIMARY KEY (id);


--
-- Name: core_reservation core_reservation_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_reservation
    ADD CONSTRAINT core_reservation_pkey PRIMARY KEY (id);


--
-- Name: core_resident core_resident_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_resident
    ADD CONSTRAINT core_resident_pkey PRIMARY KEY (id);


--
-- Name: core_resident core_resident_rut_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_resident
    ADD CONSTRAINT core_resident_rut_key UNIQUE (rut);


--
-- Name: core_resident core_resident_user_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_resident
    ADD CONSTRAINT core_resident_user_id_key UNIQUE (user_id);


--
-- Name: core_resource core_resource_nombre_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_resource
    ADD CONSTRAINT core_resource_nombre_key UNIQUE (nombre);


--
-- Name: core_resource core_resource_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_resource
    ADD CONSTRAINT core_resource_pkey PRIMARY KEY (id);


--
-- Name: core_resourcecategory core_resourcecategory_nombre_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_resourcecategory
    ADD CONSTRAINT core_resourcecategory_nombre_key UNIQUE (nombre);


--
-- Name: core_resourcecategory core_resourcecategory_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_resourcecategory
    ADD CONSTRAINT core_resourcecategory_pkey PRIMARY KEY (id);


--
-- Name: django_admin_log django_admin_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_pkey PRIMARY KEY (id);


--
-- Name: django_content_type django_content_type_app_label_model_76bd3d3b_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_app_label_model_76bd3d3b_uniq UNIQUE (app_label, model);


--
-- Name: django_content_type django_content_type_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_pkey PRIMARY KEY (id);


--
-- Name: django_migrations django_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_migrations
    ADD CONSTRAINT django_migrations_pkey PRIMARY KEY (id);


--
-- Name: django_session django_session_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_session
    ADD CONSTRAINT django_session_pkey PRIMARY KEY (session_key);


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE ONLY realtime.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id, inserted_at);


--
-- Name: subscription pk_subscription; Type: CONSTRAINT; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY realtime.subscription
    ADD CONSTRAINT pk_subscription PRIMARY KEY (id);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY realtime.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: buckets_analytics buckets_analytics_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.buckets_analytics
    ADD CONSTRAINT buckets_analytics_pkey PRIMARY KEY (id);


--
-- Name: buckets buckets_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.buckets
    ADD CONSTRAINT buckets_pkey PRIMARY KEY (id);


--
-- Name: buckets_vectors buckets_vectors_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.buckets_vectors
    ADD CONSTRAINT buckets_vectors_pkey PRIMARY KEY (id);


--
-- Name: migrations migrations_name_key; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.migrations
    ADD CONSTRAINT migrations_name_key UNIQUE (name);


--
-- Name: migrations migrations_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.migrations
    ADD CONSTRAINT migrations_pkey PRIMARY KEY (id);


--
-- Name: objects objects_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.objects
    ADD CONSTRAINT objects_pkey PRIMARY KEY (id);


--
-- Name: prefixes prefixes_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.prefixes
    ADD CONSTRAINT prefixes_pkey PRIMARY KEY (bucket_id, level, name);


--
-- Name: s3_multipart_uploads_parts s3_multipart_uploads_parts_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.s3_multipart_uploads_parts
    ADD CONSTRAINT s3_multipart_uploads_parts_pkey PRIMARY KEY (id);


--
-- Name: s3_multipart_uploads s3_multipart_uploads_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.s3_multipart_uploads
    ADD CONSTRAINT s3_multipart_uploads_pkey PRIMARY KEY (id);


--
-- Name: vector_indexes vector_indexes_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.vector_indexes
    ADD CONSTRAINT vector_indexes_pkey PRIMARY KEY (id);


--
-- Name: audit_logs_instance_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX audit_logs_instance_id_idx ON auth.audit_log_entries USING btree (instance_id);


--
-- Name: confirmation_token_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX confirmation_token_idx ON auth.users USING btree (confirmation_token) WHERE ((confirmation_token)::text !~ '^[0-9 ]*$'::text);


--
-- Name: email_change_token_current_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX email_change_token_current_idx ON auth.users USING btree (email_change_token_current) WHERE ((email_change_token_current)::text !~ '^[0-9 ]*$'::text);


--
-- Name: email_change_token_new_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX email_change_token_new_idx ON auth.users USING btree (email_change_token_new) WHERE ((email_change_token_new)::text !~ '^[0-9 ]*$'::text);


--
-- Name: factor_id_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX factor_id_created_at_idx ON auth.mfa_factors USING btree (user_id, created_at);


--
-- Name: flow_state_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX flow_state_created_at_idx ON auth.flow_state USING btree (created_at DESC);


--
-- Name: identities_email_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX identities_email_idx ON auth.identities USING btree (email text_pattern_ops);


--
-- Name: INDEX identities_email_idx; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON INDEX auth.identities_email_idx IS 'Auth: Ensures indexed queries on the email column';


--
-- Name: identities_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX identities_user_id_idx ON auth.identities USING btree (user_id);


--
-- Name: idx_auth_code; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX idx_auth_code ON auth.flow_state USING btree (auth_code);


--
-- Name: idx_user_id_auth_method; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX idx_user_id_auth_method ON auth.flow_state USING btree (user_id, authentication_method);


--
-- Name: mfa_challenge_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX mfa_challenge_created_at_idx ON auth.mfa_challenges USING btree (created_at DESC);


--
-- Name: mfa_factors_user_friendly_name_unique; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX mfa_factors_user_friendly_name_unique ON auth.mfa_factors USING btree (friendly_name, user_id) WHERE (TRIM(BOTH FROM friendly_name) <> ''::text);


--
-- Name: mfa_factors_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX mfa_factors_user_id_idx ON auth.mfa_factors USING btree (user_id);


--
-- Name: oauth_auth_pending_exp_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX oauth_auth_pending_exp_idx ON auth.oauth_authorizations USING btree (expires_at) WHERE (status = 'pending'::auth.oauth_authorization_status);


--
-- Name: oauth_clients_deleted_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX oauth_clients_deleted_at_idx ON auth.oauth_clients USING btree (deleted_at);


--
-- Name: oauth_consents_active_client_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX oauth_consents_active_client_idx ON auth.oauth_consents USING btree (client_id) WHERE (revoked_at IS NULL);


--
-- Name: oauth_consents_active_user_client_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX oauth_consents_active_user_client_idx ON auth.oauth_consents USING btree (user_id, client_id) WHERE (revoked_at IS NULL);


--
-- Name: oauth_consents_user_order_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX oauth_consents_user_order_idx ON auth.oauth_consents USING btree (user_id, granted_at DESC);


--
-- Name: one_time_tokens_relates_to_hash_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX one_time_tokens_relates_to_hash_idx ON auth.one_time_tokens USING hash (relates_to);


--
-- Name: one_time_tokens_token_hash_hash_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX one_time_tokens_token_hash_hash_idx ON auth.one_time_tokens USING hash (token_hash);


--
-- Name: one_time_tokens_user_id_token_type_key; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX one_time_tokens_user_id_token_type_key ON auth.one_time_tokens USING btree (user_id, token_type);


--
-- Name: reauthentication_token_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX reauthentication_token_idx ON auth.users USING btree (reauthentication_token) WHERE ((reauthentication_token)::text !~ '^[0-9 ]*$'::text);


--
-- Name: recovery_token_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX recovery_token_idx ON auth.users USING btree (recovery_token) WHERE ((recovery_token)::text !~ '^[0-9 ]*$'::text);


--
-- Name: refresh_tokens_instance_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX refresh_tokens_instance_id_idx ON auth.refresh_tokens USING btree (instance_id);


--
-- Name: refresh_tokens_instance_id_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX refresh_tokens_instance_id_user_id_idx ON auth.refresh_tokens USING btree (instance_id, user_id);


--
-- Name: refresh_tokens_parent_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX refresh_tokens_parent_idx ON auth.refresh_tokens USING btree (parent);


--
-- Name: refresh_tokens_session_id_revoked_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX refresh_tokens_session_id_revoked_idx ON auth.refresh_tokens USING btree (session_id, revoked);


--
-- Name: refresh_tokens_updated_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX refresh_tokens_updated_at_idx ON auth.refresh_tokens USING btree (updated_at DESC);


--
-- Name: saml_providers_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX saml_providers_sso_provider_id_idx ON auth.saml_providers USING btree (sso_provider_id);


--
-- Name: saml_relay_states_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX saml_relay_states_created_at_idx ON auth.saml_relay_states USING btree (created_at DESC);


--
-- Name: saml_relay_states_for_email_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX saml_relay_states_for_email_idx ON auth.saml_relay_states USING btree (for_email);


--
-- Name: saml_relay_states_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX saml_relay_states_sso_provider_id_idx ON auth.saml_relay_states USING btree (sso_provider_id);


--
-- Name: sessions_not_after_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX sessions_not_after_idx ON auth.sessions USING btree (not_after DESC);


--
-- Name: sessions_oauth_client_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX sessions_oauth_client_id_idx ON auth.sessions USING btree (oauth_client_id);


--
-- Name: sessions_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX sessions_user_id_idx ON auth.sessions USING btree (user_id);


--
-- Name: sso_domains_domain_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX sso_domains_domain_idx ON auth.sso_domains USING btree (lower(domain));


--
-- Name: sso_domains_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX sso_domains_sso_provider_id_idx ON auth.sso_domains USING btree (sso_provider_id);


--
-- Name: sso_providers_resource_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX sso_providers_resource_id_idx ON auth.sso_providers USING btree (lower(resource_id));


--
-- Name: sso_providers_resource_id_pattern_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX sso_providers_resource_id_pattern_idx ON auth.sso_providers USING btree (resource_id text_pattern_ops);


--
-- Name: unique_phone_factor_per_user; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX unique_phone_factor_per_user ON auth.mfa_factors USING btree (user_id, phone);


--
-- Name: user_id_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX user_id_created_at_idx ON auth.sessions USING btree (user_id, created_at);


--
-- Name: users_email_partial_key; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX users_email_partial_key ON auth.users USING btree (email) WHERE (is_sso_user = false);


--
-- Name: INDEX users_email_partial_key; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON INDEX auth.users_email_partial_key IS 'Auth: A partial unique index that applies only when is_sso_user is false';


--
-- Name: users_instance_id_email_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX users_instance_id_email_idx ON auth.users USING btree (instance_id, lower((email)::text));


--
-- Name: users_instance_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX users_instance_id_idx ON auth.users USING btree (instance_id);


--
-- Name: users_is_anonymous_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX users_is_anonymous_idx ON auth.users USING btree (is_anonymous);


--
-- Name: auth_group_name_a6ea08ec_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_group_name_a6ea08ec_like ON public.auth_group USING btree (name varchar_pattern_ops);


--
-- Name: auth_group_permissions_group_id_b120cbf9; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_group_permissions_group_id_b120cbf9 ON public.auth_group_permissions USING btree (group_id);


--
-- Name: auth_group_permissions_permission_id_84c5c92e; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_group_permissions_permission_id_84c5c92e ON public.auth_group_permissions USING btree (permission_id);


--
-- Name: auth_permission_content_type_id_2f476e4b; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_permission_content_type_id_2f476e4b ON public.auth_permission USING btree (content_type_id);


--
-- Name: auth_user_groups_group_id_97559544; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_user_groups_group_id_97559544 ON public.auth_user_groups USING btree (group_id);


--
-- Name: auth_user_groups_user_id_6a12ed8b; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_user_groups_user_id_6a12ed8b ON public.auth_user_groups USING btree (user_id);


--
-- Name: auth_user_user_permissions_permission_id_1fbb5f2c; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_user_user_permissions_permission_id_1fbb5f2c ON public.auth_user_user_permissions USING btree (permission_id);


--
-- Name: auth_user_user_permissions_user_id_a95ead1b; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_user_user_permissions_user_id_a95ead1b ON public.auth_user_user_permissions USING btree (user_id);


--
-- Name: auth_user_username_6821ab7c_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_user_username_6821ab7c_like ON public.auth_user USING btree (username varchar_pattern_ops);


--
-- Name: core_announcement_creado_por_id_aec0b327; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_announcement_creado_por_id_aec0b327 ON public.core_announcement USING btree (creado_por_id);


--
-- Name: core_docume_created_f1aada_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_docume_created_f1aada_idx ON public.core_document USING btree (created_at);


--
-- Name: core_docume_is_acti_7ca999_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_docume_is_acti_7ca999_idx ON public.core_document USING btree (is_active);


--
-- Name: core_docume_visibil_95e48e_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_docume_visibil_95e48e_idx ON public.core_document USING btree (visibilidad);


--
-- Name: core_document_categoria_id_aa5c2874; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_document_categoria_id_aa5c2874 ON public.core_document USING btree (categoria_id);


--
-- Name: core_document_subido_por_id_1359e500; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_document_subido_por_id_1359e500 ON public.core_document USING btree (subido_por_id);


--
-- Name: core_documentcategory_nombre_6e5a5bf3_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_documentcategory_nombre_6e5a5bf3_like ON public.core_documentcategory USING btree (nombre varchar_pattern_ops);


--
-- Name: core_household_residents_household_id_a8349e24; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_household_residents_household_id_a8349e24 ON public.core_household_residents USING btree (household_id);


--
-- Name: core_household_residents_resident_id_3dda2fff; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_household_residents_resident_id_3dda2fff ON public.core_household_residents USING btree (resident_id);


--
-- Name: core_incide_created_f536cb_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_incide_created_f536cb_idx ON public.core_incident USING btree (created_at);


--
-- Name: core_incide_status_cb96ff_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_incide_status_cb96ff_idx ON public.core_incident USING btree (status);


--
-- Name: core_incident_asignada_a_id_b648fa0e; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_incident_asignada_a_id_b648fa0e ON public.core_incident USING btree (asignada_a_id);


--
-- Name: core_incident_categoria_id_dd49df8b; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_incident_categoria_id_dd49df8b ON public.core_incident USING btree (categoria_id);


--
-- Name: core_incident_reportado_por_id_9bf5e7e9; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_incident_reportado_por_id_9bf5e7e9 ON public.core_incident USING btree (reportado_por_id);


--
-- Name: core_incidentcategory_nombre_2be4f057_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_incidentcategory_nombre_2be4f057_like ON public.core_incidentcategory USING btree (nombre varchar_pattern_ops);


--
-- Name: core_inscriptionevidence_resident_id_f37812d2; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_inscriptionevidence_resident_id_f37812d2 ON public.core_inscriptionevidence USING btree (resident_id);


--
-- Name: core_inscriptionevidence_submitted_by_id_82b941b1; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_inscriptionevidence_submitted_by_id_82b941b1 ON public.core_inscriptionevidence USING btree (submitted_by_id);


--
-- Name: core_inscriptionevidence_validated_by_id_869167df; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_inscriptionevidence_validated_by_id_869167df ON public.core_inscriptionevidence USING btree (validated_by_id);


--
-- Name: core_meeting_creado_por_id_16bf067b; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_meeting_creado_por_id_16bf067b ON public.core_meeting USING btree (creado_por_id);


--
-- Name: core_notification_user_id_6e341aac; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_notification_user_id_6e341aac ON public.core_notification USING btree (user_id);


--
-- Name: core_payment_fee_id_4934488e; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_payment_fee_id_4934488e ON public.core_payment USING btree (fee_id);


--
-- Name: core_payment_reservation_id_e13057b1; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_payment_reservation_id_e13057b1 ON public.core_payment USING btree (reservation_id);


--
-- Name: core_payment_resident_id_f6b9ea87; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_payment_resident_id_f6b9ea87 ON public.core_payment USING btree (resident_id);


--
-- Name: core_payment_reviewed_by_id_18380879; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_payment_reviewed_by_id_18380879 ON public.core_payment USING btree (reviewed_by_id);


--
-- Name: core_reserv_resourc_5c6287_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_reserv_resourc_5c6287_idx ON public.core_reservation USING btree (resource_id);


--
-- Name: core_reserv_start_a_ae5f53_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_reserv_start_a_ae5f53_idx ON public.core_reservation USING btree (start_at);


--
-- Name: core_reserv_status_3b8861_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_reserv_status_3b8861_idx ON public.core_reservation USING btree (status);


--
-- Name: core_reservation_approved_by_id_54e20d4b; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_reservation_approved_by_id_54e20d4b ON public.core_reservation USING btree (approved_by_id);


--
-- Name: core_reservation_requested_by_id_840fb5c0; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_reservation_requested_by_id_840fb5c0 ON public.core_reservation USING btree (requested_by_id);


--
-- Name: core_reservation_resource_id_86ce7cf0; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_reservation_resource_id_86ce7cf0 ON public.core_reservation USING btree (resource_id);


--
-- Name: core_resident_rut_5c7def1a_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_resident_rut_5c7def1a_like ON public.core_resident USING btree (rut varchar_pattern_ops);


--
-- Name: core_resource_categoria_id_19667915; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_resource_categoria_id_19667915 ON public.core_resource USING btree (categoria_id);


--
-- Name: core_resource_nombre_a049a824_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_resource_nombre_a049a824_like ON public.core_resource USING btree (nombre varchar_pattern_ops);


--
-- Name: core_resourcecategory_nombre_da7b9087_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_resourcecategory_nombre_da7b9087_like ON public.core_resourcecategory USING btree (nombre varchar_pattern_ops);


--
-- Name: django_admin_log_content_type_id_c4bce8eb; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_admin_log_content_type_id_c4bce8eb ON public.django_admin_log USING btree (content_type_id);


--
-- Name: django_admin_log_user_id_c564eba6; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_admin_log_user_id_c564eba6 ON public.django_admin_log USING btree (user_id);


--
-- Name: django_session_expire_date_a5c62663; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_session_expire_date_a5c62663 ON public.django_session USING btree (expire_date);


--
-- Name: django_session_session_key_c0390e0f_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_session_session_key_c0390e0f_like ON public.django_session USING btree (session_key varchar_pattern_ops);


--
-- Name: unique_fee_payment_per_resident; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX unique_fee_payment_per_resident ON public.core_payment USING btree (resident_id, fee_id, origin) WHERE ((origin)::text = 'fee'::text);


--
-- Name: ix_realtime_subscription_entity; Type: INDEX; Schema: realtime; Owner: supabase_admin
--

CREATE INDEX ix_realtime_subscription_entity ON realtime.subscription USING btree (entity);


--
-- Name: messages_inserted_at_topic_index; Type: INDEX; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE INDEX messages_inserted_at_topic_index ON ONLY realtime.messages USING btree (inserted_at DESC, topic) WHERE ((extension = 'broadcast'::text) AND (private IS TRUE));


--
-- Name: subscription_subscription_id_entity_filters_key; Type: INDEX; Schema: realtime; Owner: supabase_admin
--

CREATE UNIQUE INDEX subscription_subscription_id_entity_filters_key ON realtime.subscription USING btree (subscription_id, entity, filters);


--
-- Name: bname; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE UNIQUE INDEX bname ON storage.buckets USING btree (name);


--
-- Name: bucketid_objname; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE UNIQUE INDEX bucketid_objname ON storage.objects USING btree (bucket_id, name);


--
-- Name: buckets_analytics_unique_name_idx; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE UNIQUE INDEX buckets_analytics_unique_name_idx ON storage.buckets_analytics USING btree (name) WHERE (deleted_at IS NULL);


--
-- Name: idx_multipart_uploads_list; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE INDEX idx_multipart_uploads_list ON storage.s3_multipart_uploads USING btree (bucket_id, key, created_at);


--
-- Name: idx_name_bucket_level_unique; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE UNIQUE INDEX idx_name_bucket_level_unique ON storage.objects USING btree (name COLLATE "C", bucket_id, level);


--
-- Name: idx_objects_bucket_id_name; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE INDEX idx_objects_bucket_id_name ON storage.objects USING btree (bucket_id, name COLLATE "C");


--
-- Name: idx_objects_lower_name; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE INDEX idx_objects_lower_name ON storage.objects USING btree ((path_tokens[level]), lower(name) text_pattern_ops, bucket_id, level);


--
-- Name: idx_prefixes_lower_name; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE INDEX idx_prefixes_lower_name ON storage.prefixes USING btree (bucket_id, level, ((string_to_array(name, '/'::text))[level]), lower(name) text_pattern_ops);


--
-- Name: name_prefix_search; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE INDEX name_prefix_search ON storage.objects USING btree (name text_pattern_ops);


--
-- Name: objects_bucket_id_level_idx; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE UNIQUE INDEX objects_bucket_id_level_idx ON storage.objects USING btree (bucket_id, level, name COLLATE "C");


--
-- Name: vector_indexes_name_bucket_id_idx; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE UNIQUE INDEX vector_indexes_name_bucket_id_idx ON storage.vector_indexes USING btree (name, bucket_id);


--
-- Name: subscription tr_check_filters; Type: TRIGGER; Schema: realtime; Owner: supabase_admin
--

CREATE TRIGGER tr_check_filters BEFORE INSERT OR UPDATE ON realtime.subscription FOR EACH ROW EXECUTE FUNCTION realtime.subscription_check_filters();


--
-- Name: buckets enforce_bucket_name_length_trigger; Type: TRIGGER; Schema: storage; Owner: supabase_storage_admin
--

CREATE TRIGGER enforce_bucket_name_length_trigger BEFORE INSERT OR UPDATE OF name ON storage.buckets FOR EACH ROW EXECUTE FUNCTION storage.enforce_bucket_name_length();


--
-- Name: objects objects_delete_delete_prefix; Type: TRIGGER; Schema: storage; Owner: supabase_storage_admin
--

CREATE TRIGGER objects_delete_delete_prefix AFTER DELETE ON storage.objects FOR EACH ROW EXECUTE FUNCTION storage.delete_prefix_hierarchy_trigger();


--
-- Name: objects objects_insert_create_prefix; Type: TRIGGER; Schema: storage; Owner: supabase_storage_admin
--

CREATE TRIGGER objects_insert_create_prefix BEFORE INSERT ON storage.objects FOR EACH ROW EXECUTE FUNCTION storage.objects_insert_prefix_trigger();


--
-- Name: objects objects_update_create_prefix; Type: TRIGGER; Schema: storage; Owner: supabase_storage_admin
--

CREATE TRIGGER objects_update_create_prefix BEFORE UPDATE ON storage.objects FOR EACH ROW WHEN (((new.name <> old.name) OR (new.bucket_id <> old.bucket_id))) EXECUTE FUNCTION storage.objects_update_prefix_trigger();


--
-- Name: prefixes prefixes_create_hierarchy; Type: TRIGGER; Schema: storage; Owner: supabase_storage_admin
--

CREATE TRIGGER prefixes_create_hierarchy BEFORE INSERT ON storage.prefixes FOR EACH ROW WHEN ((pg_trigger_depth() < 1)) EXECUTE FUNCTION storage.prefixes_insert_trigger();


--
-- Name: prefixes prefixes_delete_hierarchy; Type: TRIGGER; Schema: storage; Owner: supabase_storage_admin
--

CREATE TRIGGER prefixes_delete_hierarchy AFTER DELETE ON storage.prefixes FOR EACH ROW EXECUTE FUNCTION storage.delete_prefix_hierarchy_trigger();


--
-- Name: objects update_objects_updated_at; Type: TRIGGER; Schema: storage; Owner: supabase_storage_admin
--

CREATE TRIGGER update_objects_updated_at BEFORE UPDATE ON storage.objects FOR EACH ROW EXECUTE FUNCTION storage.update_updated_at_column();


--
-- Name: identities identities_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.identities
    ADD CONSTRAINT identities_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: mfa_amr_claims mfa_amr_claims_session_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_amr_claims
    ADD CONSTRAINT mfa_amr_claims_session_id_fkey FOREIGN KEY (session_id) REFERENCES auth.sessions(id) ON DELETE CASCADE;


--
-- Name: mfa_challenges mfa_challenges_auth_factor_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_challenges
    ADD CONSTRAINT mfa_challenges_auth_factor_id_fkey FOREIGN KEY (factor_id) REFERENCES auth.mfa_factors(id) ON DELETE CASCADE;


--
-- Name: mfa_factors mfa_factors_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.mfa_factors
    ADD CONSTRAINT mfa_factors_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: oauth_authorizations oauth_authorizations_client_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.oauth_authorizations
    ADD CONSTRAINT oauth_authorizations_client_id_fkey FOREIGN KEY (client_id) REFERENCES auth.oauth_clients(id) ON DELETE CASCADE;


--
-- Name: oauth_authorizations oauth_authorizations_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.oauth_authorizations
    ADD CONSTRAINT oauth_authorizations_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: oauth_consents oauth_consents_client_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.oauth_consents
    ADD CONSTRAINT oauth_consents_client_id_fkey FOREIGN KEY (client_id) REFERENCES auth.oauth_clients(id) ON DELETE CASCADE;


--
-- Name: oauth_consents oauth_consents_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.oauth_consents
    ADD CONSTRAINT oauth_consents_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: one_time_tokens one_time_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.one_time_tokens
    ADD CONSTRAINT one_time_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: refresh_tokens refresh_tokens_session_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.refresh_tokens
    ADD CONSTRAINT refresh_tokens_session_id_fkey FOREIGN KEY (session_id) REFERENCES auth.sessions(id) ON DELETE CASCADE;


--
-- Name: saml_providers saml_providers_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.saml_providers
    ADD CONSTRAINT saml_providers_sso_provider_id_fkey FOREIGN KEY (sso_provider_id) REFERENCES auth.sso_providers(id) ON DELETE CASCADE;


--
-- Name: saml_relay_states saml_relay_states_flow_state_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.saml_relay_states
    ADD CONSTRAINT saml_relay_states_flow_state_id_fkey FOREIGN KEY (flow_state_id) REFERENCES auth.flow_state(id) ON DELETE CASCADE;


--
-- Name: saml_relay_states saml_relay_states_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.saml_relay_states
    ADD CONSTRAINT saml_relay_states_sso_provider_id_fkey FOREIGN KEY (sso_provider_id) REFERENCES auth.sso_providers(id) ON DELETE CASCADE;


--
-- Name: sessions sessions_oauth_client_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.sessions
    ADD CONSTRAINT sessions_oauth_client_id_fkey FOREIGN KEY (oauth_client_id) REFERENCES auth.oauth_clients(id) ON DELETE CASCADE;


--
-- Name: sessions sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.sessions
    ADD CONSTRAINT sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: sso_domains sso_domains_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY auth.sso_domains
    ADD CONSTRAINT sso_domains_sso_provider_id_fkey FOREIGN KEY (sso_provider_id) REFERENCES auth.sso_providers(id) ON DELETE CASCADE;


--
-- Name: auth_group_permissions auth_group_permissio_permission_id_84c5c92e_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissio_permission_id_84c5c92e_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions auth_group_permissions_group_id_b120cbf9_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_b120cbf9_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_permission auth_permission_content_type_id_2f476e4b_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_2f476e4b_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_groups auth_user_groups_group_id_97559544_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_group_id_97559544_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_groups auth_user_groups_user_id_6a12ed8b_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_6a12ed8b_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_user_permissions auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_user_permissions auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_announcement core_announcement_creado_por_id_aec0b327_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_announcement
    ADD CONSTRAINT core_announcement_creado_por_id_aec0b327_fk_auth_user_id FOREIGN KEY (creado_por_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_document core_document_categoria_id_aa5c2874_fk_core_documentcategory_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_document
    ADD CONSTRAINT core_document_categoria_id_aa5c2874_fk_core_documentcategory_id FOREIGN KEY (categoria_id) REFERENCES public.core_documentcategory(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_document core_document_subido_por_id_1359e500_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_document
    ADD CONSTRAINT core_document_subido_por_id_1359e500_fk_auth_user_id FOREIGN KEY (subido_por_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_household_residents core_household_resid_household_id_a8349e24_fk_core_hous; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_household_residents
    ADD CONSTRAINT core_household_resid_household_id_a8349e24_fk_core_hous FOREIGN KEY (household_id) REFERENCES public.core_household(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_household_residents core_household_resid_resident_id_3dda2fff_fk_core_resi; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_household_residents
    ADD CONSTRAINT core_household_resid_resident_id_3dda2fff_fk_core_resi FOREIGN KEY (resident_id) REFERENCES public.core_resident(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_incident core_incident_asignada_a_id_b648fa0e_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_incident
    ADD CONSTRAINT core_incident_asignada_a_id_b648fa0e_fk_auth_user_id FOREIGN KEY (asignada_a_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_incident core_incident_categoria_id_dd49df8b_fk_core_incidentcategory_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_incident
    ADD CONSTRAINT core_incident_categoria_id_dd49df8b_fk_core_incidentcategory_id FOREIGN KEY (categoria_id) REFERENCES public.core_incidentcategory(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_incident core_incident_reportado_por_id_9bf5e7e9_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_incident
    ADD CONSTRAINT core_incident_reportado_por_id_9bf5e7e9_fk_auth_user_id FOREIGN KEY (reportado_por_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_inscriptionevidence core_inscriptionevid_resident_id_f37812d2_fk_core_resi; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_inscriptionevidence
    ADD CONSTRAINT core_inscriptionevid_resident_id_f37812d2_fk_core_resi FOREIGN KEY (resident_id) REFERENCES public.core_resident(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_inscriptionevidence core_inscriptionevid_submitted_by_id_82b941b1_fk_auth_user; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_inscriptionevidence
    ADD CONSTRAINT core_inscriptionevid_submitted_by_id_82b941b1_fk_auth_user FOREIGN KEY (submitted_by_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_inscriptionevidence core_inscriptionevid_validated_by_id_869167df_fk_auth_user; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_inscriptionevidence
    ADD CONSTRAINT core_inscriptionevid_validated_by_id_869167df_fk_auth_user FOREIGN KEY (validated_by_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_meeting core_meeting_creado_por_id_16bf067b_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_meeting
    ADD CONSTRAINT core_meeting_creado_por_id_16bf067b_fk_auth_user_id FOREIGN KEY (creado_por_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_minutes core_minutes_meeting_id_332eac12_fk_core_meeting_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_minutes
    ADD CONSTRAINT core_minutes_meeting_id_332eac12_fk_core_meeting_id FOREIGN KEY (meeting_id) REFERENCES public.core_meeting(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_notification core_notification_user_id_6e341aac_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_notification
    ADD CONSTRAINT core_notification_user_id_6e341aac_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_payment core_payment_fee_id_4934488e_fk_core_fee_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_payment
    ADD CONSTRAINT core_payment_fee_id_4934488e_fk_core_fee_id FOREIGN KEY (fee_id) REFERENCES public.core_fee(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_payment core_payment_reservation_id_e13057b1_fk_core_reservation_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_payment
    ADD CONSTRAINT core_payment_reservation_id_e13057b1_fk_core_reservation_id FOREIGN KEY (reservation_id) REFERENCES public.core_reservation(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_payment core_payment_resident_id_f6b9ea87_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_payment
    ADD CONSTRAINT core_payment_resident_id_f6b9ea87_fk_auth_user_id FOREIGN KEY (resident_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_payment core_payment_reviewed_by_id_18380879_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_payment
    ADD CONSTRAINT core_payment_reviewed_by_id_18380879_fk_auth_user_id FOREIGN KEY (reviewed_by_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_reservation core_reservation_approved_by_id_54e20d4b_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_reservation
    ADD CONSTRAINT core_reservation_approved_by_id_54e20d4b_fk_auth_user_id FOREIGN KEY (approved_by_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_reservation core_reservation_requested_by_id_840fb5c0_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_reservation
    ADD CONSTRAINT core_reservation_requested_by_id_840fb5c0_fk_auth_user_id FOREIGN KEY (requested_by_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_reservation core_reservation_resource_id_86ce7cf0_fk_core_resource_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_reservation
    ADD CONSTRAINT core_reservation_resource_id_86ce7cf0_fk_core_resource_id FOREIGN KEY (resource_id) REFERENCES public.core_resource(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_resident core_resident_user_id_f7e9491b_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_resident
    ADD CONSTRAINT core_resident_user_id_f7e9491b_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_resource core_resource_categoria_id_19667915_fk_core_resourcecategory_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.core_resource
    ADD CONSTRAINT core_resource_categoria_id_19667915_fk_core_resourcecategory_id FOREIGN KEY (categoria_id) REFERENCES public.core_resourcecategory(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_content_type_id_c4bce8eb_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_content_type_id_c4bce8eb_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_user_id_c564eba6_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_user_id_c564eba6_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: objects objects_bucketId_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.objects
    ADD CONSTRAINT "objects_bucketId_fkey" FOREIGN KEY (bucket_id) REFERENCES storage.buckets(id);


--
-- Name: prefixes prefixes_bucketId_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.prefixes
    ADD CONSTRAINT "prefixes_bucketId_fkey" FOREIGN KEY (bucket_id) REFERENCES storage.buckets(id);


--
-- Name: s3_multipart_uploads s3_multipart_uploads_bucket_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.s3_multipart_uploads
    ADD CONSTRAINT s3_multipart_uploads_bucket_id_fkey FOREIGN KEY (bucket_id) REFERENCES storage.buckets(id);


--
-- Name: s3_multipart_uploads_parts s3_multipart_uploads_parts_bucket_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.s3_multipart_uploads_parts
    ADD CONSTRAINT s3_multipart_uploads_parts_bucket_id_fkey FOREIGN KEY (bucket_id) REFERENCES storage.buckets(id);


--
-- Name: s3_multipart_uploads_parts s3_multipart_uploads_parts_upload_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.s3_multipart_uploads_parts
    ADD CONSTRAINT s3_multipart_uploads_parts_upload_id_fkey FOREIGN KEY (upload_id) REFERENCES storage.s3_multipart_uploads(id) ON DELETE CASCADE;


--
-- Name: vector_indexes vector_indexes_bucket_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY storage.vector_indexes
    ADD CONSTRAINT vector_indexes_bucket_id_fkey FOREIGN KEY (bucket_id) REFERENCES storage.buckets_vectors(id);


--
-- Name: audit_log_entries; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.audit_log_entries ENABLE ROW LEVEL SECURITY;

--
-- Name: flow_state; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.flow_state ENABLE ROW LEVEL SECURITY;

--
-- Name: identities; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.identities ENABLE ROW LEVEL SECURITY;

--
-- Name: instances; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.instances ENABLE ROW LEVEL SECURITY;

--
-- Name: mfa_amr_claims; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.mfa_amr_claims ENABLE ROW LEVEL SECURITY;

--
-- Name: mfa_challenges; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.mfa_challenges ENABLE ROW LEVEL SECURITY;

--
-- Name: mfa_factors; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.mfa_factors ENABLE ROW LEVEL SECURITY;

--
-- Name: one_time_tokens; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.one_time_tokens ENABLE ROW LEVEL SECURITY;

--
-- Name: refresh_tokens; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.refresh_tokens ENABLE ROW LEVEL SECURITY;

--
-- Name: saml_providers; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.saml_providers ENABLE ROW LEVEL SECURITY;

--
-- Name: saml_relay_states; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.saml_relay_states ENABLE ROW LEVEL SECURITY;

--
-- Name: schema_migrations; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.schema_migrations ENABLE ROW LEVEL SECURITY;

--
-- Name: sessions; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.sessions ENABLE ROW LEVEL SECURITY;

--
-- Name: sso_domains; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.sso_domains ENABLE ROW LEVEL SECURITY;

--
-- Name: sso_providers; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.sso_providers ENABLE ROW LEVEL SECURITY;

--
-- Name: users; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE auth.users ENABLE ROW LEVEL SECURITY;

--
-- Name: messages; Type: ROW SECURITY; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE realtime.messages ENABLE ROW LEVEL SECURITY;

--
-- Name: buckets; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE storage.buckets ENABLE ROW LEVEL SECURITY;

--
-- Name: buckets_analytics; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE storage.buckets_analytics ENABLE ROW LEVEL SECURITY;

--
-- Name: buckets_vectors; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE storage.buckets_vectors ENABLE ROW LEVEL SECURITY;

--
-- Name: migrations; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE storage.migrations ENABLE ROW LEVEL SECURITY;

--
-- Name: objects; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE storage.objects ENABLE ROW LEVEL SECURITY;

--
-- Name: prefixes; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE storage.prefixes ENABLE ROW LEVEL SECURITY;

--
-- Name: s3_multipart_uploads; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE storage.s3_multipart_uploads ENABLE ROW LEVEL SECURITY;

--
-- Name: s3_multipart_uploads_parts; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE storage.s3_multipart_uploads_parts ENABLE ROW LEVEL SECURITY;

--
-- Name: vector_indexes; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE storage.vector_indexes ENABLE ROW LEVEL SECURITY;

--
-- Name: supabase_realtime; Type: PUBLICATION; Schema: -; Owner: postgres
--

CREATE PUBLICATION supabase_realtime WITH (publish = 'insert, update, delete, truncate');


ALTER PUBLICATION supabase_realtime OWNER TO postgres;

--
-- Name: SCHEMA auth; Type: ACL; Schema: -; Owner: supabase_admin
--

GRANT USAGE ON SCHEMA auth TO anon;
GRANT USAGE ON SCHEMA auth TO authenticated;
GRANT USAGE ON SCHEMA auth TO service_role;
GRANT ALL ON SCHEMA auth TO supabase_auth_admin;
GRANT ALL ON SCHEMA auth TO dashboard_user;
GRANT USAGE ON SCHEMA auth TO postgres;


--
-- Name: SCHEMA extensions; Type: ACL; Schema: -; Owner: postgres
--

GRANT USAGE ON SCHEMA extensions TO anon;
GRANT USAGE ON SCHEMA extensions TO authenticated;
GRANT USAGE ON SCHEMA extensions TO service_role;
GRANT ALL ON SCHEMA extensions TO dashboard_user;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: pg_database_owner
--

GRANT USAGE ON SCHEMA public TO postgres;
GRANT USAGE ON SCHEMA public TO anon;
GRANT USAGE ON SCHEMA public TO authenticated;
GRANT USAGE ON SCHEMA public TO service_role;


--
-- Name: SCHEMA realtime; Type: ACL; Schema: -; Owner: supabase_admin
--

GRANT USAGE ON SCHEMA realtime TO postgres;
GRANT USAGE ON SCHEMA realtime TO anon;
GRANT USAGE ON SCHEMA realtime TO authenticated;
GRANT USAGE ON SCHEMA realtime TO service_role;
GRANT ALL ON SCHEMA realtime TO supabase_realtime_admin;


--
-- Name: SCHEMA storage; Type: ACL; Schema: -; Owner: supabase_admin
--

GRANT USAGE ON SCHEMA storage TO postgres WITH GRANT OPTION;
GRANT USAGE ON SCHEMA storage TO anon;
GRANT USAGE ON SCHEMA storage TO authenticated;
GRANT USAGE ON SCHEMA storage TO service_role;
GRANT ALL ON SCHEMA storage TO supabase_storage_admin;
GRANT ALL ON SCHEMA storage TO dashboard_user;


--
-- Name: SCHEMA vault; Type: ACL; Schema: -; Owner: supabase_admin
--

GRANT USAGE ON SCHEMA vault TO postgres WITH GRANT OPTION;
GRANT USAGE ON SCHEMA vault TO service_role;


--
-- Name: FUNCTION email(); Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON FUNCTION auth.email() TO dashboard_user;


--
-- Name: FUNCTION jwt(); Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON FUNCTION auth.jwt() TO postgres;
GRANT ALL ON FUNCTION auth.jwt() TO dashboard_user;


--
-- Name: FUNCTION role(); Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON FUNCTION auth.role() TO dashboard_user;


--
-- Name: FUNCTION uid(); Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON FUNCTION auth.uid() TO dashboard_user;


--
-- Name: FUNCTION armor(bytea); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.armor(bytea) FROM postgres;
GRANT ALL ON FUNCTION extensions.armor(bytea) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.armor(bytea) TO dashboard_user;


--
-- Name: FUNCTION armor(bytea, text[], text[]); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.armor(bytea, text[], text[]) FROM postgres;
GRANT ALL ON FUNCTION extensions.armor(bytea, text[], text[]) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.armor(bytea, text[], text[]) TO dashboard_user;


--
-- Name: FUNCTION crypt(text, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.crypt(text, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.crypt(text, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.crypt(text, text) TO dashboard_user;


--
-- Name: FUNCTION dearmor(text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.dearmor(text) FROM postgres;
GRANT ALL ON FUNCTION extensions.dearmor(text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.dearmor(text) TO dashboard_user;


--
-- Name: FUNCTION decrypt(bytea, bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.decrypt(bytea, bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.decrypt(bytea, bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.decrypt(bytea, bytea, text) TO dashboard_user;


--
-- Name: FUNCTION decrypt_iv(bytea, bytea, bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.decrypt_iv(bytea, bytea, bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.decrypt_iv(bytea, bytea, bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.decrypt_iv(bytea, bytea, bytea, text) TO dashboard_user;


--
-- Name: FUNCTION digest(bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.digest(bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.digest(bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.digest(bytea, text) TO dashboard_user;


--
-- Name: FUNCTION digest(text, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.digest(text, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.digest(text, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.digest(text, text) TO dashboard_user;


--
-- Name: FUNCTION encrypt(bytea, bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.encrypt(bytea, bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.encrypt(bytea, bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.encrypt(bytea, bytea, text) TO dashboard_user;


--
-- Name: FUNCTION encrypt_iv(bytea, bytea, bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.encrypt_iv(bytea, bytea, bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.encrypt_iv(bytea, bytea, bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.encrypt_iv(bytea, bytea, bytea, text) TO dashboard_user;


--
-- Name: FUNCTION gen_random_bytes(integer); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.gen_random_bytes(integer) FROM postgres;
GRANT ALL ON FUNCTION extensions.gen_random_bytes(integer) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.gen_random_bytes(integer) TO dashboard_user;


--
-- Name: FUNCTION gen_random_uuid(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.gen_random_uuid() FROM postgres;
GRANT ALL ON FUNCTION extensions.gen_random_uuid() TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.gen_random_uuid() TO dashboard_user;


--
-- Name: FUNCTION gen_salt(text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.gen_salt(text) FROM postgres;
GRANT ALL ON FUNCTION extensions.gen_salt(text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.gen_salt(text) TO dashboard_user;


--
-- Name: FUNCTION gen_salt(text, integer); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.gen_salt(text, integer) FROM postgres;
GRANT ALL ON FUNCTION extensions.gen_salt(text, integer) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.gen_salt(text, integer) TO dashboard_user;


--
-- Name: FUNCTION grant_pg_cron_access(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

REVOKE ALL ON FUNCTION extensions.grant_pg_cron_access() FROM supabase_admin;
GRANT ALL ON FUNCTION extensions.grant_pg_cron_access() TO supabase_admin WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.grant_pg_cron_access() TO dashboard_user;


--
-- Name: FUNCTION grant_pg_graphql_access(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.grant_pg_graphql_access() TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION grant_pg_net_access(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

REVOKE ALL ON FUNCTION extensions.grant_pg_net_access() FROM supabase_admin;
GRANT ALL ON FUNCTION extensions.grant_pg_net_access() TO supabase_admin WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.grant_pg_net_access() TO dashboard_user;


--
-- Name: FUNCTION hmac(bytea, bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.hmac(bytea, bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.hmac(bytea, bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.hmac(bytea, bytea, text) TO dashboard_user;


--
-- Name: FUNCTION hmac(text, text, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.hmac(text, text, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.hmac(text, text, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.hmac(text, text, text) TO dashboard_user;


--
-- Name: FUNCTION pg_stat_statements(showtext boolean, OUT userid oid, OUT dbid oid, OUT toplevel boolean, OUT queryid bigint, OUT query text, OUT plans bigint, OUT total_plan_time double precision, OUT min_plan_time double precision, OUT max_plan_time double precision, OUT mean_plan_time double precision, OUT stddev_plan_time double precision, OUT calls bigint, OUT total_exec_time double precision, OUT min_exec_time double precision, OUT max_exec_time double precision, OUT mean_exec_time double precision, OUT stddev_exec_time double precision, OUT rows bigint, OUT shared_blks_hit bigint, OUT shared_blks_read bigint, OUT shared_blks_dirtied bigint, OUT shared_blks_written bigint, OUT local_blks_hit bigint, OUT local_blks_read bigint, OUT local_blks_dirtied bigint, OUT local_blks_written bigint, OUT temp_blks_read bigint, OUT temp_blks_written bigint, OUT shared_blk_read_time double precision, OUT shared_blk_write_time double precision, OUT local_blk_read_time double precision, OUT local_blk_write_time double precision, OUT temp_blk_read_time double precision, OUT temp_blk_write_time double precision, OUT wal_records bigint, OUT wal_fpi bigint, OUT wal_bytes numeric, OUT jit_functions bigint, OUT jit_generation_time double precision, OUT jit_inlining_count bigint, OUT jit_inlining_time double precision, OUT jit_optimization_count bigint, OUT jit_optimization_time double precision, OUT jit_emission_count bigint, OUT jit_emission_time double precision, OUT jit_deform_count bigint, OUT jit_deform_time double precision, OUT stats_since timestamp with time zone, OUT minmax_stats_since timestamp with time zone); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pg_stat_statements(showtext boolean, OUT userid oid, OUT dbid oid, OUT toplevel boolean, OUT queryid bigint, OUT query text, OUT plans bigint, OUT total_plan_time double precision, OUT min_plan_time double precision, OUT max_plan_time double precision, OUT mean_plan_time double precision, OUT stddev_plan_time double precision, OUT calls bigint, OUT total_exec_time double precision, OUT min_exec_time double precision, OUT max_exec_time double precision, OUT mean_exec_time double precision, OUT stddev_exec_time double precision, OUT rows bigint, OUT shared_blks_hit bigint, OUT shared_blks_read bigint, OUT shared_blks_dirtied bigint, OUT shared_blks_written bigint, OUT local_blks_hit bigint, OUT local_blks_read bigint, OUT local_blks_dirtied bigint, OUT local_blks_written bigint, OUT temp_blks_read bigint, OUT temp_blks_written bigint, OUT shared_blk_read_time double precision, OUT shared_blk_write_time double precision, OUT local_blk_read_time double precision, OUT local_blk_write_time double precision, OUT temp_blk_read_time double precision, OUT temp_blk_write_time double precision, OUT wal_records bigint, OUT wal_fpi bigint, OUT wal_bytes numeric, OUT jit_functions bigint, OUT jit_generation_time double precision, OUT jit_inlining_count bigint, OUT jit_inlining_time double precision, OUT jit_optimization_count bigint, OUT jit_optimization_time double precision, OUT jit_emission_count bigint, OUT jit_emission_time double precision, OUT jit_deform_count bigint, OUT jit_deform_time double precision, OUT stats_since timestamp with time zone, OUT minmax_stats_since timestamp with time zone) FROM postgres;
GRANT ALL ON FUNCTION extensions.pg_stat_statements(showtext boolean, OUT userid oid, OUT dbid oid, OUT toplevel boolean, OUT queryid bigint, OUT query text, OUT plans bigint, OUT total_plan_time double precision, OUT min_plan_time double precision, OUT max_plan_time double precision, OUT mean_plan_time double precision, OUT stddev_plan_time double precision, OUT calls bigint, OUT total_exec_time double precision, OUT min_exec_time double precision, OUT max_exec_time double precision, OUT mean_exec_time double precision, OUT stddev_exec_time double precision, OUT rows bigint, OUT shared_blks_hit bigint, OUT shared_blks_read bigint, OUT shared_blks_dirtied bigint, OUT shared_blks_written bigint, OUT local_blks_hit bigint, OUT local_blks_read bigint, OUT local_blks_dirtied bigint, OUT local_blks_written bigint, OUT temp_blks_read bigint, OUT temp_blks_written bigint, OUT shared_blk_read_time double precision, OUT shared_blk_write_time double precision, OUT local_blk_read_time double precision, OUT local_blk_write_time double precision, OUT temp_blk_read_time double precision, OUT temp_blk_write_time double precision, OUT wal_records bigint, OUT wal_fpi bigint, OUT wal_bytes numeric, OUT jit_functions bigint, OUT jit_generation_time double precision, OUT jit_inlining_count bigint, OUT jit_inlining_time double precision, OUT jit_optimization_count bigint, OUT jit_optimization_time double precision, OUT jit_emission_count bigint, OUT jit_emission_time double precision, OUT jit_deform_count bigint, OUT jit_deform_time double precision, OUT stats_since timestamp with time zone, OUT minmax_stats_since timestamp with time zone) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pg_stat_statements(showtext boolean, OUT userid oid, OUT dbid oid, OUT toplevel boolean, OUT queryid bigint, OUT query text, OUT plans bigint, OUT total_plan_time double precision, OUT min_plan_time double precision, OUT max_plan_time double precision, OUT mean_plan_time double precision, OUT stddev_plan_time double precision, OUT calls bigint, OUT total_exec_time double precision, OUT min_exec_time double precision, OUT max_exec_time double precision, OUT mean_exec_time double precision, OUT stddev_exec_time double precision, OUT rows bigint, OUT shared_blks_hit bigint, OUT shared_blks_read bigint, OUT shared_blks_dirtied bigint, OUT shared_blks_written bigint, OUT local_blks_hit bigint, OUT local_blks_read bigint, OUT local_blks_dirtied bigint, OUT local_blks_written bigint, OUT temp_blks_read bigint, OUT temp_blks_written bigint, OUT shared_blk_read_time double precision, OUT shared_blk_write_time double precision, OUT local_blk_read_time double precision, OUT local_blk_write_time double precision, OUT temp_blk_read_time double precision, OUT temp_blk_write_time double precision, OUT wal_records bigint, OUT wal_fpi bigint, OUT wal_bytes numeric, OUT jit_functions bigint, OUT jit_generation_time double precision, OUT jit_inlining_count bigint, OUT jit_inlining_time double precision, OUT jit_optimization_count bigint, OUT jit_optimization_time double precision, OUT jit_emission_count bigint, OUT jit_emission_time double precision, OUT jit_deform_count bigint, OUT jit_deform_time double precision, OUT stats_since timestamp with time zone, OUT minmax_stats_since timestamp with time zone) TO dashboard_user;


--
-- Name: FUNCTION pg_stat_statements_info(OUT dealloc bigint, OUT stats_reset timestamp with time zone); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pg_stat_statements_info(OUT dealloc bigint, OUT stats_reset timestamp with time zone) FROM postgres;
GRANT ALL ON FUNCTION extensions.pg_stat_statements_info(OUT dealloc bigint, OUT stats_reset timestamp with time zone) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pg_stat_statements_info(OUT dealloc bigint, OUT stats_reset timestamp with time zone) TO dashboard_user;


--
-- Name: FUNCTION pg_stat_statements_reset(userid oid, dbid oid, queryid bigint, minmax_only boolean); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pg_stat_statements_reset(userid oid, dbid oid, queryid bigint, minmax_only boolean) FROM postgres;
GRANT ALL ON FUNCTION extensions.pg_stat_statements_reset(userid oid, dbid oid, queryid bigint, minmax_only boolean) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pg_stat_statements_reset(userid oid, dbid oid, queryid bigint, minmax_only boolean) TO dashboard_user;


--
-- Name: FUNCTION pgp_armor_headers(text, OUT key text, OUT value text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_armor_headers(text, OUT key text, OUT value text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_armor_headers(text, OUT key text, OUT value text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_armor_headers(text, OUT key text, OUT value text) TO dashboard_user;


--
-- Name: FUNCTION pgp_key_id(bytea); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_key_id(bytea) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_key_id(bytea) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_key_id(bytea) TO dashboard_user;


--
-- Name: FUNCTION pgp_pub_decrypt(bytea, bytea); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_pub_decrypt(bytea, bytea) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt(bytea, bytea) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt(bytea, bytea) TO dashboard_user;


--
-- Name: FUNCTION pgp_pub_decrypt(bytea, bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_pub_decrypt(bytea, bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt(bytea, bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt(bytea, bytea, text) TO dashboard_user;


--
-- Name: FUNCTION pgp_pub_decrypt(bytea, bytea, text, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_pub_decrypt(bytea, bytea, text, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt(bytea, bytea, text, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt(bytea, bytea, text, text) TO dashboard_user;


--
-- Name: FUNCTION pgp_pub_decrypt_bytea(bytea, bytea); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_pub_decrypt_bytea(bytea, bytea) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt_bytea(bytea, bytea) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt_bytea(bytea, bytea) TO dashboard_user;


--
-- Name: FUNCTION pgp_pub_decrypt_bytea(bytea, bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_pub_decrypt_bytea(bytea, bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt_bytea(bytea, bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt_bytea(bytea, bytea, text) TO dashboard_user;


--
-- Name: FUNCTION pgp_pub_decrypt_bytea(bytea, bytea, text, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_pub_decrypt_bytea(bytea, bytea, text, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt_bytea(bytea, bytea, text, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt_bytea(bytea, bytea, text, text) TO dashboard_user;


--
-- Name: FUNCTION pgp_pub_encrypt(text, bytea); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_pub_encrypt(text, bytea) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_pub_encrypt(text, bytea) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_pub_encrypt(text, bytea) TO dashboard_user;


--
-- Name: FUNCTION pgp_pub_encrypt(text, bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_pub_encrypt(text, bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_pub_encrypt(text, bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_pub_encrypt(text, bytea, text) TO dashboard_user;


--
-- Name: FUNCTION pgp_pub_encrypt_bytea(bytea, bytea); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_pub_encrypt_bytea(bytea, bytea) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_pub_encrypt_bytea(bytea, bytea) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_pub_encrypt_bytea(bytea, bytea) TO dashboard_user;


--
-- Name: FUNCTION pgp_pub_encrypt_bytea(bytea, bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_pub_encrypt_bytea(bytea, bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_pub_encrypt_bytea(bytea, bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_pub_encrypt_bytea(bytea, bytea, text) TO dashboard_user;


--
-- Name: FUNCTION pgp_sym_decrypt(bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_sym_decrypt(bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_sym_decrypt(bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_sym_decrypt(bytea, text) TO dashboard_user;


--
-- Name: FUNCTION pgp_sym_decrypt(bytea, text, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_sym_decrypt(bytea, text, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_sym_decrypt(bytea, text, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_sym_decrypt(bytea, text, text) TO dashboard_user;


--
-- Name: FUNCTION pgp_sym_decrypt_bytea(bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_sym_decrypt_bytea(bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_sym_decrypt_bytea(bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_sym_decrypt_bytea(bytea, text) TO dashboard_user;


--
-- Name: FUNCTION pgp_sym_decrypt_bytea(bytea, text, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_sym_decrypt_bytea(bytea, text, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_sym_decrypt_bytea(bytea, text, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_sym_decrypt_bytea(bytea, text, text) TO dashboard_user;


--
-- Name: FUNCTION pgp_sym_encrypt(text, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_sym_encrypt(text, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_sym_encrypt(text, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_sym_encrypt(text, text) TO dashboard_user;


--
-- Name: FUNCTION pgp_sym_encrypt(text, text, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_sym_encrypt(text, text, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_sym_encrypt(text, text, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_sym_encrypt(text, text, text) TO dashboard_user;


--
-- Name: FUNCTION pgp_sym_encrypt_bytea(bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_sym_encrypt_bytea(bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_sym_encrypt_bytea(bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_sym_encrypt_bytea(bytea, text) TO dashboard_user;


--
-- Name: FUNCTION pgp_sym_encrypt_bytea(bytea, text, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_sym_encrypt_bytea(bytea, text, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_sym_encrypt_bytea(bytea, text, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_sym_encrypt_bytea(bytea, text, text) TO dashboard_user;


--
-- Name: FUNCTION pgrst_ddl_watch(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pgrst_ddl_watch() TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION pgrst_drop_watch(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.pgrst_drop_watch() TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION set_graphql_placeholder(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION extensions.set_graphql_placeholder() TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION uuid_generate_v1(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.uuid_generate_v1() FROM postgres;
GRANT ALL ON FUNCTION extensions.uuid_generate_v1() TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.uuid_generate_v1() TO dashboard_user;


--
-- Name: FUNCTION uuid_generate_v1mc(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.uuid_generate_v1mc() FROM postgres;
GRANT ALL ON FUNCTION extensions.uuid_generate_v1mc() TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.uuid_generate_v1mc() TO dashboard_user;


--
-- Name: FUNCTION uuid_generate_v3(namespace uuid, name text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.uuid_generate_v3(namespace uuid, name text) FROM postgres;
GRANT ALL ON FUNCTION extensions.uuid_generate_v3(namespace uuid, name text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.uuid_generate_v3(namespace uuid, name text) TO dashboard_user;


--
-- Name: FUNCTION uuid_generate_v4(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.uuid_generate_v4() FROM postgres;
GRANT ALL ON FUNCTION extensions.uuid_generate_v4() TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.uuid_generate_v4() TO dashboard_user;


--
-- Name: FUNCTION uuid_generate_v5(namespace uuid, name text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.uuid_generate_v5(namespace uuid, name text) FROM postgres;
GRANT ALL ON FUNCTION extensions.uuid_generate_v5(namespace uuid, name text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.uuid_generate_v5(namespace uuid, name text) TO dashboard_user;


--
-- Name: FUNCTION uuid_nil(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.uuid_nil() FROM postgres;
GRANT ALL ON FUNCTION extensions.uuid_nil() TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.uuid_nil() TO dashboard_user;


--
-- Name: FUNCTION uuid_ns_dns(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.uuid_ns_dns() FROM postgres;
GRANT ALL ON FUNCTION extensions.uuid_ns_dns() TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.uuid_ns_dns() TO dashboard_user;


--
-- Name: FUNCTION uuid_ns_oid(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.uuid_ns_oid() FROM postgres;
GRANT ALL ON FUNCTION extensions.uuid_ns_oid() TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.uuid_ns_oid() TO dashboard_user;


--
-- Name: FUNCTION uuid_ns_url(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.uuid_ns_url() FROM postgres;
GRANT ALL ON FUNCTION extensions.uuid_ns_url() TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.uuid_ns_url() TO dashboard_user;


--
-- Name: FUNCTION uuid_ns_x500(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.uuid_ns_x500() FROM postgres;
GRANT ALL ON FUNCTION extensions.uuid_ns_x500() TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.uuid_ns_x500() TO dashboard_user;


--
-- Name: FUNCTION graphql("operationName" text, query text, variables jsonb, extensions jsonb); Type: ACL; Schema: graphql_public; Owner: supabase_admin
--

GRANT ALL ON FUNCTION graphql_public.graphql("operationName" text, query text, variables jsonb, extensions jsonb) TO postgres;
GRANT ALL ON FUNCTION graphql_public.graphql("operationName" text, query text, variables jsonb, extensions jsonb) TO anon;
GRANT ALL ON FUNCTION graphql_public.graphql("operationName" text, query text, variables jsonb, extensions jsonb) TO authenticated;
GRANT ALL ON FUNCTION graphql_public.graphql("operationName" text, query text, variables jsonb, extensions jsonb) TO service_role;


--
-- Name: FUNCTION pg_reload_conf(); Type: ACL; Schema: pg_catalog; Owner: supabase_admin
--

GRANT ALL ON FUNCTION pg_catalog.pg_reload_conf() TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION get_auth(p_usename text); Type: ACL; Schema: pgbouncer; Owner: supabase_admin
--

REVOKE ALL ON FUNCTION pgbouncer.get_auth(p_usename text) FROM PUBLIC;
GRANT ALL ON FUNCTION pgbouncer.get_auth(p_usename text) TO pgbouncer;
GRANT ALL ON FUNCTION pgbouncer.get_auth(p_usename text) TO postgres;


--
-- Name: FUNCTION apply_rls(wal jsonb, max_record_bytes integer); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION realtime.apply_rls(wal jsonb, max_record_bytes integer) TO postgres;
GRANT ALL ON FUNCTION realtime.apply_rls(wal jsonb, max_record_bytes integer) TO dashboard_user;
GRANT ALL ON FUNCTION realtime.apply_rls(wal jsonb, max_record_bytes integer) TO anon;
GRANT ALL ON FUNCTION realtime.apply_rls(wal jsonb, max_record_bytes integer) TO authenticated;
GRANT ALL ON FUNCTION realtime.apply_rls(wal jsonb, max_record_bytes integer) TO service_role;
GRANT ALL ON FUNCTION realtime.apply_rls(wal jsonb, max_record_bytes integer) TO supabase_realtime_admin;


--
-- Name: FUNCTION broadcast_changes(topic_name text, event_name text, operation text, table_name text, table_schema text, new record, old record, level text); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION realtime.broadcast_changes(topic_name text, event_name text, operation text, table_name text, table_schema text, new record, old record, level text) TO postgres;
GRANT ALL ON FUNCTION realtime.broadcast_changes(topic_name text, event_name text, operation text, table_name text, table_schema text, new record, old record, level text) TO dashboard_user;


--
-- Name: FUNCTION build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION realtime.build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]) TO postgres;
GRANT ALL ON FUNCTION realtime.build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]) TO dashboard_user;
GRANT ALL ON FUNCTION realtime.build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]) TO anon;
GRANT ALL ON FUNCTION realtime.build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]) TO authenticated;
GRANT ALL ON FUNCTION realtime.build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]) TO service_role;
GRANT ALL ON FUNCTION realtime.build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]) TO supabase_realtime_admin;


--
-- Name: FUNCTION "cast"(val text, type_ regtype); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION realtime."cast"(val text, type_ regtype) TO postgres;
GRANT ALL ON FUNCTION realtime."cast"(val text, type_ regtype) TO dashboard_user;
GRANT ALL ON FUNCTION realtime."cast"(val text, type_ regtype) TO anon;
GRANT ALL ON FUNCTION realtime."cast"(val text, type_ regtype) TO authenticated;
GRANT ALL ON FUNCTION realtime."cast"(val text, type_ regtype) TO service_role;
GRANT ALL ON FUNCTION realtime."cast"(val text, type_ regtype) TO supabase_realtime_admin;


--
-- Name: FUNCTION check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text) TO postgres;
GRANT ALL ON FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text) TO dashboard_user;
GRANT ALL ON FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text) TO anon;
GRANT ALL ON FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text) TO authenticated;
GRANT ALL ON FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text) TO service_role;
GRANT ALL ON FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text) TO supabase_realtime_admin;


--
-- Name: FUNCTION is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION realtime.is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]) TO postgres;
GRANT ALL ON FUNCTION realtime.is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]) TO dashboard_user;
GRANT ALL ON FUNCTION realtime.is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]) TO anon;
GRANT ALL ON FUNCTION realtime.is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]) TO authenticated;
GRANT ALL ON FUNCTION realtime.is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]) TO service_role;
GRANT ALL ON FUNCTION realtime.is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]) TO supabase_realtime_admin;


--
-- Name: FUNCTION list_changes(publication name, slot_name name, max_changes integer, max_record_bytes integer); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION realtime.list_changes(publication name, slot_name name, max_changes integer, max_record_bytes integer) TO postgres;
GRANT ALL ON FUNCTION realtime.list_changes(publication name, slot_name name, max_changes integer, max_record_bytes integer) TO dashboard_user;
GRANT ALL ON FUNCTION realtime.list_changes(publication name, slot_name name, max_changes integer, max_record_bytes integer) TO anon;
GRANT ALL ON FUNCTION realtime.list_changes(publication name, slot_name name, max_changes integer, max_record_bytes integer) TO authenticated;
GRANT ALL ON FUNCTION realtime.list_changes(publication name, slot_name name, max_changes integer, max_record_bytes integer) TO service_role;
GRANT ALL ON FUNCTION realtime.list_changes(publication name, slot_name name, max_changes integer, max_record_bytes integer) TO supabase_realtime_admin;


--
-- Name: FUNCTION quote_wal2json(entity regclass); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION realtime.quote_wal2json(entity regclass) TO postgres;
GRANT ALL ON FUNCTION realtime.quote_wal2json(entity regclass) TO dashboard_user;
GRANT ALL ON FUNCTION realtime.quote_wal2json(entity regclass) TO anon;
GRANT ALL ON FUNCTION realtime.quote_wal2json(entity regclass) TO authenticated;
GRANT ALL ON FUNCTION realtime.quote_wal2json(entity regclass) TO service_role;
GRANT ALL ON FUNCTION realtime.quote_wal2json(entity regclass) TO supabase_realtime_admin;


--
-- Name: FUNCTION send(payload jsonb, event text, topic text, private boolean); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION realtime.send(payload jsonb, event text, topic text, private boolean) TO postgres;
GRANT ALL ON FUNCTION realtime.send(payload jsonb, event text, topic text, private boolean) TO dashboard_user;


--
-- Name: FUNCTION subscription_check_filters(); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION realtime.subscription_check_filters() TO postgres;
GRANT ALL ON FUNCTION realtime.subscription_check_filters() TO dashboard_user;
GRANT ALL ON FUNCTION realtime.subscription_check_filters() TO anon;
GRANT ALL ON FUNCTION realtime.subscription_check_filters() TO authenticated;
GRANT ALL ON FUNCTION realtime.subscription_check_filters() TO service_role;
GRANT ALL ON FUNCTION realtime.subscription_check_filters() TO supabase_realtime_admin;


--
-- Name: FUNCTION to_regrole(role_name text); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION realtime.to_regrole(role_name text) TO postgres;
GRANT ALL ON FUNCTION realtime.to_regrole(role_name text) TO dashboard_user;
GRANT ALL ON FUNCTION realtime.to_regrole(role_name text) TO anon;
GRANT ALL ON FUNCTION realtime.to_regrole(role_name text) TO authenticated;
GRANT ALL ON FUNCTION realtime.to_regrole(role_name text) TO service_role;
GRANT ALL ON FUNCTION realtime.to_regrole(role_name text) TO supabase_realtime_admin;


--
-- Name: FUNCTION topic(); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION realtime.topic() TO postgres;
GRANT ALL ON FUNCTION realtime.topic() TO dashboard_user;


--
-- Name: FUNCTION _crypto_aead_det_decrypt(message bytea, additional bytea, key_id bigint, context bytea, nonce bytea); Type: ACL; Schema: vault; Owner: supabase_admin
--

GRANT ALL ON FUNCTION vault._crypto_aead_det_decrypt(message bytea, additional bytea, key_id bigint, context bytea, nonce bytea) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION vault._crypto_aead_det_decrypt(message bytea, additional bytea, key_id bigint, context bytea, nonce bytea) TO service_role;


--
-- Name: FUNCTION create_secret(new_secret text, new_name text, new_description text, new_key_id uuid); Type: ACL; Schema: vault; Owner: supabase_admin
--

GRANT ALL ON FUNCTION vault.create_secret(new_secret text, new_name text, new_description text, new_key_id uuid) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION vault.create_secret(new_secret text, new_name text, new_description text, new_key_id uuid) TO service_role;


--
-- Name: FUNCTION update_secret(secret_id uuid, new_secret text, new_name text, new_description text, new_key_id uuid); Type: ACL; Schema: vault; Owner: supabase_admin
--

GRANT ALL ON FUNCTION vault.update_secret(secret_id uuid, new_secret text, new_name text, new_description text, new_key_id uuid) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION vault.update_secret(secret_id uuid, new_secret text, new_name text, new_description text, new_key_id uuid) TO service_role;


--
-- Name: TABLE audit_log_entries; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.audit_log_entries TO dashboard_user;
GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.audit_log_entries TO postgres;
GRANT SELECT ON TABLE auth.audit_log_entries TO postgres WITH GRANT OPTION;


--
-- Name: TABLE flow_state; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.flow_state TO postgres;
GRANT SELECT ON TABLE auth.flow_state TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.flow_state TO dashboard_user;


--
-- Name: TABLE identities; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.identities TO postgres;
GRANT SELECT ON TABLE auth.identities TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.identities TO dashboard_user;


--
-- Name: TABLE instances; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.instances TO dashboard_user;
GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.instances TO postgres;
GRANT SELECT ON TABLE auth.instances TO postgres WITH GRANT OPTION;


--
-- Name: TABLE mfa_amr_claims; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.mfa_amr_claims TO postgres;
GRANT SELECT ON TABLE auth.mfa_amr_claims TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.mfa_amr_claims TO dashboard_user;


--
-- Name: TABLE mfa_challenges; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.mfa_challenges TO postgres;
GRANT SELECT ON TABLE auth.mfa_challenges TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.mfa_challenges TO dashboard_user;


--
-- Name: TABLE mfa_factors; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.mfa_factors TO postgres;
GRANT SELECT ON TABLE auth.mfa_factors TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.mfa_factors TO dashboard_user;


--
-- Name: TABLE oauth_authorizations; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.oauth_authorizations TO postgres;
GRANT ALL ON TABLE auth.oauth_authorizations TO dashboard_user;


--
-- Name: TABLE oauth_clients; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.oauth_clients TO postgres;
GRANT ALL ON TABLE auth.oauth_clients TO dashboard_user;


--
-- Name: TABLE oauth_consents; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.oauth_consents TO postgres;
GRANT ALL ON TABLE auth.oauth_consents TO dashboard_user;


--
-- Name: TABLE one_time_tokens; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.one_time_tokens TO postgres;
GRANT SELECT ON TABLE auth.one_time_tokens TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.one_time_tokens TO dashboard_user;


--
-- Name: TABLE refresh_tokens; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.refresh_tokens TO dashboard_user;
GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.refresh_tokens TO postgres;
GRANT SELECT ON TABLE auth.refresh_tokens TO postgres WITH GRANT OPTION;


--
-- Name: SEQUENCE refresh_tokens_id_seq; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON SEQUENCE auth.refresh_tokens_id_seq TO dashboard_user;
GRANT ALL ON SEQUENCE auth.refresh_tokens_id_seq TO postgres;


--
-- Name: TABLE saml_providers; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.saml_providers TO postgres;
GRANT SELECT ON TABLE auth.saml_providers TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.saml_providers TO dashboard_user;


--
-- Name: TABLE saml_relay_states; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.saml_relay_states TO postgres;
GRANT SELECT ON TABLE auth.saml_relay_states TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.saml_relay_states TO dashboard_user;


--
-- Name: TABLE schema_migrations; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT SELECT ON TABLE auth.schema_migrations TO postgres WITH GRANT OPTION;


--
-- Name: TABLE sessions; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.sessions TO postgres;
GRANT SELECT ON TABLE auth.sessions TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.sessions TO dashboard_user;


--
-- Name: TABLE sso_domains; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.sso_domains TO postgres;
GRANT SELECT ON TABLE auth.sso_domains TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.sso_domains TO dashboard_user;


--
-- Name: TABLE sso_providers; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.sso_providers TO postgres;
GRANT SELECT ON TABLE auth.sso_providers TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE auth.sso_providers TO dashboard_user;


--
-- Name: TABLE users; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE auth.users TO dashboard_user;
GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE auth.users TO postgres;
GRANT SELECT ON TABLE auth.users TO postgres WITH GRANT OPTION;


--
-- Name: TABLE pg_stat_statements; Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON TABLE extensions.pg_stat_statements FROM postgres;
GRANT ALL ON TABLE extensions.pg_stat_statements TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE extensions.pg_stat_statements TO dashboard_user;


--
-- Name: TABLE pg_stat_statements_info; Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON TABLE extensions.pg_stat_statements_info FROM postgres;
GRANT ALL ON TABLE extensions.pg_stat_statements_info TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE extensions.pg_stat_statements_info TO dashboard_user;


--
-- Name: TABLE auth_group; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.auth_group TO anon;
GRANT ALL ON TABLE public.auth_group TO authenticated;
GRANT ALL ON TABLE public.auth_group TO service_role;


--
-- Name: SEQUENCE auth_group_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.auth_group_id_seq TO anon;
GRANT ALL ON SEQUENCE public.auth_group_id_seq TO authenticated;
GRANT ALL ON SEQUENCE public.auth_group_id_seq TO service_role;


--
-- Name: TABLE auth_group_permissions; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.auth_group_permissions TO anon;
GRANT ALL ON TABLE public.auth_group_permissions TO authenticated;
GRANT ALL ON TABLE public.auth_group_permissions TO service_role;


--
-- Name: SEQUENCE auth_group_permissions_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.auth_group_permissions_id_seq TO anon;
GRANT ALL ON SEQUENCE public.auth_group_permissions_id_seq TO authenticated;
GRANT ALL ON SEQUENCE public.auth_group_permissions_id_seq TO service_role;


--
-- Name: TABLE auth_permission; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.auth_permission TO anon;
GRANT ALL ON TABLE public.auth_permission TO authenticated;
GRANT ALL ON TABLE public.auth_permission TO service_role;


--
-- Name: SEQUENCE auth_permission_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.auth_permission_id_seq TO anon;
GRANT ALL ON SEQUENCE public.auth_permission_id_seq TO authenticated;
GRANT ALL ON SEQUENCE public.auth_permission_id_seq TO service_role;


--
-- Name: TABLE auth_user; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.auth_user TO anon;
GRANT ALL ON TABLE public.auth_user TO authenticated;
GRANT ALL ON TABLE public.auth_user TO service_role;


--
-- Name: TABLE auth_user_groups; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.auth_user_groups TO anon;
GRANT ALL ON TABLE public.auth_user_groups TO authenticated;
GRANT ALL ON TABLE public.auth_user_groups TO service_role;


--
-- Name: SEQUENCE auth_user_groups_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.auth_user_groups_id_seq TO anon;
GRANT ALL ON SEQUENCE public.auth_user_groups_id_seq TO authenticated;
GRANT ALL ON SEQUENCE public.auth_user_groups_id_seq TO service_role;


--
-- Name: SEQUENCE auth_user_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.auth_user_id_seq TO anon;
GRANT ALL ON SEQUENCE public.auth_user_id_seq TO authenticated;
GRANT ALL ON SEQUENCE public.auth_user_id_seq TO service_role;


--
-- Name: TABLE auth_user_user_permissions; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.auth_user_user_permissions TO anon;
GRANT ALL ON TABLE public.auth_user_user_permissions TO authenticated;
GRANT ALL ON TABLE public.auth_user_user_permissions TO service_role;


--
-- Name: SEQUENCE auth_user_user_permissions_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.auth_user_user_permissions_id_seq TO anon;
GRANT ALL ON SEQUENCE public.auth_user_user_permissions_id_seq TO authenticated;
GRANT ALL ON SEQUENCE public.auth_user_user_permissions_id_seq TO service_role;


--
-- Name: TABLE core_announcement; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.core_announcement TO anon;
GRANT ALL ON TABLE public.core_announcement TO authenticated;
GRANT ALL ON TABLE public.core_announcement TO service_role;


--
-- Name: SEQUENCE core_announcement_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.core_announcement_id_seq TO anon;
GRANT ALL ON SEQUENCE public.core_announcement_id_seq TO authenticated;
GRANT ALL ON SEQUENCE public.core_announcement_id_seq TO service_role;


--
-- Name: TABLE core_document; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.core_document TO anon;
GRANT ALL ON TABLE public.core_document TO authenticated;
GRANT ALL ON TABLE public.core_document TO service_role;


--
-- Name: SEQUENCE core_document_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.core_document_id_seq TO anon;
GRANT ALL ON SEQUENCE public.core_document_id_seq TO authenticated;
GRANT ALL ON SEQUENCE public.core_document_id_seq TO service_role;


--
-- Name: TABLE core_documentcategory; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.core_documentcategory TO anon;
GRANT ALL ON TABLE public.core_documentcategory TO authenticated;
GRANT ALL ON TABLE public.core_documentcategory TO service_role;


--
-- Name: SEQUENCE core_documentcategory_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.core_documentcategory_id_seq TO anon;
GRANT ALL ON SEQUENCE public.core_documentcategory_id_seq TO authenticated;
GRANT ALL ON SEQUENCE public.core_documentcategory_id_seq TO service_role;


--
-- Name: TABLE core_fee; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.core_fee TO anon;
GRANT ALL ON TABLE public.core_fee TO authenticated;
GRANT ALL ON TABLE public.core_fee TO service_role;


--
-- Name: SEQUENCE core_fee_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.core_fee_id_seq TO anon;
GRANT ALL ON SEQUENCE public.core_fee_id_seq TO authenticated;
GRANT ALL ON SEQUENCE public.core_fee_id_seq TO service_role;


--
-- Name: TABLE core_household; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.core_household TO anon;
GRANT ALL ON TABLE public.core_household TO authenticated;
GRANT ALL ON TABLE public.core_household TO service_role;


--
-- Name: SEQUENCE core_household_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.core_household_id_seq TO anon;
GRANT ALL ON SEQUENCE public.core_household_id_seq TO authenticated;
GRANT ALL ON SEQUENCE public.core_household_id_seq TO service_role;


--
-- Name: TABLE core_household_residents; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.core_household_residents TO anon;
GRANT ALL ON TABLE public.core_household_residents TO authenticated;
GRANT ALL ON TABLE public.core_household_residents TO service_role;


--
-- Name: SEQUENCE core_household_residents_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.core_household_residents_id_seq TO anon;
GRANT ALL ON SEQUENCE public.core_household_residents_id_seq TO authenticated;
GRANT ALL ON SEQUENCE public.core_household_residents_id_seq TO service_role;


--
-- Name: TABLE core_incident; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.core_incident TO anon;
GRANT ALL ON TABLE public.core_incident TO authenticated;
GRANT ALL ON TABLE public.core_incident TO service_role;


--
-- Name: SEQUENCE core_incident_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.core_incident_id_seq TO anon;
GRANT ALL ON SEQUENCE public.core_incident_id_seq TO authenticated;
GRANT ALL ON SEQUENCE public.core_incident_id_seq TO service_role;


--
-- Name: TABLE core_incidentcategory; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.core_incidentcategory TO anon;
GRANT ALL ON TABLE public.core_incidentcategory TO authenticated;
GRANT ALL ON TABLE public.core_incidentcategory TO service_role;


--
-- Name: SEQUENCE core_incidentcategory_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.core_incidentcategory_id_seq TO anon;
GRANT ALL ON SEQUENCE public.core_incidentcategory_id_seq TO authenticated;
GRANT ALL ON SEQUENCE public.core_incidentcategory_id_seq TO service_role;


--
-- Name: TABLE core_inscriptionevidence; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.core_inscriptionevidence TO anon;
GRANT ALL ON TABLE public.core_inscriptionevidence TO authenticated;
GRANT ALL ON TABLE public.core_inscriptionevidence TO service_role;


--
-- Name: SEQUENCE core_inscriptionevidence_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.core_inscriptionevidence_id_seq TO anon;
GRANT ALL ON SEQUENCE public.core_inscriptionevidence_id_seq TO authenticated;
GRANT ALL ON SEQUENCE public.core_inscriptionevidence_id_seq TO service_role;


--
-- Name: TABLE core_meeting; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.core_meeting TO anon;
GRANT ALL ON TABLE public.core_meeting TO authenticated;
GRANT ALL ON TABLE public.core_meeting TO service_role;


--
-- Name: SEQUENCE core_meeting_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.core_meeting_id_seq TO anon;
GRANT ALL ON SEQUENCE public.core_meeting_id_seq TO authenticated;
GRANT ALL ON SEQUENCE public.core_meeting_id_seq TO service_role;


--
-- Name: TABLE core_minutes; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.core_minutes TO anon;
GRANT ALL ON TABLE public.core_minutes TO authenticated;
GRANT ALL ON TABLE public.core_minutes TO service_role;


--
-- Name: SEQUENCE core_minutes_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.core_minutes_id_seq TO anon;
GRANT ALL ON SEQUENCE public.core_minutes_id_seq TO authenticated;
GRANT ALL ON SEQUENCE public.core_minutes_id_seq TO service_role;


--
-- Name: TABLE core_notification; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.core_notification TO anon;
GRANT ALL ON TABLE public.core_notification TO authenticated;
GRANT ALL ON TABLE public.core_notification TO service_role;


--
-- Name: SEQUENCE core_notification_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.core_notification_id_seq TO anon;
GRANT ALL ON SEQUENCE public.core_notification_id_seq TO authenticated;
GRANT ALL ON SEQUENCE public.core_notification_id_seq TO service_role;


--
-- Name: TABLE core_payment; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.core_payment TO anon;
GRANT ALL ON TABLE public.core_payment TO authenticated;
GRANT ALL ON TABLE public.core_payment TO service_role;


--
-- Name: SEQUENCE core_payment_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.core_payment_id_seq TO anon;
GRANT ALL ON SEQUENCE public.core_payment_id_seq TO authenticated;
GRANT ALL ON SEQUENCE public.core_payment_id_seq TO service_role;


--
-- Name: TABLE core_reservation; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.core_reservation TO anon;
GRANT ALL ON TABLE public.core_reservation TO authenticated;
GRANT ALL ON TABLE public.core_reservation TO service_role;


--
-- Name: SEQUENCE core_reservation_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.core_reservation_id_seq TO anon;
GRANT ALL ON SEQUENCE public.core_reservation_id_seq TO authenticated;
GRANT ALL ON SEQUENCE public.core_reservation_id_seq TO service_role;


--
-- Name: TABLE core_resident; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.core_resident TO anon;
GRANT ALL ON TABLE public.core_resident TO authenticated;
GRANT ALL ON TABLE public.core_resident TO service_role;


--
-- Name: SEQUENCE core_resident_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.core_resident_id_seq TO anon;
GRANT ALL ON SEQUENCE public.core_resident_id_seq TO authenticated;
GRANT ALL ON SEQUENCE public.core_resident_id_seq TO service_role;


--
-- Name: TABLE core_resource; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.core_resource TO anon;
GRANT ALL ON TABLE public.core_resource TO authenticated;
GRANT ALL ON TABLE public.core_resource TO service_role;


--
-- Name: SEQUENCE core_resource_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.core_resource_id_seq TO anon;
GRANT ALL ON SEQUENCE public.core_resource_id_seq TO authenticated;
GRANT ALL ON SEQUENCE public.core_resource_id_seq TO service_role;


--
-- Name: TABLE core_resourcecategory; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.core_resourcecategory TO anon;
GRANT ALL ON TABLE public.core_resourcecategory TO authenticated;
GRANT ALL ON TABLE public.core_resourcecategory TO service_role;


--
-- Name: SEQUENCE core_resourcecategory_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.core_resourcecategory_id_seq TO anon;
GRANT ALL ON SEQUENCE public.core_resourcecategory_id_seq TO authenticated;
GRANT ALL ON SEQUENCE public.core_resourcecategory_id_seq TO service_role;


--
-- Name: TABLE django_admin_log; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.django_admin_log TO anon;
GRANT ALL ON TABLE public.django_admin_log TO authenticated;
GRANT ALL ON TABLE public.django_admin_log TO service_role;


--
-- Name: SEQUENCE django_admin_log_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.django_admin_log_id_seq TO anon;
GRANT ALL ON SEQUENCE public.django_admin_log_id_seq TO authenticated;
GRANT ALL ON SEQUENCE public.django_admin_log_id_seq TO service_role;


--
-- Name: TABLE django_content_type; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.django_content_type TO anon;
GRANT ALL ON TABLE public.django_content_type TO authenticated;
GRANT ALL ON TABLE public.django_content_type TO service_role;


--
-- Name: SEQUENCE django_content_type_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.django_content_type_id_seq TO anon;
GRANT ALL ON SEQUENCE public.django_content_type_id_seq TO authenticated;
GRANT ALL ON SEQUENCE public.django_content_type_id_seq TO service_role;


--
-- Name: TABLE django_migrations; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.django_migrations TO anon;
GRANT ALL ON TABLE public.django_migrations TO authenticated;
GRANT ALL ON TABLE public.django_migrations TO service_role;


--
-- Name: SEQUENCE django_migrations_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.django_migrations_id_seq TO anon;
GRANT ALL ON SEQUENCE public.django_migrations_id_seq TO authenticated;
GRANT ALL ON SEQUENCE public.django_migrations_id_seq TO service_role;


--
-- Name: TABLE django_session; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.django_session TO anon;
GRANT ALL ON TABLE public.django_session TO authenticated;
GRANT ALL ON TABLE public.django_session TO service_role;


--
-- Name: TABLE messages; Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON TABLE realtime.messages TO postgres;
GRANT ALL ON TABLE realtime.messages TO dashboard_user;
GRANT SELECT,INSERT,UPDATE ON TABLE realtime.messages TO anon;
GRANT SELECT,INSERT,UPDATE ON TABLE realtime.messages TO authenticated;
GRANT SELECT,INSERT,UPDATE ON TABLE realtime.messages TO service_role;


--
-- Name: TABLE schema_migrations; Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON TABLE realtime.schema_migrations TO postgres;
GRANT ALL ON TABLE realtime.schema_migrations TO dashboard_user;
GRANT SELECT ON TABLE realtime.schema_migrations TO anon;
GRANT SELECT ON TABLE realtime.schema_migrations TO authenticated;
GRANT SELECT ON TABLE realtime.schema_migrations TO service_role;
GRANT ALL ON TABLE realtime.schema_migrations TO supabase_realtime_admin;


--
-- Name: TABLE subscription; Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON TABLE realtime.subscription TO postgres;
GRANT ALL ON TABLE realtime.subscription TO dashboard_user;
GRANT SELECT ON TABLE realtime.subscription TO anon;
GRANT SELECT ON TABLE realtime.subscription TO authenticated;
GRANT SELECT ON TABLE realtime.subscription TO service_role;
GRANT ALL ON TABLE realtime.subscription TO supabase_realtime_admin;


--
-- Name: SEQUENCE subscription_id_seq; Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON SEQUENCE realtime.subscription_id_seq TO postgres;
GRANT ALL ON SEQUENCE realtime.subscription_id_seq TO dashboard_user;
GRANT USAGE ON SEQUENCE realtime.subscription_id_seq TO anon;
GRANT USAGE ON SEQUENCE realtime.subscription_id_seq TO authenticated;
GRANT USAGE ON SEQUENCE realtime.subscription_id_seq TO service_role;
GRANT ALL ON SEQUENCE realtime.subscription_id_seq TO supabase_realtime_admin;


--
-- Name: TABLE buckets; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

REVOKE ALL ON TABLE storage.buckets FROM supabase_storage_admin;
GRANT ALL ON TABLE storage.buckets TO supabase_storage_admin WITH GRANT OPTION;
GRANT ALL ON TABLE storage.buckets TO anon;
GRANT ALL ON TABLE storage.buckets TO authenticated;
GRANT ALL ON TABLE storage.buckets TO service_role;
GRANT ALL ON TABLE storage.buckets TO postgres WITH GRANT OPTION;


--
-- Name: TABLE buckets_analytics; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON TABLE storage.buckets_analytics TO service_role;
GRANT ALL ON TABLE storage.buckets_analytics TO authenticated;
GRANT ALL ON TABLE storage.buckets_analytics TO anon;


--
-- Name: TABLE buckets_vectors; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT SELECT ON TABLE storage.buckets_vectors TO service_role;
GRANT SELECT ON TABLE storage.buckets_vectors TO authenticated;
GRANT SELECT ON TABLE storage.buckets_vectors TO anon;


--
-- Name: TABLE objects; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

REVOKE ALL ON TABLE storage.objects FROM supabase_storage_admin;
GRANT ALL ON TABLE storage.objects TO supabase_storage_admin WITH GRANT OPTION;
GRANT ALL ON TABLE storage.objects TO anon;
GRANT ALL ON TABLE storage.objects TO authenticated;
GRANT ALL ON TABLE storage.objects TO service_role;
GRANT ALL ON TABLE storage.objects TO postgres WITH GRANT OPTION;


--
-- Name: TABLE prefixes; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON TABLE storage.prefixes TO service_role;
GRANT ALL ON TABLE storage.prefixes TO authenticated;
GRANT ALL ON TABLE storage.prefixes TO anon;


--
-- Name: TABLE s3_multipart_uploads; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON TABLE storage.s3_multipart_uploads TO service_role;
GRANT SELECT ON TABLE storage.s3_multipart_uploads TO authenticated;
GRANT SELECT ON TABLE storage.s3_multipart_uploads TO anon;


--
-- Name: TABLE s3_multipart_uploads_parts; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON TABLE storage.s3_multipart_uploads_parts TO service_role;
GRANT SELECT ON TABLE storage.s3_multipart_uploads_parts TO authenticated;
GRANT SELECT ON TABLE storage.s3_multipart_uploads_parts TO anon;


--
-- Name: TABLE vector_indexes; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT SELECT ON TABLE storage.vector_indexes TO service_role;
GRANT SELECT ON TABLE storage.vector_indexes TO authenticated;
GRANT SELECT ON TABLE storage.vector_indexes TO anon;


--
-- Name: TABLE secrets; Type: ACL; Schema: vault; Owner: supabase_admin
--

GRANT SELECT,REFERENCES,DELETE,TRUNCATE ON TABLE vault.secrets TO postgres WITH GRANT OPTION;
GRANT SELECT,DELETE ON TABLE vault.secrets TO service_role;


--
-- Name: TABLE decrypted_secrets; Type: ACL; Schema: vault; Owner: supabase_admin
--

GRANT SELECT,REFERENCES,DELETE,TRUNCATE ON TABLE vault.decrypted_secrets TO postgres WITH GRANT OPTION;
GRANT SELECT,DELETE ON TABLE vault.decrypted_secrets TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: auth; Owner: supabase_auth_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_auth_admin IN SCHEMA auth GRANT ALL ON SEQUENCES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_auth_admin IN SCHEMA auth GRANT ALL ON SEQUENCES TO dashboard_user;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: auth; Owner: supabase_auth_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_auth_admin IN SCHEMA auth GRANT ALL ON FUNCTIONS TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_auth_admin IN SCHEMA auth GRANT ALL ON FUNCTIONS TO dashboard_user;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: auth; Owner: supabase_auth_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_auth_admin IN SCHEMA auth GRANT ALL ON TABLES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_auth_admin IN SCHEMA auth GRANT ALL ON TABLES TO dashboard_user;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: extensions; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA extensions GRANT ALL ON SEQUENCES TO postgres WITH GRANT OPTION;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: extensions; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA extensions GRANT ALL ON FUNCTIONS TO postgres WITH GRANT OPTION;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: extensions; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA extensions GRANT ALL ON TABLES TO postgres WITH GRANT OPTION;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: graphql; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON SEQUENCES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON SEQUENCES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON SEQUENCES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON SEQUENCES TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: graphql; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON FUNCTIONS TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON FUNCTIONS TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON FUNCTIONS TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON FUNCTIONS TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: graphql; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON TABLES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON TABLES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON TABLES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql GRANT ALL ON TABLES TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: graphql_public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON SEQUENCES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON SEQUENCES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON SEQUENCES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON SEQUENCES TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: graphql_public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON FUNCTIONS TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON FUNCTIONS TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON FUNCTIONS TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON FUNCTIONS TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: graphql_public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON TABLES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON TABLES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON TABLES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON TABLES TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON SEQUENCES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON SEQUENCES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON SEQUENCES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON SEQUENCES TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON SEQUENCES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON SEQUENCES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON SEQUENCES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON SEQUENCES TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON FUNCTIONS TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON FUNCTIONS TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON FUNCTIONS TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON FUNCTIONS TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON FUNCTIONS TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON FUNCTIONS TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON FUNCTIONS TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON FUNCTIONS TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON TABLES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON TABLES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON TABLES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON TABLES TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON TABLES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON TABLES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON TABLES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON TABLES TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: realtime; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA realtime GRANT ALL ON SEQUENCES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA realtime GRANT ALL ON SEQUENCES TO dashboard_user;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: realtime; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA realtime GRANT ALL ON FUNCTIONS TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA realtime GRANT ALL ON FUNCTIONS TO dashboard_user;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: realtime; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA realtime GRANT ALL ON TABLES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA realtime GRANT ALL ON TABLES TO dashboard_user;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: storage; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON SEQUENCES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON SEQUENCES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON SEQUENCES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON SEQUENCES TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: storage; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON FUNCTIONS TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON FUNCTIONS TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON FUNCTIONS TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON FUNCTIONS TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: storage; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON TABLES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON TABLES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON TABLES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA storage GRANT ALL ON TABLES TO service_role;


--
-- Name: issue_graphql_placeholder; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER issue_graphql_placeholder ON sql_drop
         WHEN TAG IN ('DROP EXTENSION')
   EXECUTE FUNCTION extensions.set_graphql_placeholder();


ALTER EVENT TRIGGER issue_graphql_placeholder OWNER TO supabase_admin;

--
-- Name: issue_pg_cron_access; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER issue_pg_cron_access ON ddl_command_end
         WHEN TAG IN ('CREATE EXTENSION')
   EXECUTE FUNCTION extensions.grant_pg_cron_access();


ALTER EVENT TRIGGER issue_pg_cron_access OWNER TO supabase_admin;

--
-- Name: issue_pg_graphql_access; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER issue_pg_graphql_access ON ddl_command_end
         WHEN TAG IN ('CREATE FUNCTION')
   EXECUTE FUNCTION extensions.grant_pg_graphql_access();


ALTER EVENT TRIGGER issue_pg_graphql_access OWNER TO supabase_admin;

--
-- Name: issue_pg_net_access; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER issue_pg_net_access ON ddl_command_end
         WHEN TAG IN ('CREATE EXTENSION')
   EXECUTE FUNCTION extensions.grant_pg_net_access();


ALTER EVENT TRIGGER issue_pg_net_access OWNER TO supabase_admin;

--
-- Name: pgrst_ddl_watch; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER pgrst_ddl_watch ON ddl_command_end
   EXECUTE FUNCTION extensions.pgrst_ddl_watch();


ALTER EVENT TRIGGER pgrst_ddl_watch OWNER TO supabase_admin;

--
-- Name: pgrst_drop_watch; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER pgrst_drop_watch ON sql_drop
   EXECUTE FUNCTION extensions.pgrst_drop_watch();


ALTER EVENT TRIGGER pgrst_drop_watch OWNER TO supabase_admin;

--
-- PostgreSQL database dump complete
--

